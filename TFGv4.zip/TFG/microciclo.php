<?php session_start(); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <script src="js/javascript.js"></script>
    
    <!-- CSS -->
    <style>
     /*header {padding: 154px 0 100px;}*/
     section {padding: 100px 0;}
     .slider{
        background: url("images/hj1.jpg");
        height: 50vh;
        background-size: cover;
        background-position: center;
      }
    </style>

    <title>Plataforma de Entrenamiento</title>
  </head>
  <body>

    <?php require("./view/vistaNav.php"); ?>
    <?php require("./controller/controllerMicrociclo.php"); ?>

    <section id="micorciclo">
      <div class="container">
        <div class="row">
          <div class="col mx-auto bg-light">
            </br>
              <h3>Generación de Entrenamiento</h3>
            </br>
            <div class="form-group">
              <div class="col-12 col-sm-12 col-md-10 col-lg-7">
              <table class="table table-sm table-hover">
                <thead class="thead-dark">
                  <tr>
                    <th scope="col">Nombre</th>
                    <th scope="col">Apellidos</th>
                    <th class="text-center" scope="col">Seleccionar</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                    $i=0;
                    foreach($atletas as $atletas){ 
                  ?>
                    <tr>
                      <td><?php echo $atletas['Nombre'];?></th>
                      <td><?php echo $atletas['Apellidos'];?></td>
                      <td class="text-center"><input type="checkbox" value="<?php echo $atletas['Id'];?>" name="atleta<?php echo $i;?>" id="atleta<?php echo $i;?>"/></td>
                    </tr>
                  <?php
                      $i++;
                    }              
                  ?>
                </tbody>
              </table>
              </div>
            </div>
            </br>
            <div class="row">
              <div class="col">
                <div id="boton">
                  <button class="btn btn-primary ml-2" type="button" onclick="generar_entrenamiento(<?php echo $i;?>, <?php echo $id;?>, <?php echo $semana;?>, '<?php echo $user;?>', '<?php echo $dia;?>');">Generar entrenamiento</button>
              </div>
              </div>
            </div>
            </br>
            <div class="row" id="java">
            </div>
          </div>
        </div>
      </div>
    </section>

    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Plataforma de Entrenamiento 2018</p>
      </div>
    </footer>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>