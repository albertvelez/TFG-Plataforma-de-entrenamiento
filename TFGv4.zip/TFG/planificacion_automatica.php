<?php session_start(); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <script src="js/javascript.js"></script>
    
    <!-- CSS -->
    <style>
     /*header {padding: 154px 0 100px;}*/
     section {padding: 100px 0;}
     .slider{
        background: url("images/hj1.jpg");
        height: 50vh;
        background-size: cover;
        background-position: center;
      }
    </style>

    <title>Plataforma de Entrenamiento</title>
  </head>
  <body>

    <?php require("./view/vistaNav.php"); ?>

    <section id="planificacion_automatica">
      <div class="container">
        <div class="row">
          <div class="col mx-auto bg-light">
            </br>
            <h3>Planificación automática</h3>
            </br>
            <form method="post" action="controller/controllerPlanAuto.php">
              <div class="form-group">
                <label for="nombre">Nombre planificación:</label>
                <input type="text" class="form-control" name="nombre" pattern="[A-Za-z0-9]{5,20}" required=""/>
              </div>
              <div class="form-group">
                <label for="temporada">Temporada:</label>
                <select name="temporada" class="form-control">
                  <option value="2017/2018">2017/2018</option>
                  <option value="2018/2019">2018/2019</option>
                  <option value="2019/2020">2019/2020</option>
                  <option value="2020/2021">2020/2021</option>
                </select>
              </div>
              <div class="form-group">
                <label for="periodo">Periodo:</label>
                <select name="periodo" class="form-control">
                  <option value="Pista cubierta">Pista cubierta</option>
                  <option value="Aire libre">Aire libre</option>
                </select>
              </div>
              <div class="form-group">
                <label for="competitivo">Num. semanas Periodo competitivo:</label>
                <select name="competitivo" class="form-control">
                  <option value="3">3 semanas</option>
                  <option value="4">4 semanas</option>
                  <option value="5">5 semanas</option>
                  <option value="6">6 semanas</option>
                  <option value="7">7 semanas</option>
                  <option value="8">8 semanas</option>
                  <option value="9">9 semanas</option>
                  <option value="10">10 semanas</option>
                </select>
              </div>
              <div class="form-group">
                <label for="variabilidad">Variabilidad:</label>
                <select name="variabilidad" class="form-control">
                  <option value="1">Baja</option>
                  <option value="2">Alta</option>
                </select>
              </div>
              </br>
              <div class="form-group">
                <button type="submit" class="btn btn-primary">Generar planificación</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Plataforma de Entrenamiento 2018</p>
      </div>
    </footer>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>