<?php session_start(); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- CSS -->
    <style>
     /*header {padding: 154px 0 100px;}*/
     section {padding: 100px 0;}
     .slider{
        background: url("images/hj1.jpg");
        height: 50vh;
        background-size: cover;
        background-position: center;
      }
    </style>

    <title>Plataforma de Entrenamiento</title>
  </head>
  <body>

    <?php require("./view/vistaNav.php"); ?>
    <?php require("./controller/controllerEntrenamiento_concreto.php"); ?>

    <section id="entrenamientos">
      <div class="container">
        <div class="row">
          <div class="col mx-auto bg-light">
            </br>
              <h3>Entrenamiento - <?php echo $fecha ?></h3>
              <h4>Semana <?php echo $semana ?></h4>
              <h4><?php echo $dia ?></h4>
            </br>
              <h5><u>Atletas</u></h5>
            <?php foreach($atletas as $atletas){?>
              <?php $id = $atletas['Id_atleta']; $atleta = result_nombreatleta($id); while($obj = $atleta->fetch_object()){$datos = $obj;}?>
              <?php echo $datos->Nombre ?> <?php echo $datos->Apellidos?><br />
            <?php } ?>
            </br>
              <h5><u>Sesión: Mañana</u></h5>
              <p><?php if($u1 != '---'){echo $u1;}?></p>
              <p><?php if($u2 != '---'){echo $u2;}?></p>
              <p><?php if($u3 != '---'){echo $u3;}?></p>
            </br>
              <h5><u>Sesión: Tarde</u></h5>
              <p><?php if($u4 != '---'){echo $u4;}?></p>
              <p><?php if($u5 != '---'){echo $u5;}?></p>
              <p><?php if($u6 != '---'){echo $u6;}?></p>
          </div>
        </div>
      </div>
    </section>

    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Plataforma de Entrenamiento 2018</p>
      </div>
    </footer>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>