<?php
  session_start();

  $id = $_GET['id'];
?>

<div class="form-group">
  <label for="nombre">Nombre:</label>
  <input type="text" class="form-control" name="nombre" pattern="[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð '-]{2,30}" required=""/>
</div>
<div class="form-group">
  <label for="apellidos">Apellidos:</label>
  <input type="text" class="form-control" name="apellidos" pattern="[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð '-]{2,30}" required=""/>
</div>
<div class="form-group">
  <label for="email">E-mail:</label>
  <input type="email" class="form-control" name="email" pattern="^[-\w.]+@{1}[-a-z0-9]+[.]{1}[a-z]{2,5}$" required=""/>
</div>
<div class="form-group">
  <label for="club_organizacion">Club/Organización:</label>
  <input type="text" class="form-control" name="club_organizacion" pattern="[a-zA-Z0-9àáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-ºª]{2,30}" required=""/>
</div>
<div class="form-group">
  <label for="sector">Sector:</label>
  <select name="sector"class="form-control">
    <option value="Saltos">Saltos</option>
  </select>
</div>
<div class="form-group">
  <label for="especialidad">Especialidad:</label>
  <select name="especialidad" class="form-control">
    <option value="Salto de altura">Salto de altura</option>
  </select>
</div>
<?php if($id==2){?>
<div class="form-group">
  <label for="fecha">Año de nacimiento:</label>
  <input type="text" class="form-control" name="fecha" pattern="[0-9]{4}" required=""/>
</div>
<div class="form-group">
  <label for="nombreentrenador">Entrenador (nombre de su usuario):</label>
  <input type="text" class="form-control" name="nombreentrenador" pattern="[A-Za-z0-9]{5,10}" required=""/>
</div>
<?php } ?>
<?php if($id==1){?>
<div class="form-group">
  <label for="titulacion">Titulación:</label>
  <select name="titulacion" class="form-control">
    <option value="Nacional especializado">E. Nacional especializado</option>
    <option value="Nacional">E. Nacional</option>
    <option value="Club">E. Club</option>
    <option value="Monitor">Monitor</option>
  </select>
</div>
<?php } ?>
<br/>
<div class="form-group">
  <label for="user">Nombre de usuario:</label>
  <input type="text" class="form-control" name="user" pattern="[A-Za-z0-9]{5,10}" required=""/>
</div>
<div class="form-group">
  <label for="pass">Contraseña:</label>
  <input type="password" class="form-control" name="pass" pattern="[A-Za-z0-9]{4,8}" required=""/>
</div>
<div class="form-group">
  <button type="submit" class="btn btn-primary">Registrarse</button>
</div>