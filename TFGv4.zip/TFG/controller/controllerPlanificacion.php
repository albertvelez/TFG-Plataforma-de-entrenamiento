<?php
	require("./model/model.php");

	if(isset($_SESSION['entrenador'])){

		$user = $_SESSION['entrenador'];

		$planificaciones = seleccionar_planificacion($user);

		$planificacion = array();

		while($row = $planificaciones->fetch_assoc()) {
			$planificacion[]= $row;
	    }

    }else{
        echo "<script>alert('Para hacer una planificacion necesitas ser entrenador');</script>";
        echo '<script>window.location.assign("./login.php");</script>';
    }              
?>