<?php
	require("./model/model.php");

	$user = $_SESSION['atleta'];

	$id_atleta = result_idatleta($user);
	$datos_entrenamientos = datos_entrenamientos_atleta($id_atleta);  
	      
	$entrenamientos = array();

	while($row = $datos_entrenamientos->fetch_assoc()) {
		$entrenamientos[]= $row;
	}
?>