<?php
    session_start();
    require("../model/model.php");

    $id_planificacion = $_GET['id'];
    $mesociclo = $_GET['mesociclo'];
    $semana = $_GET['semana'];
    
    /*Lunes*/
    $u_entrenamiento_1_1 = $_POST['u_entrenamiento_1_1'];
    $u_entrenamiento_1_2 = $_POST['u_entrenamiento_1_3'];
    $u_entrenamiento_1_3 = $_POST['u_entrenamiento_1_5'];
    $u_entrenamiento_1_4 = $_POST['u_entrenamiento_1_2'];
    $u_entrenamiento_1_5 = $_POST['u_entrenamiento_1_4'];
    $u_entrenamiento_1_6 = $_POST['u_entrenamiento_1_6'];
    $dia = "Lunes";
    guardar_semana_mesociclo($id_planificacion, $mesociclo, $semana, $dia, $u_entrenamiento_1_1, $u_entrenamiento_1_2, $u_entrenamiento_1_3, $u_entrenamiento_1_4, $u_entrenamiento_1_5, $u_entrenamiento_1_6);
    /*Martes*/
    $u_entrenamiento_2_1 = $_POST['u_entrenamiento_2_1'];
    $u_entrenamiento_2_2 = $_POST['u_entrenamiento_2_3'];
    $u_entrenamiento_2_3 = $_POST['u_entrenamiento_2_5'];
    $u_entrenamiento_2_4 = $_POST['u_entrenamiento_2_2'];
    $u_entrenamiento_2_5 = $_POST['u_entrenamiento_2_4'];
    $u_entrenamiento_2_6 = $_POST['u_entrenamiento_2_6'];
    $dia = "Martes";
    guardar_semana_mesociclo($id_planificacion, $mesociclo, $semana, $dia, $u_entrenamiento_2_1, $u_entrenamiento_2_2, $u_entrenamiento_2_3, $u_entrenamiento_2_4, $u_entrenamiento_2_5, $u_entrenamiento_2_6);
    /*Miercoles*/
    $u_entrenamiento_3_1 = $_POST['u_entrenamiento_3_1'];
    $u_entrenamiento_3_2 = $_POST['u_entrenamiento_3_3'];
    $u_entrenamiento_3_3 = $_POST['u_entrenamiento_3_5'];
    $u_entrenamiento_3_4 = $_POST['u_entrenamiento_3_2'];
    $u_entrenamiento_3_5 = $_POST['u_entrenamiento_3_4'];
    $u_entrenamiento_3_6 = $_POST['u_entrenamiento_3_6'];
    $dia = "Miércoles";
    guardar_semana_mesociclo($id_planificacion, $mesociclo, $semana, $dia, $u_entrenamiento_3_1, $u_entrenamiento_3_2, $u_entrenamiento_3_3, $u_entrenamiento_3_4, $u_entrenamiento_3_5, $u_entrenamiento_3_6);
    /*Jueves*/
    $u_entrenamiento_4_1 = $_POST['u_entrenamiento_4_1'];
    $u_entrenamiento_4_2 = $_POST['u_entrenamiento_4_3'];
    $u_entrenamiento_4_3 = $_POST['u_entrenamiento_4_5'];
    $u_entrenamiento_4_4 = $_POST['u_entrenamiento_4_2'];
    $u_entrenamiento_4_5 = $_POST['u_entrenamiento_4_4'];
    $u_entrenamiento_4_6 = $_POST['u_entrenamiento_4_6'];
    $dia = "Jueves";
    guardar_semana_mesociclo($id_planificacion, $mesociclo, $semana, $dia, $u_entrenamiento_4_1, $u_entrenamiento_4_2, $u_entrenamiento_4_3, $u_entrenamiento_4_4, $u_entrenamiento_4_5, $u_entrenamiento_4_6);
    /*Viernes*/
    $u_entrenamiento_5_1 = $_POST['u_entrenamiento_5_1'];
    $u_entrenamiento_5_2 = $_POST['u_entrenamiento_5_3'];
    $u_entrenamiento_5_3 = $_POST['u_entrenamiento_5_5'];
    $u_entrenamiento_5_4 = $_POST['u_entrenamiento_5_2'];
    $u_entrenamiento_5_5 = $_POST['u_entrenamiento_5_4'];
    $u_entrenamiento_5_6 = $_POST['u_entrenamiento_5_6'];
    $dia = "Viernes";
    guardar_semana_mesociclo($id_planificacion, $mesociclo, $semana, $dia, $u_entrenamiento_5_1, $u_entrenamiento_5_2, $u_entrenamiento_5_3, $u_entrenamiento_5_4, $u_entrenamiento_5_5, $u_entrenamiento_5_6);
    /*Sabado*/
    $u_entrenamiento_6_1 = $_POST['u_entrenamiento_6_1'];
    $u_entrenamiento_6_2 = $_POST['u_entrenamiento_6_3'];
    $u_entrenamiento_6_3 = $_POST['u_entrenamiento_6_5'];
    $u_entrenamiento_6_4 = $_POST['u_entrenamiento_6_2'];
    $u_entrenamiento_6_5 = $_POST['u_entrenamiento_6_4'];
    $u_entrenamiento_6_6 = $_POST['u_entrenamiento_6_6'];
    $dia = "Sábado";
    guardar_semana_mesociclo($id_planificacion, $mesociclo, $semana, $dia, $u_entrenamiento_6_1, $u_entrenamiento_6_2, $u_entrenamiento_6_3, $u_entrenamiento_6_4, $u_entrenamiento_6_5, $u_entrenamiento_6_6);
    /*Domingo*/
    $u_entrenamiento_7_1 = $_POST['u_entrenamiento_7_1'];
    $u_entrenamiento_7_2 = $_POST['u_entrenamiento_7_3'];
    $u_entrenamiento_7_3 = $_POST['u_entrenamiento_7_5'];
    $u_entrenamiento_7_4 = $_POST['u_entrenamiento_7_2'];
    $u_entrenamiento_7_5 = $_POST['u_entrenamiento_7_4'];
    $u_entrenamiento_7_6 = $_POST['u_entrenamiento_7_6'];
    $dia = "Domingo";
    guardar_semana_mesociclo($id_planificacion, $mesociclo, $semana, $dia, $u_entrenamiento_7_1, $u_entrenamiento_7_2, $u_entrenamiento_7_3, $u_entrenamiento_7_4, $u_entrenamiento_7_5, $u_entrenamiento_7_6);

    echo '<script>window.location.assign("../semanas_entrenamiento.php");</script>';
?>