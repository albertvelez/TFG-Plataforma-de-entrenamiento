<?php
    session_start();
    require("../model/model.php");

    $user = $_POST['user'];
    $pass = $_POST['pass'];

    $tipo = loginUser($user, $pass);

    if($tipo == 1){ //Adimnistrador
    	$_SESSION['entrenador'] = $user;
        echo '<script>window.location.assign("../index.php");</script>';
    }

    if($tipo == 2 || $tipo == 4 || $tipo == 5){ //Errores
        echo '<script>window.location.assign("../index.php");</script>';
    }

    if($tipo == 3){ //Atleta
    	$_SESSION['atleta'] = $user;
    	echo '<script>window.location.assign("../index.php");</script>';
    }
?>