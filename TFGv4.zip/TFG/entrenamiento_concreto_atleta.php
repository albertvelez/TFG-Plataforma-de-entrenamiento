<?php session_start(); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- CSS -->
    <style>
     /*header {padding: 154px 0 100px;}*/
     section {padding: 100px 0;}
     .slider{
        background: url("images/hj1.jpg");
        height: 50vh;
        background-size: cover;
        background-position: center;
      }
    </style>

    <title>Plataforma de Entrenamiento</title>
  </head>
  <body>

    <?php require("./view/vistaNav.php"); ?>
    <?php require("./controller/controllerEntrenamiento_concreto_atleta.php"); ?>

    <section id="entrenamientos">
      <div class="container">
        <div class="row">
          <div class="col mx-auto bg-light">
            </br>
              <h3>Entrenamiento - <?php echo $fecha ?></h3>
              <h4>Semana <?php echo $semana ?></h4>
              <h4><?php echo $dia ?></h4>
            </br>
              <h5><u>Sesión: Mañana</u></h5>
              <p><?php if($u1 != '---'){echo $u1;}?></p>
              <p><?php if($u2 != '---'){echo $u2;}?></p>
              <p><?php if($u3 != '---'){echo $u3;}?></p>
            </br>
              <h5><u>Sesión: Tarde</u></h5>
              <p><?php if($u4 != '---'){echo $u4;}?></p>
              <p><?php if($u5 != '---'){echo $u5;}?></p>
              <p><?php if($u6 != '---'){echo $u6;}?></p>
            </br>
            </br>
            <?php if($count != 0){ ?>
            <div class="col-12 col-sm-12 col-md-10 col-lg-6">
            <div class="table-responsive">
            <table class="table table-sm table-bordered text-center">
              <caption>Tabla RM (test <?php echo $fecha_test;?>)</caption>
              <thead class="thead-dark">
                <tr>
                  <th scope="col">RM</th>
                  <th scope="col">Arrancada</th>
                  <th scope="col">Cargada</th>
                  <th scope="col">Sent.-40</th>
                  <th scope="col">Sent.-40+3d</th>
                  <th scope="col">Pectoral</th>
                </tr>
              </thead>
              <tbody>
                  <tr>
                    <td>1</td>
                    <td><?php $rm1_arr = $kg_arr/(1.0278-0.0278*$rep_arr); echo round($rm1_arr, 1)?></td>
                    <td><?php $rm1_car = $kg_car/(1.0278-0.0278*$rep_car); echo round($rm1_car, 1)?></td>
                    <td><?php $rm1_sen = $kg_sen/(1.0278-0.0278*$rep_sen); echo round($rm1_sen, 1)?></td>
                    <td><?php $rm1_sen3 = $kg_sen3/(1.0278-0.0278*$rep_sen3); echo round($rm1_sen3, 1)?></td>
                    <td><?php $rm1_pec = $kg_pec/(1.0278-0.0278*$rep_pec); echo round($rm1_pec, 1)?></td>
                  </tr>
                  <?php for($i=1; $i < 11; $i++){ ?>
                  <tr>
                    <?php if($i < 8 ){ ?>
                    <td><?php echo $i+1; ?></td>
                    <?php } ?>
                    <?php if($i == 8 ){ ?>
                    <td><?php echo $i+2; ?></td>
                    <?php } ?>
                    <?php if($i == 9 ){ ?>
                    <td><?php echo $i+3; ?></td>
                    <?php } ?>
                    <?php if($i == 10 ){ ?>
                    <td><?php echo $i+4; ?></td>
                    <?php } ?>
                    <td><?php $rm_arr = $rm1_arr*$array[$i]; echo round($rm_arr, 1)?></td>
                    <td><?php $rm_car = $rm1_car*$array[$i]; echo round($rm_car, 1)?></td>
                    <td><?php $rm_sen = $rm1_sen*$array[$i]; echo round($rm_sen, 1)?></td>
                    <td><?php $rm_sen3 = $rm1_sen3*$array[$i]; echo round($rm_sen3, 1)?></td>
                    <td><?php $rm_pec = $rm1_pec*$array[$i]; echo round($rm_pec, 1)?></td>
                  </tr>
                  <?php } ?>
              </tbody>
            </table>
            </div>
            </div>
            <?php } ?>
            </br>
          </div>
        </div>
      </div>
    </section>

    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Plataforma de Entrenamiento 2018</p>
      </div>
    </footer>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>