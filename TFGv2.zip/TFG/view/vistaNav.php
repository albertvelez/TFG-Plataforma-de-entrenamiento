<nav class="navbar navbar-dark bg-dark navbar-expand-lg fixed-top">
  <a class="navbar-brand" href="index.php">
    <img src="images/logo.png" width="30" height="30" class="d-inline-block align-top" alt="Logo">
    Entrenamiento
  </a>
      
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
      
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
    <ul class="navbar-nav mr-auto ml-auto text-center">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Inicio</a>
      </li>
      <?php if(isset($_SESSION['atleta'])){?>
      <li class="nav-item">
        <a class="nav-link" href="atleta.php">Atleta</a>
      </li>
      <?php } ?>
      <?php if(isset($_SESSION['entrenador'])){?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Entrenador</a>
        <div class="dropdown-menu text-center" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="entrenador.php">Perfil</a>
            <a class="dropdown-item" href="atletas_entrenador.php">Atletas</a>
            <a class="dropdown-item" href="planificacion.php">Planificación</a>
            <a class="dropdown-item" href="#">Mesociclos</a>
        </div>
      </li>
      <?php } ?>
    </ul>
    <div class="d-flex flex-row justify-content-center">
      <a href="login.php" class="btn btn-outline-success mr-2">Login</a>
      <a href="logout.php" class="btn btn-outline-danger mr-2">Logout</a>
      <a href="registro.php" class="btn btn-outline-info mr-2">Registrarse</a>
    </div>
  </div>
</nav>