<div class="row">
  <div class="col mx-auto bg-light">
    </br>
    <div class="form-group">
      <div class="form-group">
        <h4><?php echo $temporada;?> - <?php echo $periodo;?></h4>
      </div>  
      <?php if($prep_general!=0){?>
      </br>
      <div class="form-group">
        <h5><u>Preparación General</u></h5>
      </div>
      <?php } ?>
      <?php if($p_marcha!=0){?>
      <div class="form-group">
          <h7><u>Puesta en marcha</u></h7>
      </div>
      <?php foreach($volumen as $volumen){?>      
      <?php if($volumen['Mesociclo'] == "Puesta en marcha"){?>
        <div class="row">
          <div class="col-1">
            <div id="semana">
              <h6>Sem. <?php echo $volumen['Semana'];?></h6>
            </div>
          </div>
          <div class="col-9">
            <div id="volumen">
              <div class="progress">
                <?php if($int_p_marcha == 1){$color = "bg-warning";}?><?php if($int_p_marcha == 2){$color = "bg-success";}?><?php if($int_p_marcha == 3){$color = "bg-info";}?><?php if($int_p_marcha == 4){$color = "";}?><?php if($int_p_marcha == 5){$color = "bg-danger";}?>
                <div class="progress-bar progress-bar-striped progress-bar-animated <?php echo $color;?>" role="progressbar" style="width: <?php echo $volumen['Volumen'];?>%" aria-valuenow="<?php echo $volumen['Volumen'];?>" aria-valuemin="0" aria-valuemax="100"><?php echo $volumen['Volumen'];?>%</div>
              </div>
            </div>
          </div>
          <div class="col-2">
            <a title="Edita las unidades de entrenamiento de la semana" class="btn btn-primary btn-sm mb-1" href="semana.php?id=<?php echo $id;?>&temporada=<?php echo $temporada;?>&periodo=<?php echo $periodo;?>&mesociclo=<?php echo $volumen['Mesociclo'];?>&semana=<?php echo $volumen['Semana'];?>" role="button">+</a>
          </div>
        </div>
      <?php } ?>
      <?php } ?>
      <?php } ?>
      <?php if($a_funcional!=0){?>
      <div class="form-group">
          <h7><u>Adaptación funcional</u></h7>
      </div>
      <?php foreach($volumen1 as $volumen1){?>      
      <?php if($volumen1['Mesociclo'] == "Adaptación funcional"){?>
        <div class="row">
          <div class="col-1">
            <div id="semana">
              <h6>Sem. <?php echo $volumen1['Semana'];?></h6>
            </div>
          </div>
          <div class="col-9">
            <div id="volumen">
              <div class="progress">
                <?php if($int_a_funcional == 1){$color = "bg-warning";}?><?php if($int_a_funcional == 2){$color = "bg-success";}?><?php if($int_a_funcional == 3){$color = "bg-info";}?><?php if($int_a_funcional == 4){$color = "";}?><?php if($int_a_funcional == 5){$color = "bg-danger";}?>
                <div class="progress-bar progress-bar-striped progress-bar-animated <?php echo $color;?>" role="progressbar" style="width: <?php echo $volumen1['Volumen'];?>%" aria-valuenow="<?php echo $volumen1['Volumen'];?>" aria-valuemin="0" aria-valuemax="100"><?php echo $volumen1['Volumen'];?>%</div>
              </div>
            </div>
          </div>
          <div class="col-2">
            <a title="Edita las unidades de entrenamiento de la semana" class="btn btn-primary btn-sm mb-1" href="semana.php?id=<?php echo $id;?>&temporada=<?php echo $temporada;?>&periodo=<?php echo $periodo;?>&mesociclo=<?php echo $volumen1['Mesociclo'];?>&semana=<?php echo $volumen1['Semana'];?>" role="button">+</a>
          </div>
        </div>
      <?php } ?>
      <?php } ?>
      <?php } ?>
      </br>  
      <?php if($prep_especial!=0){?>
      <div class="form-group">
        <h5><u>Preparación Especial</u></h5>
      </div>
      <?php } ?>
      <?php if($fuerza!=0){?>
      <div class="form-group">
          <h7><u>Fuerza</u></h7>
      </div>
      <?php foreach($volumen2 as $volumen2){?>      
      <?php if($volumen2['Mesociclo'] == "Fuerza"){?>
        <div class="row">
          <div class="col-1">
            <div id="semana">
              <h6>Sem. <?php echo $volumen2['Semana'];?></h6>
            </div>
          </div>
          <div class="col-9">
            <div id="volumen">
              <div class="progress">
                <?php if($int_fuerza == 1){$color = "bg-warning";}?><?php if($int_fuerza == 2){$color = "bg-success";}?><?php if($int_fuerza == 3){$color = "bg-info";}?><?php if($int_fuerza == 4){$color = "";}?><?php if($int_fuerza == 5){$color = "bg-danger";}?>
                <div class="progress-bar progress-bar-striped progress-bar-animated <?php echo $color;?>" role="progressbar" style="width: <?php echo $volumen2['Volumen'];?>%" aria-valuenow="<?php echo $volumen2['Volumen'];?>" aria-valuemin="0" aria-valuemax="100"><?php echo $volumen2['Volumen'];?>%</div>
              </div>
            </div>
          </div>
          <div class="col-2">
            <a title="Edita las unidades de entrenamiento de la semana" class="btn btn-primary btn-sm mb-1" href="semana.php?id=<?php echo $id;?>&temporada=<?php echo $temporada;?>&periodo=<?php echo $periodo;?>&mesociclo=<?php echo $volumen2['Mesociclo'];?>&semana=<?php echo $volumen2['Semana'];?>" role="button">+</a>
          </div>
        </div>
      <?php } ?>
      <?php } ?>
      <?php } ?>
      <?php if($f_velocidad!=0){?>
      <div class="form-group">
          <h7><u>Fuerza velocidad</u></h7>
      </div>
      <?php foreach($volumen3 as $volumen3){?>      
      <?php if($volumen3['Mesociclo'] == "Fuerza velocidad"){?>
        <div class="row">
          <div class="col-1">
            <div id="semana">
              <h6>Sem. <?php echo $volumen3['Semana'];?></h6>
            </div>
          </div>
          <div class="col-9">
            <div id="volumen">
              <div class="progress">
                <?php if($int_f_velocidad == 1){$color = "bg-warning";}?><?php if($int_f_velocidad == 2){$color = "bg-success";}?><?php if($int_f_velocidad == 3){$color = "bg-info";}?><?php if($int_f_velocidad == 4){$color = "";}?><?php if($int_f_velocidad == 5){$color = "bg-danger";}?>
                <div class="progress-bar progress-bar-striped progress-bar-animated <?php echo $color;?>" role="progressbar" style="width: <?php echo $volumen3['Volumen'];?>%" aria-valuenow="<?php echo $volumen3['Volumen'];?>" aria-valuemin="0" aria-valuemax="100"><?php echo $volumen3['Volumen'];?>%</div>
              </div>
            </div>
          </div>
          <div class="col-2">
            <a title="Edita las unidades de entrenamiento de la semana" class="btn btn-primary btn-sm mb-1" href="semana.php?id=<?php echo $id;?>&temporada=<?php echo $temporada;?>&periodo=<?php echo $periodo;?>&mesociclo=<?php echo $volumen3['Mesociclo'];?>&semana=<?php echo $volumen3['Semana'];?>" role="button">+</a>
          </div>
        </div>
      <?php } ?>
      <?php } ?>
      <?php } ?>
      </br>  
      <?php if($prep_tecnica!=0){?>
      <div class="form-group">
        <h5><u>Preparación Técnica</u></h5>
      </div>
      <?php } ?>
      <?php if($v_tecnica!=0){?>
      <div class="form-group">
          <h7><u>Velocidad técnica</u></h7>
      </div>
      <?php foreach($volumen4 as $volumen4){?>      
      <?php if($volumen4['Mesociclo'] == "Velocidad técnica"){?>
        <div class="row">
          <div class="col-1">
            <div id="semana">
              <h6>Sem. <?php echo $volumen4['Semana'];?></h6>
            </div>
          </div>
          <div class="col-9">
            <div id="volumen">
              <div class="progress">
                <?php if($int_v_tecnica == 1){$color = "bg-warning";}?><?php if($int_v_tecnica == 2){$color = "bg-success";}?><?php if($int_v_tecnica == 3){$color = "bg-info";}?><?php if($int_v_tecnica == 4){$color = "";}?><?php if($int_v_tecnica == 5){$color = "bg-danger";}?>
                <div class="progress-bar progress-bar-striped progress-bar-animated <?php echo $color;?>" role="progressbar" style="width: <?php echo $volumen4['Volumen'];?>%" aria-valuenow="<?php echo $volumen4['Volumen'];?>" aria-valuemin="0" aria-valuemax="100"><?php echo $volumen4['Volumen'];?>%</div>
              </div>
            </div>
          </div>
          <div class="col-2">
            <a title="Edita las unidades de entrenamiento de la semana" class="btn btn-primary btn-sm mb-1" href="semana.php?id=<?php echo $id;?>&temporada=<?php echo $temporada;?>&periodo=<?php echo $periodo;?>&mesociclo=<?php echo $volumen4['Mesociclo'];?>&semana=<?php echo $volumen4['Semana'];?>" role="button">+</a>
          </div>
        </div>
      <?php } ?>
      <?php } ?>
      <?php } ?>
      <?php if($m_competitiva!=0){?>
      <div class="form-group">
          <h7><u>Modelación competitiva</u></h7>
      </div>
      <?php foreach($volumen5 as $volumen5){?>      
      <?php if($volumen5['Mesociclo'] == "Modelación competitiva"){?>
        <div class="row">
          <div class="col-1">
            <div id="semana">
              <h6>Sem. <?php echo $volumen5['Semana'];?></h6>
            </div>
          </div>
          <div class="col-9">
            <div id="volumen">
              <div class="progress">
                <?php if($int_m_competitiva == 1){$color = "bg-warning";}?><?php if($int_m_competitiva == 2){$color = "bg-success";}?><?php if($int_m_competitiva == 3){$color = "bg-info";}?><?php if($int_m_competitiva == 4){$color = "";}?><?php if($int_m_competitiva == 5){$color = "bg-danger";}?>
                <div class="progress-bar progress-bar-striped progress-bar-animated <?php echo $color;?>" role="progressbar" style="width: <?php echo $volumen5['Volumen'];?>%" aria-valuenow="<?php echo $volumen5['Volumen'];?>" aria-valuemin="0" aria-valuemax="100"><?php echo $volumen5['Volumen'];?>%</div>
              </div>
            </div>
          </div>
          <div class="col-2">
            <a title="Edita las unidades de entrenamiento de la semana" class="btn btn-primary btn-sm mb-1" href="semana.php?id=<?php echo $id;?>&temporada=<?php echo $temporada;?>&periodo=<?php echo $periodo;?>&mesociclo=<?php echo $volumen5['Mesociclo'];?>&semana=<?php echo $volumen5['Semana'];?>" role="button">+</a>
          </div>
        </div>
      <?php } ?>
      <?php } ?>
      <?php } ?>
      </br>  
      <?php if($per_competitivo!=0){?>
      <div class="form-group">
        <h5><u>Periodo Competitivo</u></h5>
      </div>
      <?php } ?>
      <?php if($competitivo!=0){?>
      <div class="form-group">
          <h7><u>Competitivo</u></h7>
      </div>
      <?php foreach($volumen6 as $volumen6){?>      
      <?php if($volumen6['Mesociclo'] == "Competitivo"){?>
        <div class="row">
          <div class="col-1">
            <div id="semana">
              <h6>Sem. <?php echo $volumen6['Semana'];?></h6>
            </div>
          </div>
          <div class="col-9">
            <div id="volumen">
              <div class="progress">
                <?php if($int_competitivo == 1){$color = "bg-warning";}?><?php if($int_competitivo == 2){$color = "bg-success";}?><?php if($int_competitivo == 3){$color = "bg-info";}?><?php if($int_competitivo == 4){$color = "";}?><?php if($int_competitivo == 5){$color = "bg-danger";}?>
                <div class="progress-bar progress-bar-striped progress-bar-animated <?php echo $color;?>" role="progressbar" style="width: <?php echo $volumen6['Volumen'];?>%" aria-valuenow="<?php echo $volumen6['Volumen'];?>" aria-valuemin="0" aria-valuemax="100"><?php echo $volumen6['Volumen'];?>%</div>
              </div>
            </div>
          </div>
          <div class="col-2">
            <a title="Edita las unidades de entrenamiento de la semana" class="btn btn-primary btn-sm mb-1" href="semana.php?id=<?php echo $id;?>&temporada=<?php echo $temporada;?>&periodo=<?php echo $periodo;?>&mesociclo=<?php echo $volumen6['Mesociclo'];?>&semana=<?php echo $volumen6['Semana'];?>" role="button">+</a>
          </div>
        </div>
      <?php } ?>
      <?php } ?>
      <?php } ?>
    </div>
  </div>
</div>

