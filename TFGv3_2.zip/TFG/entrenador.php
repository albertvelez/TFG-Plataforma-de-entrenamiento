<?php session_start(); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- CSS -->
    <style>
     /*header {padding: 154px 0 100px;}*/
     section {padding: 100px 0;}
     .slider{
        background: url("images/hj1.jpg");
        height: 50vh;
        background-size: cover;
        background-position: center;
      }
     .imgProd{
        height: 200px;
        width: 200px;
        min-height: 100px;
        min-width: 100px;
      }
    </style>

    <title>Plataforma de Entrenamiento</title>
  </head>
  <body>

    /*<?php require("./view/vistaNav.php"); ?>*/
    <?php require("./controller/controllerEntrenador.php"); ?>

    <section class="container-fluid slider d-flex justify-content-center align-items-center">
    </section>

    <section id="perfil">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-3 text-center">
            <img src="images/Miklos.jpg" class="img-thumbnail imgProd">
          </div>
          <div class="col-lg-4 text-left mt-10 mb-10">
            <h4><?php echo $nombre;?> <?php echo $apellidos;?></h4>
            <p class="lead"><b><?php echo $sector;?> (<?php echo $especialidad;?>)</b></p>
            <p><b>Club/Organizacion: </b> <?php echo $club_organizacion;?></p>
            <p><b>Titulación: </b> <?php echo $titulacion;?></p>
          </div>
          <div class="col-lg-3 text-center">
            <div class="form-group">
              <a class="btn btn-primary btn-block" href="atletas_entrenador.php" role="button">Atletas</a>
            </div>
            <div class="form-group">
              <a class="btn btn-primary btn-block" href="planificacion.php" role="button">Planificación</a>
            </div>
            <div class="form-group">
              <a class="btn btn-primary btn-block" href="semanas_entrenamiento.php" role="button">Semanas</a>
            </div>
            <div class="form-group">
              <a class="btn btn-primary btn-block" href="entrenamientos.php" role="button">Entrenamientos</a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Plataforma de Entrenamiento 2018</p>
      </div>
    </footer>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>