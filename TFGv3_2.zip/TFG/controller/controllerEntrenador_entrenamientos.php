<?php
	require("./model/model.php");

	$user = $_SESSION['entrenador'];

	$datos_entrenamientos = datos_entrenamientos_user($user);  
	      
	$entrenamientos = array();

	while($row = $datos_entrenamientos->fetch_assoc()) {
		$entrenamientos[]= $row;
	}
?>