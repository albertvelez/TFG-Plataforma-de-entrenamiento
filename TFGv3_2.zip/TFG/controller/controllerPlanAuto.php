<?php
    session_start();
    require("../model/model.php");

    if(isset($_SESSION['entrenador'])){

        $id_entrenador = $_SESSION['entrenador'];
        $nombre = test_input($_POST['nombre']);
        $temporada = $_POST['temporada'];
        $periodo = $_POST['periodo'];
        $competitivo = $_POST['competitivo'];
        $variabilidad = $_POST['variabilidad'];
        
        $per_competitivo = 1;
        $prep_tecnica = 1;
        $prep_especial = 1;
        
        $puesta_marcha = 0;
        $adaptacion_funcional = 0;
        $intensidad_puesta_marcha = 0;
        $intensidad_adaptacion_funcional = 0;
        $prep_general = 0;
        
        $intensidad_fuerza = 2;
        $intensidad_fuerza_velocidad = 3;
        $intensidad_velocidad_tecnica = 4;
        $intensidad_mod_competitiva = 4;
        $intensidad_competitivo = 5;


        if($competitivo == 3 || $competitivo == 4){

            if($periodo == "Pista cubierta"){
                $puesta_marcha = 2;
                $adaptacion_funcional = 2;
                $intensidad_puesta_marcha = 1;
                $intensidad_adaptacion_funcional = 1;
                $prep_general = 1;

                $velocidad_tecnica = 2;
                $mod_competitiva = 0;
                $intensidad_mod_competitiva = 0;

                if($variabilidad == 1){
                    $array1 = array(50, 60);
                    $array2 = array(70, 80);
                    $array3 = array(90, 100, 100);
                    $array4 = array(100, 100, 90);
                    $array5 = array(80, 60);
                }else{
                    $array1 = array(50, 70);
                    $array2 = array(90, 50);
                    $array3 = array(70, 100, 80);
                    $array4 = array(70, 100, 80);
                    $array5 = array(90, 60);
                }
            }

            if($periodo == "Aire libre"){
                $velocidad_tecnica = 3;
                $mod_competitiva = 2;

                if($variabilidad == 1){
                    $array3 = array(70, 80, 90);
                    $array4 = array(100, 100, 100);
                    $array5 = array(90, 90, 80);
                    $array6 = array(70, 50);
                }else{
                    $array3 = array(70, 90, 100);
                    $array4 = array(70, 100, 80);
                    $array5 = array(100, 70, 80);
                    $array6 = array(70, 50);
                }
            }
            
            $fuerza = 3;
            $fuerza_velocidad = 3;
            if($competitivo == 3){
                $array7 = array(40, 40, 40);}
            if($competitivo == 4){
                $array7 = array(40, 40, 40, 40);}
            
            guardar_planificacion($nombre, $id_entrenador, $temporada, $periodo, $puesta_marcha, $adaptacion_funcional, $intensidad_puesta_marcha, $intensidad_adaptacion_funcional, $prep_general, $fuerza, $fuerza_velocidad, $intensidad_fuerza, $intensidad_fuerza_velocidad, $prep_especial, $velocidad_tecnica, $mod_competitiva, $intensidad_velocidad_tecnica, $intensidad_mod_competitiva, $prep_tecnica, $competitivo, $intensidad_competitivo, $per_competitivo);   
        }

        if($competitivo == 5 || $competitivo == 6){

            if($periodo == "Pista cubierta"){
                $puesta_marcha = 2;
                $adaptacion_funcional = 3;
                $intensidad_puesta_marcha = 1;
                $intensidad_adaptacion_funcional = 1;
                $prep_general = 1;

                $velocidad_tecnica = 3;
                $mod_competitiva = 0;
                $intensidad_mod_competitiva = 0;

                if($variabilidad == 1){
                    $array1 = array(50, 60);
                    $array2 = array(70, 80, 90);
                    $array3 = array(100, 100, 100, 100);
                    $array4 = array(100, 90, 90);
                    $array5 = array(80, 70, 60);
                }else{
                    $array1 = array(50, 60);
                    $array2 = array(70, 90, 50);
                    $array3 = array(70, 100, 90, 50);
                    $array4 = array(70, 100, 80);
                    $array5 = array(90, 70, 60);
                }
            }

            if($periodo == "Aire libre"){
                $velocidad_tecnica = 3;
                $mod_competitiva = 2;

                if($variabilidad == 1){
                    $array3 = array(70, 80, 90, 100);
                    $array4 = array(100, 100, 100);
                    $array5 = array(90, 90, 80);
                    $array6 = array(70, 50);
                }else{
                    $array3 = array(70, 90, 100, 50);
                    $array4 = array(70, 100, 80);
                    $array5 = array(100, 70, 80);
                    $array6 = array(70, 50);
                }
            }
            
            $fuerza = 4;
            $fuerza_velocidad = 3;
            if($competitivo == 5){
                $array7 = array(40, 40, 40, 40, 40);}
            if($competitivo == 6){
                $array7 = array(40, 40, 40, 40, 40, 40);}
            
            guardar_planificacion($nombre, $id_entrenador, $temporada, $periodo, $puesta_marcha, $adaptacion_funcional, $intensidad_puesta_marcha, $intensidad_adaptacion_funcional, $prep_general, $fuerza, $fuerza_velocidad, $intensidad_fuerza, $intensidad_fuerza_velocidad, $prep_especial, $velocidad_tecnica, $mod_competitiva, $intensidad_velocidad_tecnica, $intensidad_mod_competitiva, $prep_tecnica, $competitivo, $intensidad_competitivo, $per_competitivo);   
        }

        if($competitivo == 7 || $competitivo == 8){

            if($periodo == "Pista cubierta"){
                $puesta_marcha = 2;
                $adaptacion_funcional = 4;
                $intensidad_puesta_marcha = 1;
                $intensidad_adaptacion_funcional = 1;
                $prep_general = 1;

                $velocidad_tecnica = 3;
                $mod_competitiva = 0;
                $intensidad_mod_competitiva = 0;

                if($variabilidad == 1){
                    $array1 = array(50, 60);
                    $array2 = array(70, 80, 90, 90);
                    $array3 = array(100, 100, 100, 100);
                    $array4 = array(100, 100, 90, 90);
                    $array5 = array(80, 70, 60);
                }else{
                    $array1 = array(50, 60);
                    $array2 = array(70, 80, 90, 50);
                    $array3 = array(70, 100, 90, 50);
                    $array4 = array(70, 100, 80, 50);
                    $array5 = array(90, 70, 60);
                }
            }

            if($periodo == "Aire libre"){
                $velocidad_tecnica = 3;
                $mod_competitiva = 3;

                if($variabilidad == 1){
                    $array3 = array(70, 80, 90, 100);
                    $array4 = array(100, 100, 100, 100);
                    $array5 = array(90, 90, 80);
                    $array6 = array(70, 60, 50);
                }else{
                    $array3 = array(70, 90, 100, 50);
                    $array4 = array(70, 100, 80, 50);
                    $array5 = array(100, 70, 80);
                    $array6 = array(70, 60, 50);
                }
            }
            
            $fuerza = 4;
            $fuerza_velocidad = 4;
            if($competitivo == 7){
                $array7 = array(40, 40, 40, 40, 40, 40, 40);}
            if($competitivo == 8){
                $array7 = array(40, 40, 40, 40, 40, 40, 40, 40);}
            
            guardar_planificacion($nombre, $id_entrenador, $temporada, $periodo, $puesta_marcha, $adaptacion_funcional, $intensidad_puesta_marcha, $intensidad_adaptacion_funcional, $prep_general, $fuerza, $fuerza_velocidad, $intensidad_fuerza, $intensidad_fuerza_velocidad, $prep_especial, $velocidad_tecnica, $mod_competitiva, $intensidad_velocidad_tecnica, $intensidad_mod_competitiva, $prep_tecnica, $competitivo, $intensidad_competitivo, $per_competitivo);   
        }

        if($competitivo == 9 || $competitivo == 10){

            if($periodo == "Pista cubierta"){
                $puesta_marcha = 2;
                $adaptacion_funcional = 4;
                $intensidad_puesta_marcha = 1;
                $intensidad_adaptacion_funcional = 1;
                $prep_general = 1;

                $velocidad_tecnica = 4;
                $mod_competitiva = 0;
                $intensidad_mod_competitiva = 0;

                if($variabilidad == 1){
                    $array1 = array(50, 60);
                    $array2 = array(70, 80, 90, 90);
                    $array3 = array(100, 100, 100, 100);
                    $array4 = array(100, 100, 90, 90);
                    $array5 = array(80, 70, 60, 50);
                }else{
                    $array1 = array(50, 60);
                    $array2 = array(70, 80, 90, 50);
                    $array3 = array(70, 100, 90, 50);
                    $array4 = array(70, 100, 80, 50);
                    $array5 = array(90, 60, 80, 50);
                }
            }

            if($periodo == "Aire libre"){
                $velocidad_tecnica = 4;
                $mod_competitiva = 3;

                if($variabilidad == 1){
                    $array3 = array(70, 80, 90, 100);
                    $array4 = array(100, 100, 100, 100);
                    $array5 = array(100, 90, 90, 80);
                    $array6 = array(70, 60, 50);
                }else{
                    $array3 = array(70, 90, 100, 50);
                    $array4 = array(70, 100, 80, 50);
                    $array5 = array(100, 70, 90, 50);
                    $array6 = array(70, 60, 50);
                }
            }
            
            $fuerza = 4;
            $fuerza_velocidad = 4;
            if($competitivo == 9){
                $array7 = array(40, 40, 40, 40, 40, 40, 40, 40, 40);}
            if($competitivo == 10){
                $array7 = array(40, 40, 40, 40, 40, 40, 40, 40, 40, 40);}
            
            guardar_planificacion($nombre, $id_entrenador, $temporada, $periodo, $puesta_marcha, $adaptacion_funcional, $intensidad_puesta_marcha, $intensidad_adaptacion_funcional, $prep_general, $fuerza, $fuerza_velocidad, $intensidad_fuerza, $intensidad_fuerza_velocidad, $prep_especial, $velocidad_tecnica, $mod_competitiva, $intensidad_velocidad_tecnica, $intensidad_mod_competitiva, $prep_tecnica, $competitivo, $intensidad_competitivo, $per_competitivo);   
        }    
            

            $id_planificacion = id_planificacion();
            $i = 1;

            if(isset($array1)){
                $ciclo = "Preparación General";
                $mesociclo = "Puesta en marcha";
                for($j=0; $j<count($array1); $j++){
                    $volumen = $array1[$j];
                    guardar_volumen($id_planificacion, $ciclo, $mesociclo, $i, $volumen);
                    $i++;
                }
            }

            if(isset($array2)){
                $ciclo = "Preparación General";
                $mesociclo = "Adaptación funcional";
                for($j=0; $j<count($array2); $j++){
                    $volumen = $array2[$j];
                    guardar_volumen($id_planificacion, $ciclo, $mesociclo, $i, $volumen);
                    $i++;
                }
            }

            if(isset($array3)){
                $ciclo = "Preparación Especial";
                $mesociclo = "Fuerza";
                for($j=0; $j<count($array3); $j++){
                    $volumen = $array3[$j];
                    guardar_volumen($id_planificacion, $ciclo, $mesociclo, $i, $volumen);
                    $i++;
                }
            }

            if(isset($array4)){
                $ciclo = "Preparación Especial";
                $mesociclo = "Fuerza velocidad";
                for($j=0; $j<count($array4); $j++){
                    $volumen = $array4[$j];
                    guardar_volumen($id_planificacion, $ciclo, $mesociclo, $i, $volumen);
                    $i++;
                }
            }

            if(isset($array5)){
                $ciclo = "Preparación Técnica";
                $mesociclo = "Velocidad técnica";
                for($j=0; $j<count($array5); $j++){
                    $volumen = $array5[$j];
                    guardar_volumen($id_planificacion, $ciclo, $mesociclo, $i, $volumen);
                    $i++;
                }
            }

            if(isset($array6)){
                $ciclo = "Preparación Técnica";
                $mesociclo = "Modelación competitiva";
                for($j=0; $j<count($array6); $j++){
                    $volumen = $array6[$j];
                    guardar_volumen($id_planificacion, $ciclo, $mesociclo, $i, $volumen);
                    $i++;
                }
            }

            if(isset($array7)){
                $ciclo = "Periodo Competitivo";
                $mesociclo = "Competitivo";
                for($j=0; $j<count($array7); $j++){
                    $volumen = $array7[$j];
                    guardar_volumen($id_planificacion, $ciclo, $mesociclo, $i, $volumen);
                    $i++;
                }
            }

        echo '<script>window.location.assign("../planificacion.php");</script>';

    }else{
        echo "<script>alert('Para hacer una planificacion necesitas ser entrenador');</script>";
        echo '<script>window.location.assign("../login.php");</script>';
    }     

 
    function test_input($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

?>