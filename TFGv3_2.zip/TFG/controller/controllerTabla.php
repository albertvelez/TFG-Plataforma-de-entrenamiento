<?php
	session_start();
	require("../model/model.php");

	$id = $_GET['id'];
	$valor = $_GET['valor'];
	$user = $_SESSION['entrenador'];

	if($id == 0){

	}else{

		/*echo $id;
		echo "_";
		echo $valor;*/

		$semana_concreta = datos_semana_concreta($id, $valor);  
	      
	    $semana = array();

		while($row = $semana_concreta->fetch_assoc()) {
			$semana[]= $row;
	    }

	    require("../view/vistaTabla.php");
	}
?>