<?php
	require("../model/model.php");

	$id = $_GET['id'];
	$semana = $_GET['semana'];
	$user = $_GET['user'];
	$dia = $_GET['dia'];
	$atletas = $_GET['atletas'];

	/*$arrayatletas = preg_split('/,/', $atletas, -1, PREG_SPLIT_NO_EMPTY);*/

	$datos_dia_semana = datos_dia_semana($id, $dia, $semana);
	$datos_volumen_semana = datos_volumen_semana($id, $semana);

	while($obj = $datos_dia_semana->fetch_object()){
	    $dato = $obj;
	}

	while($obj2 = $datos_volumen_semana->fetch_object()){
	    $volumen1 = $obj2;
	}
	
	$mesociclo = $dato->Mesociclo;
	$U_entrenamiento1 = $dato->U_entrenamiento1;
	$U_entrenamiento2 =  $dato->U_entrenamiento2;
	$U_entrenamiento3 = $dato->U_entrenamiento3;
	$U_entrenamiento4 = $dato->U_entrenamiento4;
	$U_entrenamiento5 = $dato->U_entrenamiento5;
	$U_entrenamiento6 = $dato->U_entrenamiento6;
	$volumen = $volumen1->Volumen;

	$unidad = array($U_entrenamiento1, $U_entrenamiento2, $U_entrenamiento3, $U_entrenamiento4, $U_entrenamiento5, $U_entrenamiento6);

	/*echo $id."<br>";
	echo $semana."<br>";
	echo $user."<br>";
	echo $dia."<br>";
	echo $atletas."<br>";
	print_r($arrayatletas);
	echo "<br>";
	echo $mesociclo."<br>";
	echo $U_entrenamiento1."<br>";
	echo $U_entrenamiento2."<br>";
	echo $U_entrenamiento3."<br>";
	echo $U_entrenamiento4."<br>";
	echo $U_entrenamiento5."<br>";
	echo $U_entrenamiento6."<br>";
	echo $volumen."<br><br>";

	for ($i = 0; $i < 6; $i++) {

		if($unidad[$i] == 'MN'){
			$mn_ejercicios = mn_ejercicios();
			$mn_repeticiones = mn_repeticiones($mesociclo);

			$mn_ej = array();
			$mn_rep = array();

			while($row = $mn_ejercicios->fetch_assoc()) {
				$mn_ej[]= $row;
		    }
		    while($row = $mn_repeticiones->fetch_assoc()) {
				$mn_rep[]= $row;
		    }

		    foreach($mn_ej as $mn_ej){ 
        		echo $mn_ej['Ejercicio']."<br>";
			}
			foreach($mn_rep as $mn_rep){ 
        		echo $mn_rep['Series']." x ".$mn_rep['Repeticiones']." recuperación: ".$mn_rep['Recuperacion']."<br>";
			}               
		}

		if($unidad[$i] == 'ROD'){
			$rodar = min_rodar($mesociclo);

			$min_rodar = array();

			while($row = $rodar->fetch_assoc()) {
				$min_rodar[]= $row;
		    }

		    foreach($min_rodar as $min_rodar){ 
        		echo "Rodar: ".$min_rodar['Tiempo']."<br>";
			}            
		}

		if($unidad[$i] == 'MH'){
			$m_h = multi_horizontales($mesociclo, $volumen);

			$multi_horizontales = array();

			while($row = $m_h->fetch_assoc()) {
				$multi_horizontales[]= $row;
		    }

		    foreach($multi_horizontales as $multi_horizontales){
		    	echo $multi_horizontales['Ejercicio'].":  ".$multi_horizontales['Series']." x ".$multi_horizontales['Repeticiones']."<br>";
			}            
		}

		if($unidad[$i] == 'MV'){
			$m_v = multi_verticales($mesociclo, $volumen);

			$multi_verticales = array();

			while($row = $m_v->fetch_assoc()) {
				$multi_verticales[]= $row;
		    }

		    foreach($multi_verticales as $multi_verticales){
		    	echo $multi_verticales['Ejercicio'].":  ".$multi_verticales['Series']." x ".$multi_verticales['Repeticiones']."<br>";
			}            
		}

		if($unidad[$i] == 'CUE' || $unidad[$i] == 'ARR' || $unidad[$i] == 'VEL' || $unidad[$i] == 'CR'){
			$carr = carrera($mesociclo, $volumen, $unidad[$i]);

			$carrera = array();

			while($row = $carr->fetch_assoc()) {
				$carrera[]= $row;
		    }

		    if($unidad[$i] == 'ARR'){
			    foreach($carrera as $carrera){
			    	echo $carrera['Ejercicio'].":  ".$carrera['Series']." x ".$carrera['Distancia']." lastre: ".$carrera['Lastre']."kg"." recuperación: ".$carrera['Recuperacion']."<br>";
				}
			}else{
				foreach($carrera as $carrera){
			    	echo $carrera['Ejercicio'].":  ".$carrera['Series']." x ".$carrera['Distancia']." recuperación: ".$carrera['Recuperacion']."<br>";
				}
			}           
		}

		if($unidad[$i] == 'ET'){
			$ej_tec = ej_tecnicos($mesociclo, $volumen);

			$ej_tecnicos = array();

			while($row = $ej_tec->fetch_assoc()) {
				$ej_tecnicos[]= $row;
		    }

		    foreach($ej_tecnicos as $ej_tecnicos){
		    	echo $ej_tecnicos['Ejercicio'].":  ".$ej_tecnicos['Series']." x ".$ej_tecnicos['Repeticiones']."<br>";
			}            
		}

		if($unidad[$i] == 'T'){
			$tec = tecnica($mesociclo, $volumen);

			$tecnica = array();

			while($row = $tec->fetch_assoc()) {
				$tecnica[]= $row;
		    }

		    foreach($tecnica as $tecnica){
		    	echo $tecnica['Ejercicio']." x".$tecnica['Saltos']."<br>";
			}            
		}

		if($unidad[$i] == 'F'){
			$fue = fuerza($mesociclo, $volumen);

			$fuerza = array();

			while($row = $fue->fetch_assoc()) {
				$fuerza[]= $row;
		    }

		    foreach($fuerza as $fuerza){
		    	echo $fuerza['Ejercicio'].":  ".$fuerza['Series']." x ".$fuerza['Repeticiones']." x ".$fuerza['Rm']."<br>";
			}            
		}
	}*/

	require("../view/vistaEntrenamiento.php");

?>