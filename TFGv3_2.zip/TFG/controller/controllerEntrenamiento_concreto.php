<?php
	require("./model/model.php");

	$id = $_GET['id'];

	echo $id;

	$datos_entrenamientos = datos_entrenamientos_id($id);  
	      
	while($obj = $datos_entrenamientos->fetch_object()){
	    $dato = $obj;
	}

	$atletas_entrenamiento = atletas_entrenamiento_concreto($id);
	$atletas = array();

	while($row = $atletas_entrenamiento->fetch_assoc()) {
		$atletas[]= $row;
	}
	
	$fecha = $dato->Fecha;
	$id_plan =  $dato->Id_planificacion;
	$semana = $dato->Semana;
	$dia = $dato->Dia;
	$user = $dato->User;
	$u1 = $dato->U1;
	$u2 = $dato->U2;
	$u3 = $dato->U3;
	$u4 = $dato->U4;
	$u5 = $dato->U5;
	$u6 = $dato->U6;
?>