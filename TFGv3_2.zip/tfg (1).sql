-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-05-2018 a las 18:46:58
-- Versión del servidor: 5.6.17
-- Versión de PHP: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `tfg`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `atletas`
--

CREATE TABLE IF NOT EXISTS `atletas` (
  `Id` int(5) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(30) NOT NULL,
  `Apellidos` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Club_organizacion` varchar(30) NOT NULL,
  `Sector` varchar(30) NOT NULL,
  `Especialidad` varchar(30) NOT NULL,
  `Fecha` varchar(4) NOT NULL,
  `Id_entrenador` int(5) NOT NULL,
  `Usuario` varchar(30) NOT NULL,
  `Password` varchar(255) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `atletas`
--

INSERT INTO `atletas` (`Id`, `Nombre`, `Apellidos`, `Email`, `Club_organizacion`, `Sector`, `Especialidad`, `Fecha`, `Id_entrenador`, `Usuario`, `Password`) VALUES
(3, 'Albert', 'Vélez Martín', 'nuvilavelez@hotmail.com', 'F.C.Barcelona', 'Saltos', 'Salto de altura', '1988', 2, 'Nuvila', '$2y$10$yuc5ADyN6vII0r2Nm8gY/ucv4100La9.aEXTnIp13VEER72lnDqMi'),
(4, 'Miquel', 'Vélez Martín', 'michi@gmail.com', 'U.A.Terrassa', 'Saltos', 'Salto de altura', '1983', 2, 'Michi', '$2y$10$zv216IINLzRAfFZieTYqDu5bZPnS9SmUrEpO0c7vU9.XE7d7BHSKK'),
(5, 'Miguel Ángel', 'Sancho Rubio', 'sancho@gmail.com', 'Playas de Castellón', 'Saltos', 'Salto de altura', '1983', 2, 'Sancho', '$2y$10$iV6IathG6YRvt4Vahi0.8exwKOc4Yr/t0zYwgPFcxfIPKiyrotiHa'),
(6, 'Marc', 'Pagès Corella', 'marcpages@gmail.com', 'J.A.Sabadell', 'Saltos', 'Salto de altura', '1974', 2, 'Marcp', '$2y$10$NwSUVBYpY1IkeAnNkINQX.vmo8fs01vZH0f6t4Z1DiCkmGY9BDvry'),
(7, 'Alfonso', 'Badolato Martín', 'alf@gmail.com', 'Universidad de Oviedo', 'Saltos', 'Salto de altura', '1973', 3, 'Alfonso', '$2y$10$lpPEg2epUNsX1P2n2SiHAuHNnE4zjDoUqcMrc5ByeKM4sivfSTmQK');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `atletas_entrenamiento`
--

CREATE TABLE IF NOT EXISTS `atletas_entrenamiento` (
  `Id` int(5) NOT NULL AUTO_INCREMENT,
  `Id_entrenamiento` int(5) NOT NULL,
  `Id_atleta` int(5) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Volcado de datos para la tabla `atletas_entrenamiento`
--

INSERT INTO `atletas_entrenamiento` (`Id`, `Id_entrenamiento`, `Id_atleta`) VALUES
(8, 1, 3),
(9, 1, 4),
(10, 1, 5),
(11, 2, 3),
(12, 2, 4),
(13, 2, 5),
(14, 2, 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrera`
--

CREATE TABLE IF NOT EXISTS `carrera` (
  `Id` int(5) NOT NULL,
  `Mesociclo` varchar(30) NOT NULL,
  `Volumen` int(5) NOT NULL,
  `Unidad` varchar(30) NOT NULL,
  `Ejercicio` varchar(30) NOT NULL,
  `Distancia` int(5) NOT NULL,
  `Series` int(5) NOT NULL,
  `Recuperacion` varchar(30) NOT NULL,
  `Lastre` int(5) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `carrera`
--

INSERT INTO `carrera` (`Id`, `Mesociclo`, `Volumen`, `Unidad`, `Ejercicio`, `Distancia`, `Series`, `Recuperacion`, `Lastre`) VALUES
(1, 'Puesta en marcha', 40, 'CUE', 'Cuestas', 30, 2, '2min', 0),
(2, 'Puesta en marcha', 40, 'ARR', 'Arrastres', 30, 2, '2min', 5),
(3, 'Puesta en marcha', 40, 'VEL', 'Velocidad', 30, 2, '3min', 0),
(4, 'Puesta en marcha', 40, 'CR', 'Carrera repetida', 300, 2, '5min', 0),
(5, 'Puesta en marcha', 50, 'CUE', 'Cuestas', 30, 2, '2min', 0),
(6, 'Puesta en marcha', 50, 'ARR', 'Arrastres', 30, 2, '2min', 5),
(7, 'Puesta en marcha', 50, 'VEL', 'Velocidad', 50, 3, '3min', 0),
(8, 'Puesta en marcha', 50, 'CR', 'Carrera repetida', 300, 2, '5min', 0),
(9, 'Puesta en marcha', 60, 'CUE', 'Cuestas', 30, 2, '2min', 0),
(10, 'Puesta en marcha', 60, 'ARR', 'Arrastres', 30, 2, '2min', 5),
(11, 'Puesta en marcha', 60, 'VEL', 'Velocidad', 50, 3, '3min', 0),
(12, 'Puesta en marcha', 60, 'CR', 'Carrera repetida', 300, 2, '5min', 0),
(13, 'Puesta en marcha', 70, 'CUE', 'Cuestas', 30, 3, '2min', 0),
(14, 'Puesta en marcha', 70, 'ARR', 'Arrastres', 30, 3, '2min', 5),
(15, 'Puesta en marcha', 70, 'VEL', 'Velocidad', 50, 4, '3min', 0),
(16, 'Puesta en marcha', 70, 'CR', 'Carrera repetida', 300, 4, '5min', 0),
(17, 'Puesta en marcha', 80, 'CUE', 'Cuestas', 30, 3, '2min', 0),
(18, 'Puesta en marcha', 80, 'ARR', 'Arrastres', 30, 3, '2min', 5),
(19, 'Puesta en marcha', 80, 'VEL', 'Velocidad', 50, 4, '3min', 0),
(20, 'Puesta en marcha', 80, 'CR', 'Carrera repetida', 300, 5, '5min', 0),
(21, 'Puesta en marcha', 90, 'CUE', 'Cuestas', 30, 4, '2min', 0),
(22, 'Puesta en marcha', 90, 'ARR', 'Arrastres', 30, 4, '2min', 5),
(23, 'Puesta en marcha', 90, 'VEL', 'Velocidad', 50, 4, '3min', 0),
(24, 'Puesta en marcha', 90, 'CR', 'Carrera repetida', 300, 5, '5min', 0),
(25, 'Puesta en marcha', 100, 'CUE', 'Cuestas', 30, 4, '2min', 0),
(26, 'Puesta en marcha', 100, 'ARR', 'Arrastres', 30, 4, '2min', 5),
(27, 'Puesta en marcha', 100, 'VEL', 'Velocidad', 50, 5, '3min', 0),
(28, 'Puesta en marcha', 100, 'CR', 'Carrera repetida', 300, 5, '5min', 0),
(29, 'Adaptacion funcional', 40, 'CUE', 'Cuestas', 30, 2, '2min', 0),
(30, 'Adaptacion funcional', 40, 'ARR', 'Arrastres', 30, 2, '2min', 10),
(31, 'Adaptacion funcional', 40, 'VEL', 'Velocidad', 50, 2, '2min', 0),
(32, 'Adaptacion funcional', 40, 'CR', 'Carrera repetida', 300, 2, '5min', 0),
(33, 'Adaptacion funcional', 50, 'CUE', 'Cuestas', 30, 2, '2min', 0),
(34, 'Adaptacion funcional', 50, 'ARR', 'Arrastres', 30, 2, '2min', 10),
(35, 'Adaptacion funcional', 50, 'VEL', 'Velocidad', 50, 3, '2min', 0),
(36, 'Adaptacion funcional', 50, 'CR', 'Carrera repetida', 300, 2, '5min', 0),
(37, 'Adaptacion funcional', 60, 'CUE', 'Cuestas', 30, 2, '2min', 0),
(38, 'Adaptacion funcional', 60, 'ARR', 'Arrastres', 30, 2, '2min', 10),
(39, 'Adaptacion funcional', 60, 'VEL', 'Velocidad', 50, 3, '2min', 0),
(40, 'Adaptacion funcional', 60, 'CR', 'Carrera repetida', 300, 2, '5min', 0),
(41, 'Adaptacion funcional', 70, 'CUE', 'Cuestas', 30, 3, '2min', 0),
(42, 'Adaptacion funcional', 70, 'ARR', 'Arrastres', 30, 3, '2min', 10),
(43, 'Adaptacion funcional', 70, 'VEL', 'Velocidad', 50, 4, '2min', 0),
(44, 'Adaptacion funcional', 70, 'CR', 'Carrera repetida', 300, 4, '5min', 0),
(45, 'Adaptacion funcional', 80, 'CUE', 'Cuestas', 30, 3, '2min', 0),
(46, 'Adaptacion funcional', 80, 'ARR', 'Arrastres', 30, 3, '2min', 10),
(47, 'Adaptacion funcional', 80, 'VEL', 'Velocidad', 50, 4, '2min', 0),
(48, 'Adaptacion funcional', 80, 'CR', 'Carrera repetida', 300, 5, '5min', 0),
(49, 'Adaptacion funcional', 90, 'CUE', 'Cuestas', 30, 4, '2min', 0),
(50, 'Adaptacion funcional', 90, 'ARR', 'Arrastres', 30, 4, '2min', 10),
(51, 'Adaptacion funcional', 90, 'VEL', 'Velocidad', 50, 4, '2min', 0),
(52, 'Adaptacion funcional', 90, 'CR', 'Carrera repetida', 300, 5, '5min', 0),
(53, 'Adaptacion funcional', 100, 'CUE', 'Cuestas', 30, 4, '2min', 0),
(54, 'Adaptacion funcional', 100, 'ARR', 'Arrastres', 30, 4, '2min', 10),
(55, 'Adaptacion funcional', 100, 'VEL', 'Velocidad', 50, 5, '2min', 0),
(56, 'Adaptacion funcional', 100, 'CR', 'Carrera repetida', 300, 5, '5min', 0),
(57, 'Fuerza', 40, 'CUE', 'Cuestas', 30, 2, '2min', 0),
(58, 'Fuerza', 40, 'ARR', 'Arrastres', 30, 2, '2min', 20),
(59, 'Fuerza', 40, 'VEL', 'Velocidad', 50, 2, '3min', 0),
(60, 'Fuerza', 40, 'CR', 'Carrera repetida', 200, 2, '4min', 0),
(61, 'Fuerza', 50, 'CUE', 'Cuestas', 30, 2, '2min', 0),
(62, 'Fuerza', 50, 'ARR', 'Arrastres', 30, 2, '2min', 20),
(63, 'Fuerza', 50, 'VEL', 'Velocidad', 50, 3, '3min', 0),
(64, 'Fuerza', 50, 'CR', 'Carrera repetida', 200, 2, '4min', 0),
(65, 'Fuerza', 60, 'CUE', 'Cuestas', 30, 2, '2min', 0),
(66, 'Fuerza', 60, 'ARR', 'Arrastres', 30, 2, '2min', 20),
(67, 'Fuerza', 60, 'VEL', 'Velocidad', 50, 3, '3min', 0),
(68, 'Fuerza', 60, 'CR', 'Carrera repetida', 200, 2, '4min', 0),
(69, 'Fuerza', 70, 'CUE', 'Cuestas', 30, 3, '2min', 0),
(70, 'Fuerza', 70, 'ARR', 'Arrastres', 30, 3, '2min', 20),
(71, 'Fuerza', 70, 'VEL', 'Velocidad', 50, 4, '3min', 0),
(72, 'Fuerza', 70, 'CR', 'Carrera repetida', 200, 4, '4min', 0),
(73, 'Fuerza', 80, 'CUE', 'Cuestas', 30, 3, '2min', 0),
(74, 'Fuerza', 80, 'ARR', 'Arrastres', 30, 3, '2min', 20),
(75, 'Fuerza', 80, 'VEL', 'Velocidad', 50, 4, '3min', 0),
(76, 'Fuerza', 80, 'CR', 'Carrera repetida', 200, 5, '4min', 0),
(77, 'Fuerza', 90, 'CUE', 'Cuestas', 30, 4, '2min', 0),
(78, 'Fuerza', 90, 'ARR', 'Arrastres', 30, 4, '2min', 20),
(79, 'Fuerza', 90, 'VEL', 'Velocidad', 50, 4, '3min', 0),
(80, 'Fuerza', 90, 'CR', 'Carrera repetida', 200, 5, '4min', 0),
(81, 'Fuerza', 100, 'CUE', 'Cuestas', 30, 4, '2min', 0),
(82, 'Fuerza', 100, 'ARR', 'Arrastres', 30, 4, '2min', 20),
(83, 'Fuerza', 100, 'VEL', 'Velocidad', 50, 5, '3min', 0),
(84, 'Fuerza', 100, 'CR', 'Carrera repetida', 200, 6, '4min', 0),
(85, 'Fuerza velocidad', 40, 'CUE', 'Cuestas', 30, 2, '2min', 0),
(86, 'Fuerza velocidad', 40, 'ARR', 'Arrastres', 40, 2, '2min', 15),
(87, 'Fuerza velocidad', 40, 'VEL', 'Velocidad', 50, 2, '3min', 0),
(88, 'Fuerza velocidad', 40, 'CR', 'Carrera repetida', 150, 2, '5min', 0),
(89, 'Fuerza velocidad', 50, 'CUE', 'Cuestas', 30, 2, '2min', 0),
(90, 'Fuerza velocidad', 50, 'ARR', 'Arrastres', 40, 2, '2min', 15),
(91, 'Fuerza velocidad', 50, 'VEL', 'Velocidad', 50, 3, '3min', 0),
(92, 'Fuerza velocidad', 50, 'CR', 'Carrera repetida', 150, 2, '5min', 0),
(93, 'Fuerza velocidad', 60, 'CUE', 'Cuestas', 30, 2, '2min', 0),
(94, 'Fuerza velocidad', 60, 'ARR', 'Arrastres', 40, 2, '2min', 15),
(95, 'Fuerza velocidad', 60, 'VEL', 'Velocidad', 50, 3, '3min', 0),
(96, 'Fuerza velocidad', 60, 'CR', 'Carrera repetida', 150, 2, '5min', 0),
(97, 'Fuerza velocidad', 70, 'CUE', 'Cuestas', 30, 3, '2min', 0),
(98, 'Fuerza velocidad', 70, 'ARR', 'Arrastres', 40, 3, '2min', 15),
(99, 'Fuerza velocidad', 70, 'VEL', 'Velocidad', 50, 4, '3min', 0),
(100, 'Fuerza velocidad', 70, 'CR', 'Carrera repetida', 150, 4, '5min', 0),
(101, 'Fuerza velocidad', 80, 'CUE', 'Cuestas', 30, 3, '2min', 0),
(102, 'Fuerza velocidad', 80, 'ARR', 'Arrastres', 40, 3, '2min', 15),
(103, 'Fuerza velocidad', 80, 'VEL', 'Velocidad', 50, 4, '3min', 0),
(104, 'Fuerza velocidad', 80, 'CR', 'Carrera repetida', 150, 5, '5min', 0),
(105, 'Fuerza velocidad', 90, 'CUE', 'Cuestas', 30, 4, '2min', 0),
(106, 'Fuerza velocidad', 90, 'ARR', 'Arrastres', 40, 4, '2min', 15),
(107, 'Fuerza velocidad', 90, 'VEL', 'Velocidad', 50, 4, '3min', 0),
(108, 'Fuerza velocidad', 90, 'CR', 'Carrera repetida', 150, 5, '5min', 0),
(109, 'Fuerza velocidad', 100, 'CUE', 'Cuestas', 30, 4, '2min', 0),
(110, 'Fuerza velocidad', 100, 'ARR', 'Arrastres', 40, 4, '2min', 15),
(111, 'Fuerza velocidad', 100, 'VEL', 'Velocidad', 50, 5, '3min', 0),
(112, 'Fuerza velocidad', 100, 'CR', 'Carrera repetida', 150, 6, '5min', 0),
(113, 'Velocidad tecnica', 40, 'CUE', 'Cuestas', 30, 2, '2min', 0),
(114, 'Velocidad tecnica', 40, 'ARR', 'Arrastres', 30, 2, '3min', 10),
(115, 'Velocidad tecnica', 40, 'VEL', 'Velocidad', 40, 2, '4min', 0),
(116, 'Velocidad tecnica', 40, 'CR', 'Carrera repetida', 120, 2, '6min', 0),
(117, 'Velocidad tecnica', 50, 'CUE', 'Cuestas', 30, 2, '2min', 0),
(118, 'Velocidad tecnica', 50, 'ARR', 'Arrastres', 30, 2, '3min', 10),
(119, 'Velocidad tecnica', 50, 'VEL', 'Velocidad', 40, 3, '4min', 0),
(120, 'Velocidad tecnica', 50, 'CR', 'Carrera repetida', 120, 2, '6min', 0),
(121, 'Velocidad tecnica', 60, 'CUE', 'Cuestas', 30, 2, '2min', 0),
(122, 'Velocidad tecnica', 60, 'ARR', 'Arrastres', 30, 2, '3min', 10),
(123, 'Velocidad tecnica', 60, 'VEL', 'Velocidad', 40, 3, '4min', 0),
(124, 'Velocidad tecnica', 60, 'CR', 'Carrera repetida', 120, 2, '6min', 0),
(125, 'Velocidad tecnica', 70, 'CUE', 'Cuestas', 30, 3, '2min', 0),
(126, 'Velocidad tecnica', 70, 'ARR', 'Arrastres', 30, 3, '3min', 10),
(127, 'Velocidad tecnica', 70, 'VEL', 'Velocidad', 40, 4, '4min', 0),
(128, 'Velocidad tecnica', 70, 'CR', 'Carrera repetida', 120, 4, '6min', 0),
(129, 'Velocidad tecnica', 80, 'CUE', 'Cuestas', 30, 3, '2min', 0),
(130, 'Velocidad tecnica', 80, 'ARR', 'Arrastres', 30, 3, '3min', 10),
(131, 'Velocidad tecnica', 80, 'VEL', 'Velocidad', 40, 4, '4min', 0),
(132, 'Velocidad tecnica', 80, 'CR', 'Carrera repetida', 120, 5, '6min', 0),
(133, 'Velocidad tecnica', 90, 'CUE', 'Cuestas', 30, 4, '2min', 0),
(134, 'Velocidad tecnica', 90, 'ARR', 'Arrastres', 30, 4, '3min', 10),
(135, 'Velocidad tecnica', 90, 'VEL', 'Velocidad', 40, 4, '4min', 0),
(136, 'Velocidad tecnica', 90, 'CR', 'Carrera repetida', 120, 5, '6min', 0),
(137, 'Velocidad tecnica', 100, 'CUE', 'Cuestas', 30, 4, '2min', 0),
(138, 'Velocidad tecnica', 100, 'ARR', 'Arrastres', 30, 4, '3min', 10),
(139, 'Velocidad tecnica', 100, 'VEL', 'Velocidad', 40, 5, '4min', 0),
(140, 'Velocidad tecnica', 100, 'CR', 'Carrera repetida', 120, 5, '6min', 0),
(141, 'Modelacion competitiva', 40, 'CUE', 'Cuestas', 30, 2, '3min', 0),
(142, 'Modelacion competitiva', 40, 'ARR', 'Arrastres', 30, 2, '3min', 5),
(143, 'Modelacion competitiva', 40, 'VEL', 'Velocidad', 30, 2, '4min', 0),
(144, 'Modelacion competitiva', 40, 'CR', 'Carrera repetida', 120, 2, '6min', 0),
(145, 'Modelacion competitiva', 50, 'CUE', 'Cuestas', 30, 2, '3min', 0),
(146, 'Modelacion competitiva', 50, 'ARR', 'Arrastres', 30, 2, '3min', 5),
(147, 'Modelacion competitiva', 50, 'VEL', 'Velocidad', 30, 3, '4min', 0),
(148, 'Modelacion competitiva', 50, 'CR', 'Carrera repetida', 120, 2, '6min', 0),
(149, 'Modelacion competitiva', 60, 'CUE', 'Cuestas', 30, 2, '3min', 0),
(150, 'Modelacion competitiva', 60, 'ARR', 'Arrastres', 30, 2, '3min', 5),
(151, 'Modelacion competitiva', 60, 'VEL', 'Velocidad', 30, 3, '4min', 0),
(152, 'Modelacion competitiva', 60, 'CR', 'Carrera repetida', 120, 2, '6min', 0),
(153, 'Modelacion competitiva', 70, 'CUE', 'Cuestas', 30, 2, '3min', 0),
(154, 'Modelacion competitiva', 70, 'ARR', 'Arrastres', 30, 2, '3min', 5),
(155, 'Modelacion competitiva', 70, 'VEL', 'Velocidad', 30, 3, '4min', 0),
(156, 'Modelacion competitiva', 70, 'CR', 'Carrera repetida', 120, 2, '6min', 0),
(157, 'Modelacion competitiva', 80, 'CUE', 'Cuestas', 30, 2, '3min', 0),
(158, 'Modelacion competitiva', 80, 'ARR', 'Arrastres', 30, 2, '3min', 5),
(159, 'Modelacion competitiva', 80, 'VEL', 'Velocidad', 30, 4, '4min', 0),
(160, 'Modelacion competitiva', 80, 'CR', 'Carrera repetida', 120, 2, '6min', 0),
(161, 'Modelacion competitiva', 90, 'CUE', 'Cuestas', 30, 2, '3min', 0),
(162, 'Modelacion competitiva', 90, 'ARR', 'Arrastres', 30, 2, '3min', 5),
(163, 'Modelacion competitiva', 90, 'VEL', 'Velocidad', 30, 3, '4min', 0),
(164, 'Modelacion competitiva', 90, 'CR', 'Carrera repetida', 120, 2, '6min', 0),
(165, 'Modelacion competitiva', 100, 'CUE', 'Cuestas', 30, 2, '3min', 0),
(166, 'Modelacion competitiva', 100, 'ARR', 'Arrastres', 30, 2, '3min', 5),
(167, 'Modelacion competitiva', 100, 'VEL', 'Velocidad', 30, 4, '4min', 0),
(168, 'Modelacion competitiva', 100, 'CR', 'Carrera repetida', 120, 2, '6min', 0),
(169, 'Competitivo', 40, 'CUE', 'Cuestas', 30, 2, '3min', 0),
(170, 'Competitivo', 40, 'ARR', 'Arrastres', 30, 2, '3min', 5),
(171, 'Competitivo', 40, 'VEL', 'Velocidad', 30, 2, '4min', 0),
(172, 'Competitivo', 40, 'CR', 'Carrera repetida', 100, 2, '6min', 0),
(173, 'Competitivo', 50, 'CUE', 'Cuestas', 30, 2, '3min', 0),
(174, 'Competitivo', 50, 'ARR', 'Arrastres', 30, 2, '3min', 5),
(175, 'Competitivo', 50, 'VEL', 'Velocidad', 30, 3, '4min', 0),
(176, 'Competitivo', 50, 'CR', 'Carrera repetida', 100, 2, '6min', 0),
(177, 'Competitivo', 60, 'CUE', 'Cuestas', 30, 2, '3min', 0),
(178, 'Competitivo', 60, 'ARR', 'Arrastres', 30, 2, '3min', 5),
(179, 'Competitivo', 60, 'VEL', 'Velocidad', 30, 3, '4min', 0),
(180, 'Competitivo', 60, 'CR', 'Carrera repetida', 100, 2, '6min', 0),
(181, 'Competitivo', 70, 'CUE', 'Cuestas', 30, 2, '3min', 0),
(182, 'Competitivo', 70, 'ARR', 'Arrastres', 30, 2, '3min', 5),
(183, 'Competitivo', 70, 'VEL', 'Velocidad', 30, 3, '4min', 0),
(184, 'Competitivo', 70, 'CR', 'Carrera repetida', 100, 2, '6min', 0),
(185, 'Competitivo', 80, 'CUE', 'Cuestas', 30, 2, '3min', 0),
(186, 'Competitivo', 80, 'ARR', 'Arrastres', 30, 2, '3min', 5),
(187, 'Competitivo', 80, 'VEL', 'Velocidad', 30, 4, '4min', 0),
(188, 'Competitivo', 80, 'CR', 'Carrera repetida', 100, 2, '6min', 0),
(189, 'Competitivo', 90, 'CUE', 'Cuestas', 30, 2, '3min', 0),
(190, 'Competitivo', 90, 'ARR', 'Arrastres', 30, 2, '3min', 5),
(191, 'Competitivo', 90, 'VEL', 'Velocidad', 30, 3, '4min', 0),
(192, 'Competitivo', 90, 'CR', 'Carrera repetida', 100, 2, '6min', 0),
(193, 'Competitivo', 100, 'CUE', 'Cuestas', 30, 2, '3min', 0),
(194, 'Competitivo', 100, 'ARR', 'Arrastres', 30, 2, '3min', 5),
(195, 'Competitivo', 100, 'VEL', 'Velocidad', 30, 4, '4min', 0),
(196, 'Competitivo', 100, 'CR', 'Carrera repetida', 100, 2, '6min', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ejercicios_tecnicos`
--

CREATE TABLE IF NOT EXISTS `ejercicios_tecnicos` (
  `Id` int(5) NOT NULL,
  `Mesociclo` varchar(30) NOT NULL,
  `Volumen` int(5) NOT NULL,
  `Ejercicio` varchar(30) NOT NULL,
  `Series` int(5) NOT NULL,
  `Repeticiones` int(5) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `ejercicios_tecnicos`
--

INSERT INTO `ejercicios_tecnicos` (`Id`, `Mesociclo`, `Volumen`, `Ejercicio`, `Series`, `Repeticiones`) VALUES
(1, 'Puesta en marcha', 40, 'Isometricos franqueo', 1, 4),
(2, 'Puesta en marcha', 50, 'Isometricos franqueo', 2, 4),
(3, 'Puesta en marcha', 60, 'Isometricos franqueo', 2, 4),
(4, 'Puesta en marcha', 70, 'Isometricos franqueo', 2, 4),
(5, 'Puesta en marcha', 80, 'Isometricos franqueo', 2, 4),
(6, 'Puesta en marcha', 90, 'Isometricos franqueo', 2, 4),
(7, 'Puesta en marcha', 100, 'Isometricos franqueo', 2, 4),
(8, 'Adaptacion funcional', 40, 'Isometricos franqueo', 1, 5),
(9, 'Adaptacion funcional', 40, 'Flop parado', 1, 5),
(10, 'Adaptacion funcional', 50, 'Isometricos franqueo', 2, 5),
(11, 'Adaptacion funcional', 50, 'Flop parado', 2, 5),
(12, 'Adaptacion funcional', 60, 'Isometricos franqueo', 2, 5),
(13, 'Adaptacion funcional', 60, 'Flop parado', 2, 5),
(14, 'Adaptacion funcional', 70, 'Isometricos franqueo', 2, 5),
(15, 'Adaptacion funcional', 70, 'Flop parado', 2, 5),
(16, 'Adaptacion funcional', 80, 'Isometricos franqueo', 2, 5),
(17, 'Adaptacion funcional', 80, 'Flop parado', 2, 5),
(18, 'Adaptacion funcional', 90, 'Isometricos franqueo', 2, 5),
(19, 'Adaptacion funcional', 90, 'Flop parado', 2, 5),
(20, 'Adaptacion funcional', 100, 'Isometricos franqueo', 2, 5),
(21, 'Adaptacion funcional', 100, 'Flop parado', 2, 5),
(22, 'Fuerza', 40, 'Saltos a tocar', 1, 6),
(23, 'Fuerza', 40, 'Isometricos franqueo', 1, 5),
(24, 'Fuerza', 40, 'Flop parado', 1, 5),
(25, 'Fuerza', 50, 'Saltos a tocar', 2, 6),
(26, 'Fuerza', 50, 'Isometricos franqueo', 2, 5),
(27, 'Fuerza', 50, 'Flop parado', 2, 5),
(28, 'Fuerza', 60, 'Saltos a tocar', 2, 6),
(29, 'Fuerza', 60, 'Isometricos franqueo', 2, 5),
(30, 'Fuerza', 60, 'Flop parado', 2, 5),
(31, 'Fuerza', 70, 'Saltos a tocar', 2, 6),
(32, 'Fuerza', 70, 'Isometricos franqueo', 2, 5),
(33, 'Fuerza', 70, 'Flop parado', 2, 5),
(34, 'Fuerza', 80, 'Saltos a tocar', 3, 6),
(35, 'Fuerza', 80, 'Isometricos franqueo', 3, 5),
(36, 'Fuerza', 80, 'Flop parado', 3, 5),
(37, 'Fuerza', 90, 'Saltos a tocar', 3, 6),
(38, 'Fuerza', 90, 'Isometricos franqueo', 3, 5),
(39, 'Fuerza', 90, 'Flop parado', 3, 5),
(40, 'Fuerza', 100, 'Saltos a tocar', 3, 6),
(41, 'Fuerza', 100, 'Isometricos franqueo', 3, 5),
(42, 'Fuerza', 100, 'Flop parado', 3, 5),
(43, 'Fuerza velocidad', 40, 'Saltos a tocar', 1, 5),
(44, 'Fuerza velocidad', 40, 'Isometricos franqueo', 1, 5),
(45, 'Fuerza velocidad', 40, 'Flop parado', 1, 5),
(46, 'Fuerza velocidad', 50, 'Saltos a tocar', 2, 5),
(47, 'Fuerza velocidad', 50, 'Isometricos franqueo', 2, 5),
(48, 'Fuerza velocidad', 50, 'Flop parado', 2, 5),
(49, 'Fuerza velocidad', 60, 'Saltos a tocar', 2, 5),
(50, 'Fuerza velocidad', 60, 'Isometricos franqueo', 2, 5),
(51, 'Fuerza velocidad', 60, 'Flop parado', 2, 5),
(52, 'Fuerza velocidad', 70, 'Saltos a tocar', 2, 5),
(53, 'Fuerza velocidad', 70, 'Isometricos franqueo', 2, 5),
(54, 'Fuerza velocidad', 70, 'Flop parado', 2, 5),
(55, 'Fuerza velocidad', 80, 'Saltos a tocar', 2, 5),
(56, 'Fuerza velocidad', 80, 'Isometricos franqueo', 2, 5),
(57, 'Fuerza velocidad', 80, 'Flop parado', 2, 5),
(58, 'Fuerza velocidad', 90, 'Saltos a tocar', 2, 5),
(59, 'Fuerza velocidad', 90, 'Isometricos franqueo', 2, 5),
(60, 'Fuerza velocidad', 90, 'Flop parado', 2, 5),
(61, 'Fuerza velocidad', 100, 'Saltos a tocar', 2, 5),
(62, 'Fuerza velocidad', 100, 'Isometricos franqueo', 2, 5),
(63, 'Fuerza velocidad', 100, 'Flop parado', 2, 5),
(64, 'Velocidad tecnica', 40, 'Skiping batida', 1, 4),
(65, 'Velocidad tecnica', 40, 'Isometricos franqueo', 1, 5),
(66, 'Velocidad tecnica', 40, 'Flop parado', 1, 5),
(67, 'Velocidad tecnica', 50, 'Skiping batida', 1, 4),
(68, 'Velocidad tecnica', 50, 'Isometricos franqueo', 1, 5),
(69, 'Velocidad tecnica', 50, 'Flop parado', 1, 5),
(70, 'Velocidad tecnica', 60, 'Skiping batida', 1, 4),
(71, 'Velocidad tecnica', 60, 'Isometricos franqueo', 1, 5),
(72, 'Velocidad tecnica', 60, 'Flop parado', 1, 5),
(73, 'Velocidad tecnica', 70, 'Skiping batida', 1, 4),
(74, 'Velocidad tecnica', 70, 'Isometricos franqueo', 1, 5),
(75, 'Velocidad tecnica', 70, 'Flop parado', 1, 5),
(76, 'Velocidad tecnica', 80, 'Skiping batida', 1, 4),
(77, 'Velocidad tecnica', 80, 'Isometricos franqueo', 1, 5),
(78, 'Velocidad tecnica', 80, 'Flop parado', 1, 5),
(79, 'Velocidad tecnica', 90, 'Skiping batida', 1, 4),
(80, 'Velocidad tecnica', 90, 'Isometricos franqueo', 1, 5),
(81, 'Velocidad tecnica', 90, 'Flop parado', 1, 5),
(82, 'Velocidad tecnica', 100, 'Skiping batida', 1, 4),
(83, 'Velocidad tecnica', 100, 'Isometricos franqueo', 1, 5),
(84, 'Velocidad tecnica', 100, 'Flop parado', 1, 5),
(85, 'Modelacion competitiva', 40, 'Skiping batida', 1, 4),
(86, 'Modelacion competitiva', 50, 'Skiping batida', 1, 4),
(87, 'Modelacion competitiva', 60, 'Skiping batida', 1, 4),
(88, 'Modelacion competitiva', 70, 'Skiping batida', 1, 4),
(89, 'Modelacion competitiva', 80, 'Skiping batida', 1, 4),
(90, 'Modelacion competitiva', 90, 'Skiping batida', 1, 4),
(91, 'Modelacion competitiva', 100, 'Skiping batida', 1, 4),
(92, 'Competitivo', 40, 'Skiping batida', 1, 4),
(93, 'Competitivo', 50, 'Skiping batida', 1, 4),
(94, 'Competitivo', 60, 'Skiping batida', 1, 4),
(95, 'Competitivo', 70, 'Skiping batida', 1, 4),
(96, 'Competitivo', 80, 'Skiping batida', 1, 4),
(97, 'Competitivo', 90, 'Skiping batida', 1, 4),
(98, 'Competitivo', 100, 'Skiping batida', 1, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entrenadores`
--

CREATE TABLE IF NOT EXISTS `entrenadores` (
  `Id` int(5) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(30) NOT NULL,
  `Apellidos` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Club_organizacion` varchar(30) NOT NULL,
  `Sector` varchar(30) NOT NULL,
  `Especialidad` varchar(30) NOT NULL,
  `Titulacion` varchar(30) NOT NULL,
  `Usuario` varchar(30) NOT NULL,
  `Password` varchar(255) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `entrenadores`
--

INSERT INTO `entrenadores` (`Id`, `Nombre`, `Apellidos`, `Email`, `Club_organizacion`, `Sector`, `Especialidad`, `Titulacion`, `Usuario`, `Password`) VALUES
(2, 'Miguel', 'Vélez Blasco', 'miklos@gmail.com', 'RFEA', 'Saltos', 'Salto de altura', 'Nacional especializado', 'Miklos', '$2y$10$c.2tZDP72MdCkK.R90UExevhSb/2nf8sfhK.xvdsGjUPh0qmYSTPi'),
(3, 'Hans', 'Ruf Jiménez', 'ruf@gmail.com', 'RFEA', 'Saltos', 'Salto de altura', 'Club', 'Rufina', '$2y$10$qI/PW2.VfTBnGK9dTJrhkuM3.ADEu8tmt/XduQ0Y9ZCdwOneGLJBq');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entrenamientos`
--

CREATE TABLE IF NOT EXISTS `entrenamientos` (
  `Id` int(5) NOT NULL AUTO_INCREMENT,
  `Fecha` date NOT NULL,
  `Id_planificacion` int(5) NOT NULL,
  `Semana` int(5) NOT NULL,
  `Dia` varchar(30) NOT NULL,
  `User` varchar(30) NOT NULL,
  `U1` text NOT NULL,
  `U2` text NOT NULL,
  `U3` text NOT NULL,
  `U4` text NOT NULL,
  `U5` text NOT NULL,
  `U6` text NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `entrenamientos`
--

INSERT INTO `entrenamientos` (`Id`, `Fecha`, `Id_planificacion`, `Semana`, `Dia`, `User`, `U1`, `U2`, `U3`, `U4`, `U5`, `U6`) VALUES
(1, '2018-05-07', 1, 1, 'Lunes', 'Miklos', 'Fuerza:<br />\r\nArrancada:  2 x 5 x 12RM<br />\r\nCargada:  2 x 5 x 12RM<br />\r\nSentadilla-40:  2 x 6 x 10RM<br />\r\nPectoral:  2 x 5 x 12RM<br />\r\nGemelos:  2 x 10 x 20kg<br />\r\n', 'Cuestas:<br />\r\n2 x 30m recuperación: 2min<br />\r\n', '---', 'Ejercicios técnicos:<br />\r\nIsometricos franqueo:  2 x 5<br />\r\nFlop parado:  2 x 5<br />\r\n', '---', '---'),
(2, '2018-05-08', 1, 1, 'Martes', 'Miklos', 'Ejercicios técnicos:<br />\r\nIsometricos franqueo:  2 x 5<br />\r\nFlop parado:  2 x 5<br />\r\n', 'Técnica:<br />\r\nTijeras falicitadas - III 4 p. x8<br />\r\nFlop facilitado - III 6 p.l. x10<br />\r\n', '---', 'Carrera repetida:<br />\r\n2 x 300m recuperación: 5min<br />\r\n', '---', '---');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fuerza`
--

CREATE TABLE IF NOT EXISTS `fuerza` (
  `Id` int(5) NOT NULL,
  `Ciclo` varchar(30) NOT NULL,
  `Volumen` int(5) NOT NULL,
  `Ejercicio` varchar(30) NOT NULL,
  `Series` int(5) NOT NULL,
  `Repeticiones` int(5) NOT NULL,
  `Rm` varchar(10) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `fuerza`
--

INSERT INTO `fuerza` (`Id`, `Ciclo`, `Volumen`, `Ejercicio`, `Series`, `Repeticiones`, `Rm`) VALUES
(1, 'Especial', 20, 'Arrancada', 2, 4, '14RM'),
(2, 'Especial', 20, 'Cargada', 2, 4, '14RM'),
(3, 'Especial', 20, 'Sentadilla-40', 2, 5, '12RM'),
(4, 'Especial', 20, 'Pectoral', 1, 5, '14RM'),
(5, 'Especial', 20, 'Gemelos', 1, 8, '10kg'),
(6, 'Especial', 50, 'Arrancada', 2, 5, '12RM'),
(7, 'Especial', 50, 'Cargada', 2, 5, '12RM'),
(8, 'Especial', 50, 'Sentadilla-40', 2, 6, '10RM'),
(9, 'Especial', 50, 'Pectoral', 2, 5, '12RM'),
(10, 'Especial', 50, 'Gemelos', 2, 10, '20kg'),
(11, 'Especial', 80, 'Arrancada', 2, 5, '8RM'),
(12, 'Especial', 80, 'Cargada', 2, 5, '8RM'),
(13, 'Especial', 80, 'Sentadilla-40', 3, 6, '7RM'),
(14, 'Especial', 80, 'Pectoral', 2, 5, '8RM'),
(15, 'Especial', 80, 'Gemelos', 2, 10, '30kg'),
(16, 'Especial', 100, 'Arrancada', 3, 5, '7RM'),
(17, 'Especial', 100, 'Cargada', 3, 5, '7RM'),
(18, 'Especial', 100, 'Sentadilla-40', 4, 6, '6RM'),
(19, 'Especial', 100, 'Pectoral', 3, 5, '8RM'),
(20, 'Especial', 100, 'Gemelos', 3, 12, '40kg'),
(21, 'Tecnica', 20, 'Arrancada', 1, 4, '12RM'),
(22, 'Tecnica', 20, 'Cargada', 1, 4, '12RM'),
(23, 'Tecnica', 20, 'Sentadilla-40+3d', 2, 4, '10RM'),
(24, 'Tecnica', 20, 'Pectoral', 1, 5, '12RM'),
(25, 'Tecnica', 20, 'Gemelos', 1, 8, '15kg'),
(26, 'Tecnica', 50, 'Arrancada', 2, 4, '10RM'),
(27, 'Tecnica', 50, 'Cargada', 2, 4, '10RM'),
(28, 'Tecnica', 50, 'Sentadilla-40+3d', 2, 5, '8RM'),
(29, 'Tecnica', 50, 'Pectoral', 2, 5, '10RM'),
(30, 'Tecnica', 50, 'Gemelos', 2, 10, '25kg'),
(31, 'Tecnica', 80, 'Arrancada', 2, 5, '7RM'),
(32, 'Tecnica', 80, 'Cargada', 2, 5, '7RM'),
(33, 'Tecnica', 80, 'Sentadilla-40+3d', 3, 5, '6RM'),
(34, 'Tecnica', 80, 'Pectoral', 2, 5, '8RM'),
(35, 'Tecnica', 80, 'Gemelos', 2, 10, '35kg'),
(36, 'Tecnica', 100, 'Arrancada', 2, 4, '6RM'),
(37, 'Tecnica', 100, 'Cargada', 3, 4, '6RM'),
(38, 'Tecnica', 100, 'Sentadilla-40+3d', 4, 4, '5RM'),
(39, 'Tecnica', 100, 'Pectoral', 3, 5, '7RM'),
(40, 'Tecnica', 100, 'Gemelos', 3, 12, '45kg'),
(41, 'Competitivo', 20, 'Arrancada', 1, 3, '12RM'),
(42, 'Competitivo', 20, 'Cargada', 1, 3, '12RM'),
(43, 'Competitivo', 20, 'Sentadilla-40+3d', 1, 4, '10RM'),
(44, 'Competitivo', 20, 'Pectoral', 1, 4, '12RM'),
(45, 'Competitivo', 50, 'Arrancada', 1, 3, '8RM'),
(46, 'Competitivo', 50, 'Cargada', 1, 3, '8RM'),
(47, 'Competitivo', 50, 'Sentadilla-40+3d', 2, 4, '7RM'),
(48, 'Competitivo', 50, 'Pectoral', 1, 4, '10RM'),
(49, 'Competitivo', 80, 'Arrancada', 2, 3, '7RM'),
(50, 'Competitivo', 80, 'Cargada', 2, 3, '7RM'),
(51, 'Competitivo', 80, 'Sentadilla-40+3d', 2, 4, '6RM'),
(52, 'Competitivo', 80, 'Pectoral', 2, 4, '8RM'),
(53, 'Competitivo', 100, 'Arrancada', 2, 4, '6RM'),
(54, 'Competitivo', 100, 'Cargada', 2, 4, '6RM'),
(55, 'Competitivo', 100, 'Sentadilla-40+3d', 2, 5, '5RM'),
(56, 'Competitivo', 100, 'Pectoral', 2, 4, '7RM');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `monoarticulares_ejercicios`
--

CREATE TABLE IF NOT EXISTS `monoarticulares_ejercicios` (
  `Id` int(5) NOT NULL AUTO_INCREMENT,
  `Ejercicio` varchar(30) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `monoarticulares_ejercicios`
--

INSERT INTO `monoarticulares_ejercicios` (`Id`, `Ejercicio`) VALUES
(1, 'Vasto interno'),
(2, 'Cuadriceps (tirante)'),
(3, 'Glúteo'),
(4, 'Isquios (tirante)'),
(5, 'Psoas Ilíaco'),
(6, 'Prensa'),
(7, 'Botes (plano inclinado)');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `monoarticulares_repeticiones`
--

CREATE TABLE IF NOT EXISTS `monoarticulares_repeticiones` (
  `Id` int(5) NOT NULL AUTO_INCREMENT,
  `Mesociclo` varchar(30) NOT NULL,
  `Series` int(5) NOT NULL,
  `Repeticiones` int(5) NOT NULL,
  `Recuperacion` varchar(30) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `monoarticulares_repeticiones`
--

INSERT INTO `monoarticulares_repeticiones` (`Id`, `Mesociclo`, `Series`, `Repeticiones`, `Recuperacion`) VALUES
(1, 'Puesta en marcha', 3, 12, 'Streching'),
(2, 'Adaptacion funcional', 3, 12, 'Streching'),
(3, 'Fuerza', 3, 12, 'Streching'),
(4, 'Fuerza velocidad', 3, 10, 'Streching'),
(5, 'Velocidad tecnica', 2, 8, 'Streching'),
(6, 'Modelacion competitiva', 2, 6, 'Streching'),
(7, 'Competitivo', 1, 6, 'Streching');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `multisaltos_horizontales`
--

CREATE TABLE IF NOT EXISTS `multisaltos_horizontales` (
  `Id` int(5) NOT NULL,
  `Mesociclo` varchar(30) NOT NULL,
  `Volumen` int(5) NOT NULL,
  `Ejercicio` varchar(30) NOT NULL,
  `Series` int(5) NOT NULL,
  `Repeticiones` int(5) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `multisaltos_horizontales`
--

INSERT INTO `multisaltos_horizontales` (`Id`, `Mesociclo`, `Volumen`, `Ejercicio`, `Series`, `Repeticiones`) VALUES
(1, 'Puesta en marcha', 40, 'Escaleras o obstaculines', 1, 15),
(2, 'Puesta en marcha', 50, 'Escaleras o obstaculines', 2, 12),
(3, 'Puesta en marcha', 60, 'Escaleras o obstaculines', 2, 15),
(4, 'Puesta en marcha', 70, 'Escaleras o obstaculines', 3, 12),
(5, 'Puesta en marcha', 80, 'Escaleras o obstaculines', 3, 15),
(6, 'Puesta en marcha', 90, 'Escaleras o obstaculines', 4, 12),
(7, 'Puesta en marcha', 100, 'Escaleras o obstaculines', 4, 15),
(8, 'Adaptacion funcional', 40, 'Escaleras o obstaculines', 1, 15),
(9, 'Adaptacion funcional', 50, 'Escaleras o obstaculines', 2, 12),
(10, 'Adaptacion funcional', 60, 'Escaleras o obstaculines', 2, 15),
(11, 'Adaptacion funcional', 70, 'Escaleras o obstaculines', 3, 12),
(12, 'Adaptacion funcional', 80, 'Escaleras o obstaculines', 3, 15),
(13, 'Adaptacion funcional', 90, 'Escaleras o obstaculines', 4, 12),
(14, 'Adaptacion funcional', 100, 'Escaleras o obstaculines', 4, 15),
(15, 'Fuerza', 40, 'Escaleras o obstaculines', 1, 15),
(16, 'Fuerza', 50, 'Escaleras o obstaculines', 2, 12),
(17, 'Fuerza', 60, 'Escaleras o obstaculines', 2, 15),
(18, 'Fuerza', 70, 'Escaleras o obstaculines', 3, 12),
(19, 'Fuerza', 80, 'Escaleras o obstaculines', 3, 15),
(20, 'Fuerza', 90, 'Escaleras o obstaculines', 4, 12),
(21, 'Fuerza', 100, 'Escaleras o obstaculines', 4, 15),
(22, 'Fuerza velocidad', 40, 'Decasalto alterno', 1, 1),
(23, 'Fuerza velocidad', 40, 'Longitud parado', 1, 1),
(24, 'Fuerza velocidad', 40, 'Triple parado', 1, 1),
(25, 'Fuerza velocidad', 40, 'Pentasalto alterno', 1, 2),
(26, 'Fuerza velocidad', 50, 'Decasalto alterno', 1, 2),
(27, 'Fuerza velocidad', 50, 'Longitud parado', 1, 2),
(28, 'Fuerza velocidad', 50, 'Triple parado', 1, 2),
(29, 'Fuerza velocidad', 50, 'Pentasalto alterno', 1, 4),
(30, 'Fuerza velocidad', 60, 'Decasalto alterno', 1, 3),
(31, 'Fuerza velocidad', 60, 'Longitud parado', 1, 3),
(32, 'Fuerza velocidad', 60, 'Triple parado', 1, 3),
(33, 'Fuerza velocidad', 60, 'Pentasalto alterno', 1, 5),
(34, 'Fuerza velocidad', 70, 'Decasalto alterno', 1, 3),
(35, 'Fuerza velocidad', 70, 'Longitud parado', 1, 3),
(36, 'Fuerza velocidad', 70, 'Triple parado', 1, 3),
(37, 'Fuerza velocidad', 70, 'Pentasalto alterno', 1, 6),
(38, 'Fuerza velocidad', 80, 'Decasalto alterno', 1, 3),
(39, 'Fuerza velocidad', 80, 'Longitud parado', 1, 3),
(40, 'Fuerza velocidad', 80, 'Triple parado', 1, 3),
(41, 'Fuerza velocidad', 80, 'Pentasalto alterno', 1, 6),
(42, 'Fuerza velocidad', 90, 'Decasalto alterno', 1, 4),
(43, 'Fuerza velocidad', 90, 'Longitud parado', 1, 4),
(44, 'Fuerza velocidad', 90, 'Triple parado', 1, 4),
(45, 'Fuerza velocidad', 90, 'Pentasalto alterno', 1, 7),
(46, 'Fuerza velocidad', 100, 'Decasalto alterno', 1, 4),
(47, 'Fuerza velocidad', 100, 'Longitud parado', 1, 4),
(48, 'Fuerza velocidad', 100, 'Triple parado', 1, 4),
(49, 'Fuerza velocidad', 100, 'Pentasalto alterno', 1, 8),
(50, 'Velocidad tecnica', 40, 'Longitud parado', 1, 2),
(51, 'Velocidad tecnica', 40, 'Triple parado', 1, 2),
(52, 'Velocidad tecnica', 40, 'Pentasalto alterno', 1, 4),
(53, 'Velocidad tecnica', 50, 'Longitud parado', 1, 3),
(54, 'Velocidad tecnica', 50, 'Triple parado', 1, 3),
(55, 'Velocidad tecnica', 50, 'Pentasalto alterno', 1, 5),
(56, 'Velocidad tecnica', 60, 'Longitud parado', 1, 3),
(57, 'Velocidad tecnica', 60, 'Triple parado', 1, 3),
(58, 'Velocidad tecnica', 60, 'Pentasalto alterno', 1, 6),
(59, 'Velocidad tecnica', 70, 'Longitud parado', 1, 3),
(60, 'Velocidad tecnica', 70, 'Triple parado', 1, 3),
(61, 'Velocidad tecnica', 70, 'Pentasalto alterno', 1, 7),
(62, 'Velocidad tecnica', 80, 'Longitud parado', 1, 3),
(63, 'Velocidad tecnica', 80, 'Triple parado', 1, 3),
(64, 'Velocidad tecnica', 80, 'Pentasalto alterno', 1, 8),
(65, 'Velocidad tecnica', 90, 'Longitud parado', 1, 3),
(66, 'Velocidad tecnica', 90, 'Triple parado', 1, 3),
(67, 'Velocidad tecnica', 90, 'Pentasalto alterno', 1, 9),
(68, 'Velocidad tecnica', 100, 'Longitud parado', 1, 3),
(69, 'Velocidad tecnica', 100, 'Triple parado', 1, 3),
(70, 'Velocidad tecnica', 100, 'Pentasalto alterno', 1, 10),
(71, 'Modelacion competitiva', 40, 'Longitud parado', 1, 2),
(72, 'Modelacion competitiva', 40, 'Triple parado', 1, 2),
(73, 'Modelacion competitiva', 50, 'Longitud parado', 1, 2),
(74, 'Modelacion competitiva', 50, 'Triple parado', 1, 2),
(75, 'Modelacion competitiva', 60, 'Longitud parado', 1, 2),
(76, 'Modelacion competitiva', 60, 'Triple parado', 1, 2),
(77, 'Modelacion competitiva', 70, 'Longitud parado', 1, 3),
(78, 'Modelacion competitiva', 70, 'Triple parado', 1, 3),
(79, 'Modelacion competitiva', 80, 'Longitud parado', 1, 3),
(80, 'Modelacion competitiva', 80, 'Triple parado', 1, 3),
(81, 'Modelacion competitiva', 90, 'Longitud parado', 1, 3),
(82, 'Modelacion competitiva', 90, 'Triple parado', 1, 3),
(83, 'Modelacion competitiva', 100, 'Longitud parado', 1, 3),
(84, 'Modelacion competitiva', 100, 'Triple parado', 1, 3),
(85, 'Competitivo', 40, 'Longitud parado', 1, 1),
(86, 'Competitivo', 40, 'Triple parado', 1, 1),
(87, 'Competitivo', 50, 'Longitud parado', 1, 1),
(88, 'Competitivo', 50, 'Triple parado', 1, 1),
(89, 'Competitivo', 60, 'Longitud parado', 1, 1),
(90, 'Competitivo', 60, 'Triple parado', 1, 1),
(91, 'Competitivo', 70, 'Longitud parado', 1, 2),
(92, 'Competitivo', 70, 'Triple parado', 1, 2),
(93, 'Competitivo', 80, 'Longitud parado', 1, 2),
(94, 'Competitivo', 80, 'Triple parado', 1, 2),
(95, 'Competitivo', 90, 'Longitud parado', 1, 3),
(96, 'Competitivo', 90, 'Triple parado', 1, 3),
(97, 'Competitivo', 100, 'Longitud parado', 1, 3),
(98, 'Competitivo', 100, 'Triple parado', 1, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `multisaltos_verticales`
--

CREATE TABLE IF NOT EXISTS `multisaltos_verticales` (
  `Id` int(5) NOT NULL,
  `Mesociclo` varchar(30) NOT NULL,
  `Volumen` int(5) NOT NULL,
  `Ejercicio` varchar(30) NOT NULL,
  `Series` int(5) NOT NULL,
  `Repeticiones` int(5) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `multisaltos_verticales`
--

INSERT INTO `multisaltos_verticales` (`Id`, `Mesociclo`, `Volumen`, `Ejercicio`, `Series`, `Repeticiones`) VALUES
(1, 'Puesta en marcha', 40, 'Imitativos batida', 1, 4),
(2, 'Puesta en marcha', 50, 'Imitativos batida', 1, 4),
(3, 'Puesta en marcha', 60, 'Imitativos batida', 1, 4),
(4, 'Puesta en marcha', 70, 'Imitativos batida', 2, 4),
(5, 'Puesta en marcha', 80, 'Imitativos batida', 2, 4),
(6, 'Puesta en marcha', 90, 'Imitativos batida', 2, 4),
(7, 'Puesta en marcha', 100, 'Imitativos batida', 3, 4),
(8, 'Adaptacion funcional', 40, 'Imitativos batida', 1, 4),
(9, 'Adaptacion funcional', 40, 'Multisaltos vallas', 1, 6),
(10, 'Adaptacion funcional', 50, 'Imitativos batida', 1, 4),
(11, 'Adaptacion funcional', 50, 'Multisaltos vallas', 2, 6),
(12, 'Adaptacion funcional', 60, 'Imitativos batida', 1, 4),
(13, 'Adaptacion funcional', 60, 'Multisaltos vallas', 2, 6),
(14, 'Adaptacion funcional', 70, 'Imitativos batida', 2, 4),
(15, 'Adaptacion funcional', 70, 'Multisaltos vallas', 2, 6),
(16, 'Adaptacion funcional', 80, 'Imitativos batida', 2, 4),
(17, 'Adaptacion funcional', 80, 'Multisaltos vallas', 3, 6),
(18, 'Adaptacion funcional', 90, 'Imitativos batida', 2, 4),
(19, 'Adaptacion funcional', 90, 'Multisaltos vallas', 3, 6),
(20, 'Adaptacion funcional', 100, 'Imitativos batida', 3, 4),
(21, 'Adaptacion funcional', 100, 'Multisaltos vallas', 3, 6),
(22, 'Fuerza', 40, 'Imitativos batida', 1, 5),
(23, 'Fuerza', 40, 'Multisaltos vallas', 1, 8),
(24, 'Fuerza', 50, 'Imitativos batida', 1, 5),
(25, 'Fuerza', 50, 'Multisaltos vallas', 2, 8),
(26, 'Fuerza', 60, 'Imitativos batida', 1, 5),
(27, 'Fuerza', 60, 'Multisaltos vallas', 2, 8),
(28, 'Fuerza', 70, 'Imitativos batida', 2, 5),
(29, 'Fuerza', 70, 'Multisaltos vallas', 2, 8),
(30, 'Fuerza', 80, 'Imitativos batida', 2, 5),
(31, 'Fuerza', 80, 'Multisaltos vallas', 3, 8),
(32, 'Fuerza', 90, 'Imitativos batida', 2, 5),
(33, 'Fuerza', 90, 'Multisaltos vallas', 3, 8),
(34, 'Fuerza', 100, 'Imitativos batida', 3, 5),
(35, 'Fuerza', 100, 'Multisaltos vallas', 3, 8),
(36, 'Fuerza velocidad', 40, 'Imitativos batida', 1, 4),
(37, 'Fuerza velocidad', 40, 'Multisaltos vallas', 1, 6),
(38, 'Fuerza velocidad', 40, 'Mult. vallas rebote', 1, 6),
(39, 'Fuerza velocidad', 50, 'Imitativos batida', 1, 4),
(40, 'Fuerza velocidad', 50, 'Multisaltos vallas', 2, 6),
(41, 'Fuerza velocidad', 50, 'Mult. vallas rebote', 1, 6),
(42, 'Fuerza velocidad', 60, 'Imitativos batida', 1, 4),
(43, 'Fuerza velocidad', 60, 'Multisaltos vallas', 2, 6),
(44, 'Fuerza velocidad', 60, 'Mult. vallas rebote', 2, 6),
(45, 'Fuerza velocidad', 70, 'Imitativos batida', 2, 4),
(46, 'Fuerza velocidad', 70, 'Multisaltos vallas', 2, 6),
(47, 'Fuerza velocidad', 70, 'Mult. vallas rebote', 2, 6),
(48, 'Fuerza velocidad', 80, 'Imitativos batida', 2, 4),
(49, 'Fuerza velocidad', 80, 'Multisaltos vallas', 3, 6),
(50, 'Fuerza velocidad', 80, 'Mult. vallas rebote', 2, 6),
(51, 'Fuerza velocidad', 90, 'Imitativos batida', 2, 4),
(52, 'Fuerza velocidad', 90, 'Multisaltos vallas', 3, 6),
(53, 'Fuerza velocidad', 90, 'Mult. vallas rebote', 2, 6),
(54, 'Fuerza velocidad', 100, 'Imitativos batida', 3, 4),
(55, 'Fuerza velocidad', 100, 'Multisaltos vallas', 3, 6),
(56, 'Fuerza velocidad', 100, 'Mult. vallas rebote', 3, 6),
(57, 'Velocidad tecnica', 40, 'Imitativos batida', 1, 3),
(58, 'Velocidad tecnica', 40, 'Multisaltos vallas', 1, 5),
(59, 'Velocidad tecnica', 40, 'Mult. vallas rebote', 1, 5),
(60, 'Velocidad tecnica', 50, 'Imitativos batida', 1, 3),
(61, 'Velocidad tecnica', 50, 'Multisaltos vallas', 2, 5),
(62, 'Velocidad tecnica', 50, 'Mult. vallas rebote', 1, 5),
(63, 'Velocidad tecnica', 60, 'Imitativos batida', 1, 3),
(64, 'Velocidad tecnica', 60, 'Multisaltos vallas', 2, 5),
(65, 'Velocidad tecnica', 60, 'Mult. vallas rebote', 2, 5),
(66, 'Velocidad tecnica', 70, 'Imitativos batida', 2, 3),
(67, 'Velocidad tecnica', 70, 'Multisaltos vallas', 2, 5),
(68, 'Velocidad tecnica', 70, 'Mult. vallas rebote', 2, 5),
(69, 'Velocidad tecnica', 80, 'Imitativos batida', 2, 3),
(70, 'Velocidad tecnica', 80, 'Multisaltos vallas', 3, 5),
(71, 'Velocidad tecnica', 80, 'Mult. vallas rebote', 2, 5),
(72, 'Velocidad tecnica', 90, 'Imitativos batida', 2, 3),
(73, 'Velocidad tecnica', 90, 'Multisaltos vallas', 3, 5),
(74, 'Velocidad tecnica', 90, 'Mult. vallas rebote', 2, 5),
(75, 'Velocidad tecnica', 100, 'Imitativos batida', 3, 3),
(76, 'Velocidad tecnica', 100, 'Multisaltos vallas', 3, 5),
(77, 'Velocidad tecnica', 100, 'Mult. vallas rebote', 3, 5),
(78, 'Modelacion competitiva', 40, 'Multisaltos vallas', 1, 5),
(79, 'Modelacion competitiva', 50, 'Multisaltos vallas', 2, 5),
(80, 'Modelacion competitiva', 60, 'Multisaltos vallas', 2, 5),
(81, 'Modelacion competitiva', 70, 'Multisaltos vallas', 2, 5),
(82, 'Modelacion competitiva', 80, 'Multisaltos vallas', 3, 5),
(83, 'Modelacion competitiva', 90, 'Multisaltos vallas', 3, 5),
(84, 'Modelacion competitiva', 100, 'Multisaltos vallas', 3, 5),
(85, 'Competitivo', 40, 'Multisaltos vallas', 1, 5),
(86, 'Competitivo', 50, 'Multisaltos vallas', 2, 5),
(87, 'Competitivo', 60, 'Multisaltos vallas', 2, 5),
(88, 'Competitivo', 70, 'Multisaltos vallas', 2, 5),
(89, 'Competitivo', 80, 'Multisaltos vallas', 3, 5),
(90, 'Competitivo', 90, 'Multisaltos vallas', 3, 5),
(91, 'Competitivo', 100, 'Multisaltos vallas', 3, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `planificacion`
--

CREATE TABLE IF NOT EXISTS `planificacion` (
  `Id` int(5) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(30) NOT NULL,
  `Id_entrenador` varchar(30) NOT NULL,
  `Temporada` varchar(30) NOT NULL,
  `Periodo` varchar(30) NOT NULL,
  `P_marcha` varchar(5) NOT NULL,
  `A_funcional` varchar(5) NOT NULL,
  `Int_p_marcha` varchar(5) NOT NULL,
  `Int_a_funcional` varchar(5) NOT NULL,
  `Prep_general` varchar(5) NOT NULL,
  `Fuerza` varchar(5) NOT NULL,
  `F_velocidad` varchar(5) NOT NULL,
  `Int_fuerza` varchar(5) NOT NULL,
  `Int_f_velocidad` varchar(5) NOT NULL,
  `Prep_especial` varchar(5) NOT NULL,
  `V_tecnica` varchar(5) NOT NULL,
  `M_competitiva` varchar(5) NOT NULL,
  `Int_v_tecnica` varchar(5) NOT NULL,
  `Int_m_competitiva` varchar(5) NOT NULL,
  `Prep_tecnica` varchar(5) NOT NULL,
  `Competitivo` varchar(5) NOT NULL,
  `Int_competitivo` varchar(5) NOT NULL,
  `Per_competitivo` varchar(5) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `planificacion`
--

INSERT INTO `planificacion` (`Id`, `Nombre`, `Id_entrenador`, `Temporada`, `Periodo`, `P_marcha`, `A_funcional`, `Int_p_marcha`, `Int_a_funcional`, `Prep_general`, `Fuerza`, `F_velocidad`, `Int_fuerza`, `Int_f_velocidad`, `Prep_especial`, `V_tecnica`, `M_competitiva`, `Int_v_tecnica`, `Int_m_competitiva`, `Prep_tecnica`, `Competitivo`, `Int_competitivo`, `Per_competitivo`) VALUES
(1, 'Plan1', 'Miklos', '2017/2018', 'Aire libre', '0', '2', '0', '1', '1', '4', '4', '2', '3', '1', '3', '3', '4', '4', '1', '8', '5', '1'),
(2, 'Plan2', 'Miklos', '2018/2019', 'Pista cubierta', '2', '3', '1', '2', '1', '4', '4', '3', '3', '1', '4', '0', '4', '0', '1', '6', '5', '1'),
(3, 'plan3', 'Miklos', '2020/2021', 'Pista cubierta', '2', '4', '1', '1', '1', '4', '4', '2', '3', '1', '3', '0', '4', '0', '1', '7', '5', '1'),
(4, 'plan4auto', 'Miklos', '2019/2020', 'Aire libre', '0', '0', '0', '0', '0', '3', '3', '2', '3', '1', '3', '2', '4', '4', '1', '4', '5', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resultados_atleta`
--

CREATE TABLE IF NOT EXISTS `resultados_atleta` (
  `Id` int(5) NOT NULL AUTO_INCREMENT,
  `Id_atleta` int(5) NOT NULL,
  `Fecha` varchar(20) NOT NULL,
  `Competicion` varchar(30) NOT NULL,
  `Lugar` varchar(30) NOT NULL,
  `Posicion` varchar(4) NOT NULL,
  `Prueba` varchar(30) NOT NULL,
  `Marca` varchar(10) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `resultados_atleta`
--

INSERT INTO `resultados_atleta` (`Id`, `Id_atleta`, `Fecha`, `Competicion`, `Lugar`, `Posicion`, `Prueba`, `Marca`) VALUES
(1, 3, '20/10/2011', 'C. de España', 'Madrid', '1º', 'Salto de altura', '2.16'),
(2, 3, '15/11/2011', 'C. Cataluña', 'Barcelona', '2º', 'Salto de altura', '2.05');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rodar`
--

CREATE TABLE IF NOT EXISTS `rodar` (
  `Id` int(5) NOT NULL,
  `Mesociclo` varchar(30) NOT NULL,
  `Tiempo` varchar(30) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `rodar`
--

INSERT INTO `rodar` (`Id`, `Mesociclo`, `Tiempo`) VALUES
(1, 'Puesta en marcha', '45min'),
(2, 'Adaptacion funcional', '45min'),
(3, 'Fuerza', '30min'),
(4, 'Fuerza velocidad', '30min'),
(5, 'Velocidad tecnica', '20min'),
(6, 'Modelacion competitiva', '15min'),
(7, 'Competitivo', '15min');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `semana_mesociclo`
--

CREATE TABLE IF NOT EXISTS `semana_mesociclo` (
  `Id` int(5) NOT NULL AUTO_INCREMENT,
  `Id_planificacion` int(5) NOT NULL,
  `Mesociclo` varchar(30) NOT NULL,
  `Semana` int(5) NOT NULL,
  `Dia` varchar(30) NOT NULL,
  `U_entrenamiento1` varchar(10) NOT NULL,
  `U_entrenamiento2` varchar(10) NOT NULL,
  `U_entrenamiento3` varchar(10) NOT NULL,
  `U_entrenamiento4` varchar(10) NOT NULL,
  `U_entrenamiento5` varchar(10) NOT NULL,
  `U_entrenamiento6` varchar(10) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Volcado de datos para la tabla `semana_mesociclo`
--

INSERT INTO `semana_mesociclo` (`Id`, `Id_planificacion`, `Mesociclo`, `Semana`, `Dia`, `U_entrenamiento1`, `U_entrenamiento2`, `U_entrenamiento3`, `U_entrenamiento4`, `U_entrenamiento5`, `U_entrenamiento6`) VALUES
(1, 3, 'Puesta en marcha', 1, 'Lunes', 'ROD', 'F', '---', 'MV', '---', '---'),
(2, 3, 'Puesta en marcha', 1, 'Martes', 'ET', 'T', '---', '---', '---', '---'),
(3, 3, 'Puesta en marcha', 1, 'Miércoles', 'ROD', 'F', '---', 'MH', '---', '---'),
(4, 3, 'Puesta en marcha', 1, 'Jueves', 'ROD', '---', '---', '---', '---', '---'),
(5, 3, 'Puesta en marcha', 1, 'Viernes', 'ET', 'T', '---', '---', '---', '---'),
(6, 3, 'Puesta en marcha', 1, 'Sábado', 'ROD', 'MN', '---', '---', '---', '---'),
(7, 3, 'Puesta en marcha', 1, 'Domingo', '---', '---', '---', '---', '---', '---'),
(8, 2, 'Competitivo', 23, 'Lunes', 'F', '---', '---', 'F', '---', '---'),
(9, 2, 'Competitivo', 23, 'Martes', 'MN', '---', '---', 'MH', '---', '---'),
(10, 2, 'Competitivo', 23, 'Miércoles', 'MV', '---', '---', 'ROD', '---', '---'),
(11, 2, 'Competitivo', 23, 'Jueves', 'CR', '---', '---', 'VEL', '---', '---'),
(12, 2, 'Competitivo', 23, 'Viernes', 'CUE', '---', '---', 'ARR', '---', '---'),
(13, 2, 'Competitivo', 23, 'Sábado', 'ET', '---', '---', 'T', '---', '---'),
(14, 2, 'Competitivo', 23, 'Domingo', 'F', '---', '---', 'F', '---', '---'),
(15, 1, 'Modelación competitiva', 16, 'Lunes', 'F', 'ROD', 'VEL', 'MN', 'CR', 'ARR'),
(16, 1, 'Modelación competitiva', 16, 'Martes', 'F', '---', '---', 'MN', '---', '---'),
(17, 1, 'Modelación competitiva', 16, 'Miércoles', 'F', '---', '---', 'MN', '---', '---'),
(18, 1, 'Modelación competitiva', 16, 'Jueves', 'F', '---', '---', 'MN', '---', '---'),
(19, 1, 'Modelación competitiva', 16, 'Viernes', 'MH', '---', '---', 'ROD', '---', '---'),
(20, 1, 'Modelación competitiva', 16, 'Sábado', 'MH', '---', '---', 'ROD', '---', '---'),
(21, 1, 'Modelación competitiva', 16, 'Domingo', 'MH', '---', '---', 'ROD', '---', '---'),
(22, 2, 'Adaptación funcional', 5, 'Lunes', 'F', 'F', 'MN', 'MH', 'MV', '---'),
(23, 2, 'Adaptación funcional', 5, 'Martes', 'ROD', 'CR', 'VEL', 'ET', 'T', '---'),
(24, 2, 'Adaptación funcional', 5, 'Miércoles', '---', '---', '---', '---', '---', '---'),
(25, 2, 'Adaptación funcional', 5, 'Jueves', '---', '---', '---', '---', '---', '---'),
(26, 2, 'Adaptación funcional', 5, 'Viernes', '---', '---', '---', '---', '---', '---'),
(27, 2, 'Adaptación funcional', 5, 'Sábado', '---', '---', '---', '---', '---', '---'),
(28, 2, 'Adaptación funcional', 5, 'Domingo', 'T', '---', '---', '---', '---', '---'),
(29, 1, 'Adaptación funcional', 1, 'Lunes', 'F', 'CUE', '---', 'ET', '---', '---'),
(30, 1, 'Adaptación funcional', 1, 'Martes', 'ET', 'T', '---', 'CR', '---', '---'),
(31, 1, 'Adaptación funcional', 1, 'Miércoles', '---', '---', '---', '---', '---', '---'),
(32, 1, 'Adaptación funcional', 1, 'Jueves', 'MN', 'ARR', 'MH', '---', '---', '---'),
(33, 1, 'Adaptación funcional', 1, 'Viernes', 'F', 'MV', '---', 'ET', '---', '---'),
(34, 1, 'Adaptación funcional', 1, 'Sábado', '---', '---', '---', '---', '---', '---'),
(35, 1, 'Adaptación funcional', 1, 'Domingo', '---', '---', '---', '---', '---', '---');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tecnica`
--

CREATE TABLE IF NOT EXISTS `tecnica` (
  `Id` int(5) NOT NULL,
  `Mesociclo` varchar(30) NOT NULL,
  `Volumen` int(5) NOT NULL,
  `Ejercicio` varchar(30) NOT NULL,
  `Saltos` int(5) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tecnica`
--

INSERT INTO `tecnica` (`Id`, `Mesociclo`, `Volumen`, `Ejercicio`, `Saltos`) VALUES
(1, 'Puesta en marcha', 40, 'Tijeras falicitadas - III 4 p.', 10),
(2, 'Puesta en marcha', 50, 'Tijeras falicitadas - III 4 p.', 10),
(3, 'Puesta en marcha', 60, 'Tijeras falicitadas - III 4 p.', 15),
(4, 'Puesta en marcha', 70, 'Tijeras falicitadas - III 4 p.', 15),
(5, 'Puesta en marcha', 80, 'Tijeras falicitadas - III 4 p.', 20),
(6, 'Puesta en marcha', 90, 'Tijeras falicitadas - III 4 p.', 20),
(7, 'Puesta en marcha', 100, 'Tijeras falicitadas - III 4 p.', 25),
(8, 'Adaptacion funcional', 40, 'Tijeras falicitadas - III 4 p.', 8),
(9, 'Adaptacion funcional', 40, 'Flop facilitado - III 6 p.l.', 8),
(10, 'Adaptacion funcional', 50, 'Tijeras falicitadas - III 4 p.', 8),
(11, 'Adaptacion funcional', 50, 'Flop facilitado - III 6 p.l.', 10),
(12, 'Adaptacion funcional', 60, 'Tijeras falicitadas - III 4 p.', 8),
(13, 'Adaptacion funcional', 60, 'Flop facilitado - III 6 p.l.', 10),
(14, 'Adaptacion funcional', 70, 'Tijeras falicitadas - III 4 p.', 8),
(15, 'Adaptacion funcional', 70, 'Flop facilitado - III 6 p.l.', 10),
(16, 'Adaptacion funcional', 80, 'Tijeras falicitadas - III 4 p.', 8),
(17, 'Adaptacion funcional', 80, 'Flop facilitado - III 6 p.l.', 15),
(18, 'Adaptacion funcional', 90, 'Tijeras falicitadas - III 4 p.', 8),
(19, 'Adaptacion funcional', 90, 'Flop facilitado - III 6 p.l.', 15),
(20, 'Adaptacion funcional', 100, 'Tijeras falicitadas - III 4 p.', 8),
(21, 'Adaptacion funcional', 100, 'Flop facilitado - III 6 p.l.', 20),
(22, 'Fuerza', 40, 'Tijeras falicitadas - III 4 p.', 10),
(23, 'Fuerza', 40, 'Flop facilitado - III 6 p.l.', 10),
(24, 'Fuerza', 50, 'Tijeras falicitadas - III 4 p.', 10),
(25, 'Fuerza', 50, 'Flop facilitado - III 6 p.l.', 15),
(26, 'Fuerza', 60, 'Tijeras falicitadas - III 4 p.', 10),
(27, 'Fuerza', 60, 'Flop facilitado - III 6 p.l.', 15),
(28, 'Fuerza', 70, 'Tijeras falicitadas - III 4 p.', 10),
(29, 'Fuerza', 70, 'Flop facilitado - III 6 p.l.', 15),
(30, 'Fuerza', 80, 'Tijeras falicitadas - III 4 p.', 10),
(31, 'Fuerza', 80, 'Flop facilitado - III 6 p.l.', 20),
(32, 'Fuerza', 90, 'Tijeras falicitadas - III 4 p.', 10),
(33, 'Fuerza', 90, 'Flop facilitado - III 6 p.l.', 20),
(34, 'Fuerza', 100, 'Tijeras falicitadas - III 4 p.', 10),
(35, 'Fuerza', 100, 'Flop facilitado - III 6 p.l.', 25),
(36, 'Fuerza velocidad', 40, 'Tijeras falicitadas - II 4 p.l', 10),
(37, 'Fuerza velocidad', 40, 'Flop facilitado - II 6 p.l.', 10),
(38, 'Fuerza velocidad', 50, 'Tijeras falicitadas - II 4 p.l', 10),
(39, 'Fuerza velocidad', 50, 'Flop facilitado - II 6 p.l.', 15),
(40, 'Fuerza velocidad', 60, 'Tijeras falicitadas - II 4 p.l', 10),
(41, 'Fuerza velocidad', 60, 'Flop facilitado - II 6 p.l.', 15),
(42, 'Fuerza velocidad', 70, 'Tijeras falicitadas - II 4 p.l', 10),
(43, 'Fuerza velocidad', 70, 'Flop facilitado - II 6 p.l.', 15),
(44, 'Fuerza velocidad', 80, 'Tijeras falicitadas - II 4 p.l', 10),
(45, 'Fuerza velocidad', 80, 'Flop facilitado - II 6 p.l.', 20),
(46, 'Fuerza velocidad', 90, 'Tijeras falicitadas - II 4 p.l', 10),
(47, 'Fuerza velocidad', 90, 'Flop facilitado - II 6 p.l.', 20),
(48, 'Fuerza velocidad', 100, 'Tijeras falicitadas - II 4 p.l', 10),
(49, 'Fuerza velocidad', 100, 'Flop facilitado - II 6 p.l.', 25),
(50, 'Velocidad tecnica', 40, 'Flop facilitado - I 6 p.l.', 15),
(51, 'Velocidad tecnica', 50, 'Flop facilitado - I 6 p.l.', 15),
(52, 'Velocidad tecnica', 60, 'Flop facilitado - I 6 p.l.', 20),
(53, 'Velocidad tecnica', 70, 'Flop facilitado - I 6 p.l.', 20),
(54, 'Velocidad tecnica', 80, 'Flop facilitado - I 6 p.l.', 25),
(55, 'Velocidad tecnica', 90, 'Flop facilitado - I 6 p.l.', 25),
(56, 'Velocidad tecnica', 100, 'Flop facilitado - I 6 p.l.', 30),
(57, 'Modelacion competitiva', 40, 'Flop estandar compl.', 10),
(58, 'Modelacion competitiva', 50, 'Flop estandar compl.', 10),
(59, 'Modelacion competitiva', 60, 'Flop estandar compl.', 10),
(60, 'Modelacion competitiva', 70, 'Flop estandar compl.', 15),
(61, 'Modelacion competitiva', 80, 'Flop estandar compl.', 15),
(62, 'Modelacion competitiva', 90, 'Flop estandar compl.', 20),
(63, 'Modelacion competitiva', 100, 'Flop estandar compl.', 20),
(64, 'Competitivo', 40, 'Flop estandar compl.', 10),
(65, 'Competitivo', 50, 'Flop estandar compl.', 10),
(66, 'Competitivo', 60, 'Flop estandar compl.', 10),
(67, 'Competitivo', 70, 'Flop estandar compl.', 10),
(68, 'Competitivo', 80, 'Flop estandar compl.', 15),
(69, 'Competitivo', 90, 'Flop estandar compl.', 15),
(70, 'Competitivo', 100, 'Flop estandar compl.', 15);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `volumenes_planificacion`
--

CREATE TABLE IF NOT EXISTS `volumenes_planificacion` (
  `Id` int(5) NOT NULL AUTO_INCREMENT,
  `Id_planificacion` int(5) NOT NULL,
  `Ciclo` varchar(30) NOT NULL,
  `Mesociclo` varchar(30) NOT NULL,
  `Semana` varchar(5) NOT NULL,
  `Volumen` int(5) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=87 ;

--
-- Volcado de datos para la tabla `volumenes_planificacion`
--

INSERT INTO `volumenes_planificacion` (`Id`, `Id_planificacion`, `Ciclo`, `Mesociclo`, `Semana`, `Volumen`) VALUES
(1, 1, 'Preparación General', 'Adaptación funcional', '1', 50),
(2, 1, 'Preparación General', 'Adaptación funcional', '2', 60),
(3, 1, 'Preparación Especial', 'Fuerza', '3', 60),
(4, 1, 'Preparación Especial', 'Fuerza', '4', 70),
(5, 1, 'Preparación Especial', 'Fuerza', '5', 80),
(6, 1, 'Preparación Especial', 'Fuerza', '6', 60),
(7, 1, 'Preparación Especial', 'Fuerza velocidad', '7', 60),
(8, 1, 'Preparación Especial', 'Fuerza velocidad', '8', 80),
(9, 1, 'Preparación Especial', 'Fuerza velocidad', '9', 90),
(10, 1, 'Preparación Especial', 'Fuerza velocidad', '10', 60),
(11, 1, 'Preparación Técnica', 'Velocidad técnica', '11', 70),
(12, 1, 'Preparación Técnica', 'Velocidad técnica', '12', 90),
(13, 1, 'Preparación Técnica', 'Velocidad técnica', '13', 100),
(14, 1, 'Preparación Técnica', 'Modelación competitiva', '14', 80),
(15, 1, 'Preparación Técnica', 'Modelación competitiva', '15', 60),
(16, 1, 'Preparación Técnica', 'Modelación competitiva', '16', 50),
(17, 1, 'Periodo Competitivo', 'Competitivo', '17', 40),
(18, 1, 'Periodo Competitivo', 'Competitivo', '18', 40),
(19, 1, 'Periodo Competitivo', 'Competitivo', '19', 40),
(20, 1, 'Periodo Competitivo', 'Competitivo', '20', 40),
(21, 1, 'Periodo Competitivo', 'Competitivo', '21', 40),
(22, 1, 'Periodo Competitivo', 'Competitivo', '22', 40),
(23, 1, 'Periodo Competitivo', 'Competitivo', '23', 40),
(24, 1, 'Periodo Competitivo', 'Competitivo', '24', 40),
(25, 2, 'Preparación General', 'Puesta en marcha', '1', 50),
(26, 2, 'Preparación General', 'Puesta en marcha', '2', 60),
(27, 2, 'Preparación General', 'Adaptación funcional', '3', 70),
(28, 2, 'Preparación General', 'Adaptación funcional', '4', 80),
(29, 2, 'Preparación General', 'Adaptación funcional', '5', 90),
(30, 2, 'Preparación Especial', 'Fuerza', '6', 70),
(31, 2, 'Preparación Especial', 'Fuerza', '7', 100),
(32, 2, 'Preparación Especial', 'Fuerza', '8', 90),
(33, 2, 'Preparación Especial', 'Fuerza', '9', 50),
(34, 2, 'Preparación Especial', 'Fuerza velocidad', '10', 70),
(35, 2, 'Preparación Especial', 'Fuerza velocidad', '11', 100),
(36, 2, 'Preparación Especial', 'Fuerza velocidad', '12', 70),
(37, 2, 'Preparación Especial', 'Fuerza velocidad', '13', 50),
(38, 2, 'Preparación Técnica', 'Velocidad técnica', '14', 90),
(39, 2, 'Preparación Técnica', 'Velocidad técnica', '15', 70),
(40, 2, 'Preparación Técnica', 'Velocidad técnica', '16', 80),
(41, 2, 'Preparación Técnica', 'Velocidad técnica', '17', 50),
(42, 2, 'Periodo Competitivo', 'Competitivo', '18', 40),
(43, 2, 'Periodo Competitivo', 'Competitivo', '19', 40),
(44, 2, 'Periodo Competitivo', 'Competitivo', '20', 40),
(45, 2, 'Periodo Competitivo', 'Competitivo', '21', 30),
(46, 2, 'Periodo Competitivo', 'Competitivo', '22', 30),
(47, 2, 'Periodo Competitivo', 'Competitivo', '23', 30),
(48, 3, 'Preparación General', 'Puesta en marcha', '1', 50),
(49, 3, 'Preparación General', 'Puesta en marcha', '2', 60),
(50, 3, 'Preparación General', 'Adaptación funcional', '3', 70),
(51, 3, 'Preparación General', 'Adaptación funcional', '4', 80),
(52, 3, 'Preparación General', 'Adaptación funcional', '5', 90),
(53, 3, 'Preparación General', 'Adaptación funcional', '6', 90),
(54, 3, 'Preparación Especial', 'Fuerza', '7', 100),
(55, 3, 'Preparación Especial', 'Fuerza', '8', 100),
(56, 3, 'Preparación Especial', 'Fuerza', '9', 100),
(57, 3, 'Preparación Especial', 'Fuerza', '10', 100),
(58, 3, 'Preparación Especial', 'Fuerza velocidad', '11', 100),
(59, 3, 'Preparación Especial', 'Fuerza velocidad', '12', 100),
(60, 3, 'Preparación Especial', 'Fuerza velocidad', '13', 90),
(61, 3, 'Preparación Especial', 'Fuerza velocidad', '14', 90),
(62, 3, 'Preparación Técnica', 'Velocidad técnica', '15', 80),
(63, 3, 'Preparación Técnica', 'Velocidad técnica', '16', 70),
(64, 3, 'Preparación Técnica', 'Velocidad técnica', '17', 60),
(65, 3, 'Periodo Competitivo', 'Competitivo', '18', 40),
(66, 3, 'Periodo Competitivo', 'Competitivo', '19', 40),
(67, 3, 'Periodo Competitivo', 'Competitivo', '20', 40),
(68, 3, 'Periodo Competitivo', 'Competitivo', '21', 40),
(69, 3, 'Periodo Competitivo', 'Competitivo', '22', 40),
(70, 3, 'Periodo Competitivo', 'Competitivo', '23', 40),
(71, 3, 'Periodo Competitivo', 'Competitivo', '24', 40),
(72, 4, 'Preparación Especial', 'Fuerza', '1', 70),
(73, 4, 'Preparación Especial', 'Fuerza', '2', 90),
(74, 4, 'Preparación Especial', 'Fuerza', '3', 100),
(75, 4, 'Preparación Especial', 'Fuerza velocidad', '4', 70),
(76, 4, 'Preparación Especial', 'Fuerza velocidad', '5', 100),
(77, 4, 'Preparación Especial', 'Fuerza velocidad', '6', 80),
(78, 4, 'Preparación Técnica', 'Velocidad técnica', '7', 100),
(79, 4, 'Preparación Técnica', 'Velocidad técnica', '8', 70),
(80, 4, 'Preparación Técnica', 'Velocidad técnica', '9', 80),
(81, 4, 'Preparación Técnica', 'Modelación competitiva', '10', 70),
(82, 4, 'Preparación Técnica', 'Modelación competitiva', '11', 50),
(83, 4, 'Periodo Competitivo', 'Competitivo', '12', 40),
(84, 4, 'Periodo Competitivo', 'Competitivo', '13', 40),
(85, 4, 'Periodo Competitivo', 'Competitivo', '14', 40),
(86, 4, 'Periodo Competitivo', 'Competitivo', '15', 40);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
