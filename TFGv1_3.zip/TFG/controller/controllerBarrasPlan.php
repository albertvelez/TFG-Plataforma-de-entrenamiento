<?php
	require("../model/model.php");

	$id = $_GET['id'];

	$datos_planificacion = datos_planificacion($id);

	while($obj = $datos_planificacion->fetch_object()){
	    $dato = $obj;
	}
	
	$nombre = $dato->Nombre;
	$temporada =  $dato->Temporada;
	$periodo = $dato->Periodo;
	$p_marcha = $dato->P_marcha;
	$a_funcional = $dato->A_funcional;
	$int_p_marcha = $dato->Int_p_marcha;
	$int_a_funcional =  $dato->Int_a_funcional;
	$prep_general = $dato->Prep_general;
	$fuerza = $dato->Fuerza;
	$f_velocidad = $dato->F_velocidad;
	$int_fuerza = $dato->Int_fuerza;
	$int_f_velocidad =  $dato->Int_f_velocidad;
	$prep_especial = $dato->Prep_especial;
	$v_tecnica = $dato->V_tecnica;
	$m_competitiva = $dato->M_competitiva;
	$int_v_tecnica = $dato->Int_v_tecnica;
	$int_m_competitiva =  $dato->Int_m_competitiva;
	$prep_tecnica = $dato->Prep_tecnica;
	$competitivo = $dato->Competitivo;
	$int_competitivo = $dato->Int_competitivo; 
	$per_competitivo = $dato->Per_competitivo;

	$datos_volumen = datos_volumen($id);
	$volumen = array();
	while($row = $datos_volumen->fetch_assoc()){
		$volumen[]= $row;
	}

	$datos_volumen = datos_volumen($id);
	$volumen1 = array();
	while($row = $datos_volumen->fetch_assoc()){
		$volumen1[]= $row;
	}

	$datos_volumen = datos_volumen($id);
	$volumen2 = array();
	while($row = $datos_volumen->fetch_assoc()){
		$volumen2[]= $row;
	}

	$datos_volumen = datos_volumen($id);
	$volumen3 = array();
	while($row = $datos_volumen->fetch_assoc()){
		$volumen3[]= $row;
	}

	$datos_volumen = datos_volumen($id);
	$volumen4 = array();
	while($row = $datos_volumen->fetch_assoc()){
		$volumen4[]= $row;
	}

	$datos_volumen = datos_volumen($id);
	$volumen5 = array();
	while($row = $datos_volumen->fetch_assoc()){
		$volumen5[]= $row;
	}

	$datos_volumen = datos_volumen($id);
	$volumen6 = array();
	while($row = $datos_volumen->fetch_assoc()){
		$volumen6[]= $row;
	}

	require("../view/vistaBarrasPlan.php");      
?>