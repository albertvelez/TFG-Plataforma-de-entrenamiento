<?php
	require("./model/model.php");

	$id = $_GET['id'];
	$temporada = $_GET['temporada'];
	$periodo = $_GET['periodo'];
	$mesociclo = $_GET['mesociclo'];
	$semana = $_GET['semana'];
    
    $dia_semana = array("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo");
?>