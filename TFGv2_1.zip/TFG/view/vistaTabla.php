<div class="row mx-auto">
<?php
    foreach($semana as $semana){ 
?>
      <div class="col-12 col-sm-6 col-md-4 col-lg-3">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th colspan="2" scope="col" class="text-center bg-info"><?php echo $semana['Dia'];?></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="text-center table-info"><b>Mañana</b></td>
              <td class="text-center table-info"><b>Tarde</b></td>
            </tr>
            <tr>
              <td style="background-color: <?php echo $color = color($semana['U_entrenamiento1']);?>" class="text-center"><?php echo $semana['U_entrenamiento1'];?></td>
              <td style="background-color: <?php echo $color = color($semana['U_entrenamiento4']);?>" class="text-center"><?php echo $semana['U_entrenamiento4'];?></td>
            </tr>
            <tr>
              <td style="background-color: <?php echo $color = color($semana['U_entrenamiento2']);?>" class="text-center"><?php echo $semana['U_entrenamiento2'];?></td>
              <td style="background-color: <?php echo $color = color($semana['U_entrenamiento5']);?>" class="text-center"><?php echo $semana['U_entrenamiento5'];?></td>
            </tr>
            <tr>
              <td style="background-color: <?php echo $color = color($semana['U_entrenamiento3']);?>" class="text-center"><?php echo $semana['U_entrenamiento3'];?></td>
              <td style="background-color: <?php echo $color = color($semana['U_entrenamiento6']);?>" class="text-center"><?php echo $semana['U_entrenamiento6'];?></td>
            </tr>
            <tr>
              <td colspan="2" class="text-center"><button class="btn btn-succes" type="button" onclick="">Generar Entrenamiento</button></td>
            </tr>
          </tbody>
        </table>
      </div>
<?php
    }              
?>
</div>

<?php
  function color($u_e){

    if ($u_e == "F1" || $u_e =="F2"){
      $color = "#ffffcc";
    }
    if ($u_e == "MN"){
      $color = "#ccffcc";
    }
    if ($u_e == "MV" || $u_e =="MH"){
      $color = "#ccffff";
    }
    if ($u_e == "ROD" || $u_e =="CUE" || $u_e =="CR" || $u_e =="ARR" || $u_e =="VEL"){
      $color = "#ccccff";
    }
    if ($u_e == "ET" || $u_e =="T"){
      $color = "#ffcccc";
    }
    if ($u_e == "---"){
      $color = "#ffffff";
    }
    return $color;
  }
?>