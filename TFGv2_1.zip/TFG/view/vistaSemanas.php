<option value="0">-----</option>
<?php
    foreach($semanas as $semana){ 
?>
        <option value="<?php echo $semana['Semana'];?>"><?php echo $semana['Semana'];?></option>

<?php
    }              
?> 