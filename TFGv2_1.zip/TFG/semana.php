<?php session_start(); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <script src="js/javascript.js"></script>
    
    <!-- CSS -->
    <style>
     /*header {padding: 154px 0 100px;}*/
     section {padding: 100px 0;}
     .slider{
        background: url("images/hj1.jpg");
        height: 50vh;
        background-size: cover;
        background-position: center;
      }
    </style>

    <title>Plataforma de Entrenamiento</title>
  </head>
  <body>

    <?php require("./view/vistaNav.php"); ?>
    <?php require("./controller/controllerSemana.php"); ?>

    <section id="semana">
      <div class="container">
        <div class="row">
          <div class="col mx-auto bg-light">
            </br>
            <h3>Semana <?php echo $semana;?></h3>
            <h5><?php echo $mesociclo;?></h5>
            <h6><?php echo $temporada;?> - <?php echo $periodo;?></h6>
            </br>
            </br>
             <p class="lead"><b>Objetivo mesociclo</b></p>
            </br>
            <form method="post" action="controller/controllerSemanaMesociclo.php?id=<?php echo $id;?>&mesociclo=<?php echo $mesociclo;?>&semana=<?php echo $semana;?>">
              <div class="row">
              <?php $dia = 1;?>
              <?php for ($i = 0; $i < 4; $i++) { ?>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                  <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th colspan="2" scope="col" class="text-center bg-info"><?php echo $dia_semana[$i];?></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td class="text-center table-info"><b>Mañana</b></td>
                        <td class="text-center table-info"><b>Tarde</b></td>
                      </tr>
                      <?php $sesion = 1;?>
                      <?php for ($j = 0; $j < 3; $j++) { ?>
                      <tr>
                        <?php for ($k = 0; $k < 2; $k++) { ?>
                        <td>
                          <select name="u_entrenamiento_<?php echo $dia;?>_<?php echo $sesion;?>" class="form-control form-control-sm" onchange="this.style.backgroundColor=this.options[this.selectedIndex].style.backgroundColor">
                              <option style="background-color: #ffffff" value="---">---</option>
                            <optgroup style="background-color: #ffffcc" label="Fuerza">
                              <option style="background-color: #ffffcc" value="F1">F1</option>
                              <option style="background-color: #ffffcc" value="F2">F2</option>
                            </optgroup>
                            <optgroup style="background-color: #ccffcc" label="Monoarti.">
                              <option style="background-color: #ccffcc" value="MN">MN</option>
                            </optgroup>
                            <optgroup style="background-color: #ccffff" label="Multisaltos">
                              <option style="background-color: #ccffff" value="MH">MH</option>
                              <option style="background-color: #ccffff" value="MV">MV</option>
                            </optgroup>
                            <optgroup style="background-color: #ccccff" label="Carrera">
                              <option style="background-color: #ccccff" value="ROD">ROD</option>
                              <option style="background-color: #ccccff" value="CR">CR</option>
                              <option style="background-color: #ccccff" value="VEL">VEL</option>
                              <option style="background-color: #ccccff" value="CUE">CUE</option>
                              <option style="background-color: #ccccff" value="ARR">ARR</option>
                            </optgroup>
                             <optgroup style="background-color: #ffcccc" label="Técnica">
                              <option style="background-color: #ffcccc" value="ET">ET</option>
                              <option style="background-color: #ffcccc" value="T">T</option>
                            </optgroup>
                          </select>
                        </td>
                        <?php $sesion++;?>
                        <?php } ?>
                      </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
                <?php $dia++;?>
              <?php } ?>
              </div>
              <div class="row">
              <?php for ($i = 4; $i < 7; $i++) { ?>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                  <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th colspan="2" scope="col" class="text-center bg-info"><?php echo $dia_semana[$i];?></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td class="text-center table-info"><b>Mañana</b></td>
                        <td class="text-center table-info"><b>Tarde</b></td>
                      </tr>
                      <?php $sesion = 1;?>
                      <?php for ($j = 0; $j < 3; $j++) { ?>
                      <tr>
                        <?php for ($k = 0; $k < 2; $k++) { ?>
                        <td>
                         <select name="u_entrenamiento_<?php echo $dia;?>_<?php echo $sesion;?>" class="form-control form-control-sm" onchange="this.style.backgroundColor=this.options[this.selectedIndex].style.backgroundColor">
                              <option style="background-color: #ffffff" value="---">---</option>
                            <optgroup style="background-color: #ffffcc" label="Fuerza">
                              <option style="background-color: #ffffcc" value="F1">F1</option>
                              <option style="background-color: #ffffcc" value="F2">F2</option>
                            </optgroup>
                            <optgroup style="background-color: #ccffcc" label="Monoarti.">
                              <option style="background-color: #ccffcc" value="MN">MN</option>
                            </optgroup>
                            <optgroup style="background-color: #ccffff" label="Multisaltos">
                              <option style="background-color: #ccffff" value="MH">MH</option>
                              <option style="background-color: #ccffff" value="MV">MV</option>
                            </optgroup>
                            <optgroup style="background-color: #ccccff" label="Carrera">
                              <option style="background-color: #ccccff" value="ROD">ROD</option>
                              <option style="background-color: #ccccff" value="CR">CR</option>
                              <option style="background-color: #ccccff" value="VEL">VEL</option>
                              <option style="background-color: #ccccff" value="CUE">CUE</option>
                              <option style="background-color: #ccccff" value="ARR">ARR</option>
                            </optgroup>
                             <optgroup style="background-color: #ffcccc" label="Técnica">
                              <option style="background-color: #ffcccc" value="ET">ET</option>
                              <option style="background-color: #ffcccc" value="T">T</option>
                            </optgroup>
                          </select>
                        </td>
                        <?php $sesion++;?>
                        <?php } ?>
                      </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
                <?php $dia++;?>
              <?php } ?>
                <div class="col">
                </div>
              </div>
              <hr />
              </br>
              <div class="form-group">
                <button type="submit" class="btn btn-primary">Guardar unidades para esta semana</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Plataforma de Entrenamiento 2018</p>
      </div>
    </footer>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>