//Funcion que construye un objeto xmlhttp, devuelve un objeto xmlhttp
function getXMLHTTP()
{
  var xmlhttp;
  
  if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  }
  else
  {// code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlhttp;
}

//Funcion que modifica el contenido de la seccion tipoform(Tipo de registro)
function cargar_formulario(id){

    var xmlhttp = getXMLHTTP();
    
    //Realizaremos esto cuando tengamos la respuesta del servidor
    xmlhttp.onreadystatechange = function() {
      if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        document.getElementById("tipoform").innerHTML = xmlhttp.responseText;
      }
    };
    //Enviamos la peticion asincrona al servidor y esperamos la respuesta
    xmlhttp.open("GET","./view/vistaFormulario.php?id="+id,true);
    xmlhttp.send();
}