<?php
    session_start();

    if(isset($_SESSION['entrenador'])){
        unset($_SESSION['entrenador']);
        session_destroy();
        echo "<script>alert('LOGOUT');</script>";
    }

    if(isset($_SESSION['atleta'])){
        unset($_SESSION['atleta']);
        session_destroy();
        echo "<script>alert('LOGOUT');</script>";
    }

    echo '<script>window.location.assign("./index.php");</script>';
?>