<?php session_start(); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <script src="js/javascript.js"></script>
    
    <!-- CSS -->
    <style>
     /*header {padding: 154px 0 100px;}*/
     section {padding: 100px 0;}
     .slider{
        background: url("images/hj1.jpg");
        height: 50vh;
        background-size: cover;
        background-position: center;
      }
    </style>

    <title>Plataforma de Entrenamiento</title>
  </head>
  <body>

    <?php require("./view/vistaNav.php"); ?>
    <?php require("./model/model.php");
        $id_atleta = $_GET['id'];
        $user_atleta = result_user_atleta($id_atleta);
        $atleta = result_atleta($user_atleta);
        while($obj = $atleta->fetch_object()){
            $datos_atleta = $obj;
        }
        $nombre=$datos_atleta->Nombre;
        $apellidos=$datos_atleta->Apellidos;        
    ?>

    <section id="anadir_resultado">
      <div class="container">
        <div class="row">
          <div class="col mx-auto bg-light">
            </br>
            <h3>Añadir test</h3>
            <h5><?php echo $nombre;?> <?php echo $apellidos;?></h5>
            </br>
            <form method="post" action="controller/controllerAnadirTest.php?id=<?php echo $id_atleta;?>">
              <div class="form-group col-md-3">
                <label for="fecha">Fecha</label>
                <input type="date" name="fecha" class="form-control">
              </div>
              <label for="arrancada"><b>Arrancada</b></label>
              <div class="form-row">
                <div class="form-group col-md-2">
                  <label for="rep_arr">Repeticiones</label>
                  <input type="text" class="form-control" name="rep_arr" pattern="[0-9]{1,8}" required=""/>
                </div>
                <div class="form-group col-md-2">
                  <label for="kg_arr">Carga (kg)</label>
                  <input type="text" class="form-control" name="kg_arr" pattern="[0-9]{1,8}" required=""/>
                </div>
              </div>
             <label for="arrancada"><b>Cargada</b></label>
              <div class="form-row">
                <div class="form-group col-md-2">
                  <label for="rep_car">Repeticiones</label>
                  <input type="text" class="form-control" name="rep_car" pattern="[0-9]{1,8}" required=""/>
                </div>
                <div class="form-group col-md-2">
                  <label for="kg_car">Carga (kg)</label>
                  <input type="text" class="form-control" name="kg_car" pattern="[0-9]{1,8}" required=""/>
                </div>
              </div>
              <label for="arrancada"><b>Sentadilla-40</b></label>
              <div class="form-row">
                <div class="form-group col-md-2">
                  <label for="rep_sen">Repeticiones</label>
                  <input type="text" class="form-control" name="rep_sen" pattern="[0-9]{1,8}" required=""/>
                </div>
                <div class="form-group col-md-2">
                  <label for="kg_sen">Carga (kg)</label>
                  <input type="text" class="form-control" name="kg_sen" pattern="[0-9]{1,8}" required=""/>
                </div>
              </div>
              <label for="arrancada"><b>Sentadilla-40+3d</b></label>
              <div class="form-row">
                <div class="form-group col-md-2">
                  <label for="rep_sen3">Repeticiones</label>
                  <input type="text" class="form-control" name="rep_sen3" pattern="[0-9]{1,8}" required=""/>
                </div>
                <div class="form-group col-md-2">
                  <label for="kg_sen3">Carga (kg)</label>
                  <input type="text" class="form-control" name="kg_sen3" pattern="[0-9]{1,8}" required=""/>
                </div>
              </div>
              <label for="arrancada"><b>Pectoral</b></label>
              <div class="form-row">
                <div class="form-group col-md-2">
                  <label for="rep_pec">Repeticiones</label>
                  <input type="text" class="form-control" name="rep_pec" pattern="[0-9]{1,8}" required=""/>
                </div>
                <div class="form-group col-md-2">
                  <label for="kg_pec">Carga (kg)</label>
                  <input type="text" class="form-control" name="kg_pec" pattern="[0-9]{1,8}" required=""/>
                </div>
              </div>
              </br>
              <div class="form-group">
                <button type="submit" class="btn btn-success">Guardar test</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Plataforma de Entrenamiento 2018</p>
      </div>
    </footer>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>