<?php
    session_start();
    require("../model/model.php");

    $id = $_GET['id'];
    $fecha = $_POST['fecha'];
    $competicion = test_input($_POST['competicion']);
    $lugar = test_input($_POST['lugar']);
    $posicion = test_input($_POST['posicion']);
    $prueba = $_POST['prueba'];
    $marca = test_input($_POST['marca']);
    

    function test_input($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    guardar_resultado($id, $fecha, $competicion, $lugar, $posicion, $prueba, $marca);

    if(isset($_SESSION['entrenador'])){
        echo '<script>window.location.assign("../atleta_entrenador.php?id='.$id.'");</script>';
    }else{
        echo '<script>window.location.assign("../atleta.php");</script>';
    }

?>