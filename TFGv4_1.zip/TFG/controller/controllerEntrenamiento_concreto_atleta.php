<?php
	require("./model/model.php");

	$id = $_GET['id'];
	$user = $_SESSION['atleta'];

	$id_atleta = result_idatleta($user);
	$datos_entrenamientos = datos_entrenamientos_id($id);
	$datos_test = ultimo_test_atleta($id_atleta);  
	      
	while($obj = $datos_entrenamientos->fetch_object()){
	    $dato = $obj;
	}

	$count = 0;
	while($obj2 = $datos_test->fetch_object()){
	    $test = $obj2;
	    $count++;
	}

	$array = array(1 => 0.971, 2 => 0.942, 3 => 0.917, 4 => 0.888, 5 => 0.859, 6 => 0.830, 7 => 0.806, 8 => 0.748, 9 => 0.714, 10 => 0.680);
	
	$fecha = $dato->Fecha;
	$id_plan =  $dato->Id_planificacion;
	$semana = $dato->Semana;
	$dia = $dato->Dia;
	$user = $dato->User;
	$u1 = $dato->U1;
	$u2 = $dato->U2;
	$u3 = $dato->U3;
	$u4 = $dato->U4;
	$u5 = $dato->U5;
	$u6 = $dato->U6;

	if($count != 0){
		$fecha_test = $test->Fecha;
		$rep_arr = $test->Rep_arr;
		$kg_arr = $test->Kg_arr;
		$rep_car = $test->Rep_car;
		$kg_car = $test->Kg_car;
		$rep_sen = $test->Rep_sen;
		$kg_sen = $test->Kg_sen;
		$rep_sen3 = $test->Rep_sen3;
		$kg_sen3 = $test->Kg_sen3;
		$rep_pec = $test->Rep_pec;
		$kg_pec = $test->Kg_pec;
	}
?>