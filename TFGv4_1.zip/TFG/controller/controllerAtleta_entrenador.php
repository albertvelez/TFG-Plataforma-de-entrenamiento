<?php
	require("./model/model.php");

        $id_atleta = $_GET['id'];
        $user_atleta = result_user_atleta($id_atleta);
		$atleta = result_atleta($user_atleta);
        $resultados = resultados_atleta($id_atleta);
        $test = resultados_test_atleta($id_atleta);

        $res_atleta = array();
        $test_atleta = array();

        while($row = $resultados->fetch_assoc()) {
            $res_atleta[]= $row;
        }

        while($row = $test->fetch_assoc()) {
            $test_atleta[]= $row;
        } 

		while($obj = $atleta->fetch_object()){
            $datos_atleta = $obj;
        }

        $id=$datos_atleta->Id;
        $nombre=$datos_atleta->Nombre;
        $apellidos=$datos_atleta->Apellidos;
        $fecha=$datos_atleta->Fecha; 
        $club_organizacion=$datos_atleta->Club_organizacion;
        $especialidad=$datos_atleta->Especialidad;          
?>