<?php
	require("./model/model.php");

		$user = $_SESSION['entrenador'];
		$id = result_identrenador($user);
		$result_atletas_entrenador = result_atletas_entrenador($id);

        $atletas = array();

		while($row = $result_atletas_entrenador->fetch_assoc()) {
			$atletas[]= $row;
    	}       
?>