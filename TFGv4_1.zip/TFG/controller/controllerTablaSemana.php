<?php
	require("../model/model.php");

	$id = $_GET['id'];

	if($id == 0){

	}else{

		$semanas_planificacion = datos_semanas_planificacion($id);  
	      
	    $semanas = array();

		while($row = $semanas_planificacion->fetch_assoc()) {
			$semanas[]= $row;
	    }

	    require("../view/vistaSemanas.php");
	}
?>