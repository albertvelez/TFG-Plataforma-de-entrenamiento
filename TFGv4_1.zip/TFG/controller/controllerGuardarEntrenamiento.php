<?php
    session_start();
    require("../model/model.php");

    $id = $_GET['id'];
    $semana = $_GET['semana'];
    $dia = $_GET['dia'];
    $atletas = $_GET['atletas'];
    $user = $_GET['user'];
    $unidad0 = "---";
    $unidad1 = "---";
    $unidad2 = "---";
    $unidad3 = "---";
    $unidad4 = "---";
    $unidad5 = "---";

    $fecha = $_POST['fecha'];

    if(isset($_POST['unidad0'])){
        $unidad0 = nl2br($_POST['unidad0']);
    }

    if(isset($_POST['unidad1'])){
        $unidad1 = nl2br($_POST['unidad1']);
    }

    if(isset($_POST['unidad2'])){
        $unidad2 = nl2br($_POST['unidad2']);
    }

    if(isset($_POST['unidad3'])){
        $unidad3 = nl2br($_POST['unidad3']);
    }

    if(isset($_POST['unidad4'])){
        $unidad4 = nl2br($_POST['unidad4']);
    }

    if(isset($_POST['unidad5'])){
        $unidad5 = nl2br($_POST['unidad5']);
    }

    $arrayatletas = preg_split('/,/', $atletas, -1, PREG_SPLIT_NO_EMPTY);
    
    guardar_entrenamiento($fecha, $id, $semana, $dia, $user, $unidad0, $unidad1, $unidad2, $unidad3, $unidad4, $unidad5);
    $id_entrenamiento = id_entrenamiento();

    for($i=0; $i<count($arrayatletas); $i++){
        guardar_atletas_entrenamiento($id_entrenamiento, $arrayatletas[$i]);
    }

    echo '<script>window.location.assign("../entrenamientos.php");</script>';
?>