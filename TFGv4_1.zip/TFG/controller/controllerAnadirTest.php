<?php
    session_start();
    require("../model/model.php");

    $id = $_GET['id'];
    $fecha = $_POST['fecha'];
    $rep_arr = test_input($_POST['rep_arr']);
    $kg_arr= test_input($_POST['kg_arr']);
    $rep_car = test_input($_POST['rep_car']);
    $kg_car= test_input($_POST['kg_car']);
    $rep_sen = test_input($_POST['rep_sen']);
    $kg_sen= test_input($_POST['kg_sen']);
    $rep_sen3 = test_input($_POST['rep_sen3']);
    $kg_sen3= test_input($_POST['kg_sen3']);
    $rep_pec = test_input($_POST['rep_pec']);
    $kg_pec= test_input($_POST['kg_pec']);

    function test_input($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    guardar_test($id, $fecha, $rep_arr, $kg_arr, $rep_car, $kg_car, $rep_sen, $kg_sen, $rep_sen3, $kg_sen3, $rep_pec, $kg_pec);

    echo '<script>window.location.assign("../atleta_entrenador.php?id='.$id.'");</script>';
?>