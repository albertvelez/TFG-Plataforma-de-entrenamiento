<?php
	require("./model/model.php");

		$user = $_SESSION['entrenador'];
		$entrenador = result_entrenador($user);

		while($obj = $entrenador->fetch_object()){
            $datos_entrenador = $obj;
        }

        $nombre=$datos_entrenador->Nombre;
        $apellidos=$datos_entrenador->Apellidos;
        $club_organizacion=$datos_entrenador->Club_organizacion;
        $sector=$datos_entrenador->Sector; 
        $especialidad=$datos_entrenador->Especialidad;
        $titulacion=$datos_entrenador->Titulacion;            
?>
