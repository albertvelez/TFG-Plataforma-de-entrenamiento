<?php session_start(); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- CSS -->
    <style>
     /*header {padding: 154px 0 100px;}*/
     section {padding: 100px 0;}
     .slider{
        background: url("images/hj1.jpg");
        height: 50vh;
        background-size: cover;
        background-position: center;
      }
     .imgProd{
        height: 200px;
        width: 200px;
        min-height: 100px;
        min-width: 100px;
      }
    </style>

    <title>Plataforma de Entrenamiento</title>
  </head>
  <body>

    /*<?php require("./view/vistaNav.php"); ?>*/
    <?php require("./controller/controllerAtleta_entrenador.php"); ?>

    <section class="container-fluid slider d-flex justify-content-center align-items-center">
    </section>

    <section id="perfil">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-3 text-center">
            <img src="images/foto.png" class="img-thumbnail imgProd">
          </div>
          <div class="col-lg-3 text-left mt-10 mb-10">
            <h4><?php echo $nombre;?> <?php echo $apellidos;?></h4>
            <p class="lead"><b><?php echo $especialidad;?></b></p>
            <p><b>Club: </b> <?php echo $club_organizacion;?></p>
            <p><b>Año: </b> <?php echo $fecha;?></p>
          </div>
        </div>
        </br>
        <div class="row">
          <div class="col-lg-6 text-left">
            <h5>Resultados</h5>
            <table class="table">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">Competición</th>
                  <th scope="col">Lugar</th>
                  <th scope="col">Fecha</th>
                  <th scope="col">Posición</th>
                  <th scope="col">Marca</th>
                </tr>
              </thead>
              <tbody>
                <?php
                  foreach($res_atleta as $res_atleta){ 
                ?>
                  <tr>
                    <td><?php echo $res_atleta['Competicion'];?></th>
                    <td><?php echo $res_atleta['Lugar'];?></td>
                    <td><?php echo $res_atleta['Fecha'];?></td>
                    <td><?php echo $res_atleta['Posicion'];?></td>
                    <td><?php echo $res_atleta['Marca'];?></td>
                  </tr>
                <?php
                  }              
                ?>
              </tbody>
            </table>
            <a class="btn btn-primary btn-sm" href="anadir_resultado.php?id=<?php echo $id;?>" role="button">Añadir resultado</a>
          </div>
        </div>
          </br>
        <div class="row">
          <div class="col-lg-7 text-left">
            <h5>Test</h5>
            <table class="table">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">Fecha</th>
                  <th scope="col">Arrancada</th>
                  <th scope="col">Cargada</th>
                  <th scope="col">Sent.-40</th>
                  <th scope="col">Sent.-40+3d</th>
                  <th scope="col">Pectoral</th>
                </tr>
              </thead>
              <tbody>
                <?php
                  foreach($test_atleta as $test_atleta){ 
                ?>
                  <tr>
                    <td><?php echo $test_atleta['Fecha'];?></th>
                    <td><?php echo $test_atleta['Rep_arr'];?> x <?php echo $test_atleta['Kg_arr'];?> kg</td>
                    <td><?php echo $test_atleta['Rep_car'];?> x <?php echo $test_atleta['Kg_car'];?> kg</td>
                    <td><?php echo $test_atleta['Rep_sen'];?> x <?php echo $test_atleta['Kg_sen'];?> kg</td>
                    <td><?php echo $test_atleta['Rep_sen3'];?> x <?php echo $test_atleta['Kg_sen3'];?> kg</td>
                    <td><?php echo $test_atleta['Rep_pec'];?> x <?php echo $test_atleta['Kg_pec'];?> kg</td>
                  </tr>
                <?php
                  }              
                ?>
              </tbody>
            </table>
            <a class="btn btn-success btn-sm" href="anadir_test.php?id=<?php echo $id;?>" role="button">Añadir test</a>
          </div>
        </div>
      </div>
    </section>

    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Plataforma de Entrenamiento 2018</p>
      </div>
    </footer>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>