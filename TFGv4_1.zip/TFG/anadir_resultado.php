<?php session_start(); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <script src="js/javascript.js"></script>
    
    <!-- CSS -->
    <style>
     /*header {padding: 154px 0 100px;}*/
     section {padding: 100px 0;}
     .slider{
        background: url("images/hj1.jpg");
        height: 50vh;
        background-size: cover;
        background-position: center;
      }
    </style>

    <title>Plataforma de Entrenamiento</title>
  </head>
  <body>

    <?php require("./view/vistaNav.php"); ?>
    <?php require("./model/model.php");
        $id_atleta = $_GET['id'];
        $user_atleta = result_user_atleta($id_atleta);
        $atleta = result_atleta($user_atleta);
        while($obj = $atleta->fetch_object()){
            $datos_atleta = $obj;
        }
        $nombre=$datos_atleta->Nombre;
        $apellidos=$datos_atleta->Apellidos;        
    ?>

    <section id="anadir_resultado">
      <div class="container">
        <div class="row">
          <div class="col mx-auto bg-light">
            </br>
            <h3>Añadir resultado</h3>
            <h5><?php echo $nombre;?> <?php echo $apellidos;?></h5>
            </br>
            <form method="post" action="controller/controllerAnadirResultado.php?id=<?php echo $id_atleta;?>">
              <div class="form-group col-md-6">
                <label for="fecha">Fecha</label>
                <input type="date" name="fecha" class="form-control">
              </div>
              <div class="form-group col-md-6">
                <label for="competicion">Competición</label>
                <input type="text" class="form-control" name="competicion" pattern="[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð. '-]{2,30}" required=""/>
              </div>
              <div class="form-group col-md-6">
                <label for="lugar">Lugar</label>
                <input type="text" class="form-control" name="lugar" pattern="[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð '-]{2,30}" required=""/>
              </div>
              <div class="form-group col-md-6">
                <label for="posicion">Posición</label>
                <input type="text" class="form-control" name="posicion" pattern="[a-zA-Z0-9àáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-ºª]{1,2}" required=""/>
              </div>
              <div class="form-group col-md-6">
                <label for="prueba">Prueba</label>
                <select name="prueba" class="form-control">
                  <option value="Salto de altura">Salto de altura</option>
                  <option value="Salto con pértiga">Salto con pértiga</option>
                  <option value="Salto de longitud">Salto de longitud</option>
                  <option value="Triple salto">Triple salto</option>
                </select>
              </div>
              <div class="form-group col-md-6">
                <label for="marca">Marca</label>
                <input type="text" class="form-control" name="marca" pattern="[0-9.]{2,8}" required=""/>
              </div>
              </br>
              <div class="form-group">
                <button type="submit" class="btn btn-primary">Guardar resultado</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Plataforma de Entrenamiento 2018</p>
      </div>
    </footer>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>