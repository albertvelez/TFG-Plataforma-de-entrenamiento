<?php session_start(); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <script src="js/javascript.js"></script>
    
    <!-- CSS -->
    <style>
     /*header {padding: 154px 0 100px;}*/
     section {padding: 100px 0;}
     .slider{
        background: url("images/hj1.jpg");
        height: 50vh;
        background-size: cover;
        background-position: center;
      }
    </style>

    <title>Plataforma de Entrenamiento</title>
  </head>
  <body>

    <?php require("./view/vistaNav.php"); ?>
    <?php require("./controller/controllerSemana.php"); ?>

    <section id="semana">
      <div class="container">
        <div class="row">
          <div class="col mx-auto bg-light">
            </br>
            <h3>Semana <?php echo $semana;?></h3>
            <h5><?php echo $mesociclo;?></h5>
            <h6><?php echo $temporada;?> - <?php echo $periodo;?></h6>
            </br>
            <?php if($existe==1){?>
            <div class="alert alert-danger" role="alert">
              Las unidades de entrenamiento de esta semana ya han sido editadas <a href="semanas_entrenamiento.php" class="alert-link">(ver semanas ya editadas)</a>. Si se vuelven a editar se sobrescribirán las actuales.
            </div>
            <?php } ?>
            <?php if($mesociclo=="Puesta en marcha" || $mesociclo=="Adaptación funcional"){?>
              <div class="alert alert-secondary alert-dismissible fade show" role="alert">
                <p class="lead"><b><u>Objetivo mesociclo:</u></b></p>
                <h6><b>Mejora del nivel funcional del aparato locomotor y del estado de salud del atleta</b></h6>
                <ul>
                  <li>Restablecer la capacidad de trabajo hasta los niveles de la temporada anterior</li>
                  <li>Trabajo dirigido a corregir las partes débiles y los desequilibrios detectados la temporada anterior</li>
                  <li>Desarrollo de los grupos musculares principales y de la musculatura de sostén</li>
                  <li>Desarrollo de la capacidad de carrera con la técnica y los ritmos correctos</li>
                  <li>Mejora de la técnica de los elementos y las fases de la carrera y el salto</li>
                </ul>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <h6><b>Nº de sesiones recomendadas por semana:</b> <u>desde 4 hasta 8</u></h6>
              <h6><b>Uni. de entrenamiento recomendadas:</b> MN, ROD, CUE, CR, ET</h6>
            <?php } ?>
            <?php if($mesociclo=="Fuerza"){?>
              <div class="alert alert-secondary alert-dismissible fade show" role="alert">
                <p class="lead"><b><u>Objetivo mesociclo:</u></b></p>
                <h6><b>Mejora de la Fuerza específica</b></h6>
                <ul>
                  <li>Mantenimiento de  los grupos musculares principales y de la musculatura de sostén</li>
                  <li>Desarrollo de la Fuerza máxima dinámica y explosiva (hasta los niveles máximos de la temporada anterior)</li>
                  <li>Mejora de la capacidad de salto (general y específica)</li>
                  <li>Mejora de la técnica de carrera específica del saltador de altura</li>
                  <li>Mejora de la técnica y de la eficacia en la utilización de los ejercicios especiales y de los saltos con carrera corta</li>
                </ul>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <h6><b>Nº de sesiones recomendadas por semana:</b> <u>de 8 a 10</u></h6>
              <h6><b>Uni. de entrenamiento recomendadas:</b> F, MN, MV, MH, ARR, ET, T</h6>
            <?php } ?>
            <?php if($mesociclo=="Fuerza velocidad"){?>
              <div class="alert alert-secondary alert-dismissible fade show" role="alert">
                <p class="lead"><b><u>Objetivo mesociclo:</u></b></p>
                <h6><b>Transferencia a la Potencia específica</b></h6>
                <ul>
                  <li>Mantenimiento del nivel de Fuerza máxima dinámica y explosiva</li>
                  <li>Desarrollo de la Fuerza especial (elástico-explosiva) mediante la utilización de ejercicios específicos y de competición</li>
                  <li>Mejora de la técnica y de la eficacia del salto con carrera de impulso media</li>
                  <li>Mejora de la técnica y el ritmo de la carrera de impulso</li>
                </ul>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <h6><b>Nº de sesiones recomendadas por semana:</b> <u>de 10 a 8</u></h6>
              <h6><b>Uni. de entrenamiento recomendadas:</b> F, MN, MV, MH, VEL, ET, T</h6>
            <?php } ?>
            <?php if($mesociclo=="Velocidad técnica"){?>
              <div class="alert alert-secondary alert-dismissible fade show" role="alert">
                <p class="lead"><b><u>Objetivo mesociclo:</u></b></p>
                <h6><b>Mejora de la Potencia específica</b></h6>
                <ul>
                  <li>Mantenimiento del nivel de Fuerza máxima dinámica y elástico-explosiva</li>
                  <li>Desarrollo de la Fuerza especial (reflejo-elástico-explosiva) mediante la utilización de ejercicios específicos y de competición</li>
                  <li>Mejora de la técnica y el ritmo del ejercicio competitivo con carrera de impulso completa</li>
                  <li>Mejora de la velocidad de la carrera de impulso</li>
                </ul>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <h6><b>Nº de sesiones recomendadas por semana:</b> <u>de 8 a 6</u></h6>
              <h6><b>Uni. de entrenamiento recomendadas:</b> F, MV, MH, VEL, ET, T</h6>
            <?php } ?>
            <?php if($mesociclo=="Modelación competitiva" || $mesociclo=="Competitivo"){?>
              <div class="alert alert-secondary alert-dismissible fade show" role="alert">
                <p class="lead"><b><u>Objetivo mesociclo:</u></b></p>
                <h6><b>Logro del mejor resultado competitivo posible</b></h6>
                <ul>
                  <li>Óptima manifestación y posterior mantenimiento del nivel de condición física especial</li>
                  <li>Adaptación al microciclo competitivo</li>
                  <li>Logro del mejor resultado competitivo posible</li>
                </ul>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <h6><b>Nº de sesiones recomendadas por semana:</b> <u>de 6 a 4</u></h6>
              <h6><b>Uni. de entrenamiento recomendadas:</b> F, MV, VEL, ET, T</h6>
            <?php } ?>
            </br>
            <form method="post" action="controller/controllerSemanaMesociclo.php?id=<?php echo $id;?>&mesociclo=<?php echo $mesociclo;?>&semana=<?php echo $semana;?>">
              <div class="row">
              <?php $dia = 1;?>
              <?php for ($i = 0; $i < 4; $i++) { ?>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                  <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th colspan="2" scope="col" class="text-center bg-info"><?php echo $dia_semana[$i];?></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td class="text-center table-info"><b>Mañana</b></td>
                        <td class="text-center table-info"><b>Tarde</b></td>
                      </tr>
                      <?php $sesion = 1;?>
                      <?php for ($j = 0; $j < 3; $j++) { ?>
                      <tr>
                        <?php for ($k = 0; $k < 2; $k++) { ?>
                        <td>
                          <select name="u_entrenamiento_<?php echo $dia;?>_<?php echo $sesion;?>" class="form-control form-control-sm" onchange="this.style.backgroundColor=this.options[this.selectedIndex].style.backgroundColor">
                              <option style="background-color: #ffffff" value="---">---</option>
                            <optgroup style="background-color: #ffffcc" label="Fuerza">
                              <option style="background-color: #ffffcc" value="F">F</option>
                            </optgroup>
                            <optgroup style="background-color: #ccffcc" label="Monoarti.">
                              <option style="background-color: #ccffcc" value="MN">MN</option>
                            </optgroup>
                            <optgroup style="background-color: #ccffff" label="Multisaltos">
                              <option style="background-color: #ccffff" value="MH">MH</option>
                              <option style="background-color: #ccffff" value="MV">MV</option>
                            </optgroup>
                            <optgroup style="background-color: #ccccff" label="Carrera">
                              <option style="background-color: #ccccff" value="ROD">ROD</option>
                              <option style="background-color: #ccccff" value="CR">CR</option>
                              <option style="background-color: #ccccff" value="VEL">VEL</option>
                              <option style="background-color: #ccccff" value="CUE">CUE</option>
                              <option style="background-color: #ccccff" value="ARR">ARR</option>
                            </optgroup>
                             <optgroup style="background-color: #ffcccc" label="Técnica">
                              <option style="background-color: #ffcccc" value="ET">ET</option>
                              <option style="background-color: #ffcccc" value="T">T</option>
                            </optgroup>
                          </select>
                        </td>
                        <?php $sesion++;?>
                        <?php } ?>
                      </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
                <?php $dia++;?>
              <?php } ?>
              </div>
              <div class="row">
              <?php for ($i = 4; $i < 7; $i++) { ?>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                  <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th colspan="2" scope="col" class="text-center bg-info"><?php echo $dia_semana[$i];?></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td class="text-center table-info"><b>Mañana</b></td>
                        <td class="text-center table-info"><b>Tarde</b></td>
                      </tr>
                      <?php $sesion = 1;?>
                      <?php for ($j = 0; $j < 3; $j++) { ?>
                      <tr>
                        <?php for ($k = 0; $k < 2; $k++) { ?>
                        <td>
                         <select name="u_entrenamiento_<?php echo $dia;?>_<?php echo $sesion;?>" class="form-control form-control-sm" onchange="this.style.backgroundColor=this.options[this.selectedIndex].style.backgroundColor">
                              <option style="background-color: #ffffff" value="---">---</option>
                            <optgroup style="background-color: #ffffcc" label="Fuerza">
                              <option style="background-color: #ffffcc" value="F">F</option>
                            </optgroup>
                            <optgroup style="background-color: #ccffcc" label="Monoarti.">
                              <option style="background-color: #ccffcc" value="MN">MN</option>
                            </optgroup>
                            <optgroup style="background-color: #ccffff" label="Multisaltos">
                              <option style="background-color: #ccffff" value="MH">MH</option>
                              <option style="background-color: #ccffff" value="MV">MV</option>
                            </optgroup>
                            <optgroup style="background-color: #ccccff" label="Carrera">
                              <option style="background-color: #ccccff" value="ROD">ROD</option>
                              <option style="background-color: #ccccff" value="CR">CR</option>
                              <option style="background-color: #ccccff" value="VEL">VEL</option>
                              <option style="background-color: #ccccff" value="CUE">CUE</option>
                              <option style="background-color: #ccccff" value="ARR">ARR</option>
                            </optgroup>
                             <optgroup style="background-color: #ffcccc" label="Técnica">
                              <option style="background-color: #ffcccc" value="ET">ET</option>
                              <option style="background-color: #ffcccc" value="T">T</option>
                            </optgroup>
                          </select>
                        </td>
                        <?php $sesion++;?>
                        <?php } ?>
                      </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
                <?php $dia++;?>
              <?php } ?>
                <div class="col">
                </div>
              </div>
              <hr />
              </br>
              <div class="form-group">
                <button type="submit" class="btn btn-primary">Guardar unidades para esta semana</button>
              </div>
              </br>
            </form>
            <hr />
            <h6>Información de las unidades de entrenamiento:</h6>
            <button type="button" class="btn btn-lg btn-warning mb-3 mt-2 mr-3" data-toggle="popover" title="Fuerza" data-content="Ejercicios con pesas:<br />
                <ul>
                  <li>Arrancada</li>
                  <li>Cargada</li>
                  <li>Sentadilla</li>
                  <li>Pectoral</li>
                  <li>...</li>
                </ul>">F</button>
            <button type="button" class="btn btn-lg btn-success mb-3 mt-2 mr-3" data-toggle="popover" title="Monoarticulares" data-content="Ejercicios con máquinas de musculación:<br />
                <ul>
                  <li>Cuádriceps</li>
                  <li>Isquios</li>
                  <li>Gluteos</li>
                  <li>Prensa</li>
                  <li>...</li>
                </ul>">MN</button>
            <button type="button" class="btn btn-lg btn-primary mb-3 mt-2 mr-3" data-toggle="popover" title="Multisaltos horizontales" data-content="
                <ul>
                  <li>Escaleras o obtaculines</li>
                  <li>Decasaltos</li>
                  <li>Pensasaltos</li>
                  <li>Longitud parado</li>
                  <li>Triple parado</li>
                  <li>...</li>
                </ul>">MH</button>
            <button type="button" class="btn btn-lg btn-primary mb-3 mt-2 mr-3" data-toggle="popover" title="Multisaltos verticales" data-content="
                <ul>
                  <li>Imitativos de batida</li>
                  <li>Multisaltos con vallas</li>
                  <li>...</li>
                </ul>">MV</button>
            <button type="button" class="btn btn-lg btn-secondary mb-3 mt-2 mr-3" data-toggle="popover" title="Rodar" data-content="Rodaje largo (15-45 min)">ROD</button>
            <button type="button" class="btn btn-lg btn-secondary mb-3 mt-2 mr-3" data-toggle="popover" title="Cuestas" data-content="Carreras en cuesta">CUE</button>
            <button type="button" class="btn btn-lg btn-secondary mb-3 mt-2 mr-3" data-toggle="popover" title="Arrastres" data-content="Carreras con lastre">ARR</button>
            <button type="button" class="btn btn-lg btn-secondary mb-3 mt-2 mr-3" data-toggle="popover" title="Velocidad" data-content="Carreras de velocidad máxima">VEL</button>
            <button type="button" class="btn btn-lg btn-secondary mb-3 mt-2 mr-3" data-toggle="popover" title="Carrera repetida" data-content="Carreras de distancia media 120-300 m">CR</button>
            <button type="button" class="btn btn-lg btn-danger mb-3 mt-2 mr-3" data-toggle="popover" title="Ejercicios técnicos" data-content="
                <ul>
                  <li>Isométricos franqueo</li>
                  <li>Flop de parado</li>
                  <li>Saltos a tocar</li>
                  <li>Skiping batida</li>
                  <li>...</li>
                </ul>">ET</button>
            <button type="button" class="btn btn-lg btn-danger mb-3 mt-2 mr-3" data-toggle="popover" title="Técnica" data-content="
                <ul>
                  <li>Tijeras (facilitadas)</li>
                  <li>Flop (facilitado o estándar)</li>
                  <li>Variación de carrera dependiendo del periodo</li>
                </ul>">T</button>
            </br>
          </div>
        </div>
      </div>
    </section>

    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Plataforma de Entrenamiento 2018</p>
      </div>
    </footer>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){
      $('[data-toggle="popover"]').popover({ html : true });
      });
    </script>
  </body>
</html>