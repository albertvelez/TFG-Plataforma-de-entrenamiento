<div class="col-12 col-sm-12 col-md-10 col-lg-7">
<form method="post" action="controller/controllerGuardarEntrenamiento.php?id=<?php echo $id;?>&semana=<?php echo $semana;?>&dia=<?php echo $dia;?>&atletas=<?php echo $atletas;?>&user=<?php echo $user;?>">
  <div id="tipoform">
    <div class="form-group">
      <label for="fecha">Fecha (<?php echo $dia;?>) </label>
      <input type="date" name="fecha" class="form-control">
    </div>
    <?php $iter = 0;?>
    <?php for ($i = 0; $i < 6; $i++) {

      if ($iter == 0 AND ($unidad[0] != '---' OR $unidad[1] != '---' OR $unidad[2] != '---')){ ?>
        <h4><u>Mañana</u></h4>
      <?php }
      if ($iter == 3 AND ($unidad[3] != '---' OR $unidad[4] != '---' OR $unidad[5] != '---')){ ?>
        <h4><u>Tarde</u></h4>
      <?php } ?>
      <?php if ($unidad[$i] != '---'){ ?>
      <div class="form-group">
        <label for="exampleFormControlTextarea1"></label>
        <textarea name="unidad<?php echo $iter ?>" class="form-control" id="exampleFormControlTextarea1" rows="4">
<?php if($unidad[$i] == 'MN'){
        $mn_ejercicios = mn_ejercicios();
        $mn_repeticiones = mn_repeticiones($mesociclo);
        $mn_ej = array();
        $mn_rep = array();
        while($row = $mn_ejercicios->fetch_assoc()) {
          $mn_ej[]= $row;
        }
        while($row = $mn_repeticiones->fetch_assoc()) {
          $mn_rep[]= $row;
        }
        echo "Monoarticulares:\n";
        foreach($mn_ej as $mn_ej){ 
          echo $mn_ej['Ejercicio']."\n";
        }
        foreach($mn_rep as $mn_rep){ 
          echo $mn_rep['Series']." x ".$mn_rep['Repeticiones']." recuperación: ".$mn_rep['Recuperacion']."\n";
        }               
        }?>
<?php if($unidad[$i] == 'ROD'){
        $rodar = min_rodar($mesociclo);
        $min_rodar = array();

        while($row = $rodar->fetch_assoc()) {
          $min_rodar[]= $row;
        }

        foreach($min_rodar as $min_rodar){ 
            echo "Rodar:\n".$min_rodar['Tiempo'];
        }            
        }?>
<?php if($unidad[$i] == 'MH'){
        $m_h = multi_horizontales($mesociclo, $volumen);
        $multi_horizontales = array();

        while($row = $m_h->fetch_assoc()) {
          $multi_horizontales[]= $row;
        }
        echo "Multisaltos horizontales:\n";
        foreach($multi_horizontales as $multi_horizontales){
          echo $multi_horizontales['Ejercicio'].": ".$multi_horizontales['Series']." x ".$multi_horizontales['Repeticiones']."\n";
        }            
        }?>
<?php if($unidad[$i] == 'MV'){
        $m_v = multi_verticales($mesociclo, $volumen);
        $multi_verticales = array();

        while($row = $m_v->fetch_assoc()) {
          $multi_verticales[]= $row;
        }
        echo "Multisaltos verticales:\n";
        foreach($multi_verticales as $multi_verticales){
          echo $multi_verticales['Ejercicio'].": ".$multi_verticales['Series']." x ".$multi_verticales['Repeticiones']."\n";
        }            
        }?>
<?php if($unidad[$i] == 'CUE' || $unidad[$i] == 'ARR' || $unidad[$i] == 'VEL' || $unidad[$i] == 'CR'){
        $carr = carrera($mesociclo, $volumen, $unidad[$i]);
        $carrera = array();

        while($row = $carr->fetch_assoc()) {
          $carrera[]= $row;
        }

        if($unidad[$i] == 'ARR'){
          foreach($carrera as $carrera){
            echo $carrera['Ejercicio'].":\n".$carrera['Series']." x ".$carrera['Distancia']."m (".$carrera['Lastre']."kg)"." recuperación: ".$carrera['Recuperacion']."\n";
          }
        }else{
          foreach($carrera as $carrera){
            echo $carrera['Ejercicio'].":\n".$carrera['Series']." x ".$carrera['Distancia']."m recuperación: ".$carrera['Recuperacion']."\n";
          }
        }           
        }?>
<?php if($unidad[$i] == 'ET'){
        $ej_tec = ej_tecnicos($mesociclo, $volumen);
        $ej_tecnicos = array();

        while($row = $ej_tec->fetch_assoc()) {
          $ej_tecnicos[]= $row;
        }
        echo "Ejercicios técnicos:\n";
        foreach($ej_tecnicos as $ej_tecnicos){
          echo $ej_tecnicos['Ejercicio'].":  ".$ej_tecnicos['Series']." x ".$ej_tecnicos['Repeticiones']."\n";
        }            
        }?>
<?php if($unidad[$i] == 'T'){
        $tec = tecnica($mesociclo, $volumen);
        $tecnica = array();

        while($row = $tec->fetch_assoc()) {
          $tecnica[]= $row;
        }
        echo "Técnica:\n";
        foreach($tecnica as $tecnica){
          echo $tecnica['Ejercicio']." x".$tecnica['Saltos']."\n";
        }            
        }?>
<?php if($unidad[$i] == 'F'){
        $fue = fuerza($mesociclo, $volumen);
        $fuerza = array();

        while($row = $fue->fetch_assoc()) {
          $fuerza[]= $row;
        }
        echo "Fuerza:\n";
        foreach($fuerza as $fuerza){
          echo $fuerza['Ejercicio'].":  ".$fuerza['Series']." x ".$fuerza['Repeticiones']." x ".$fuerza['Rm']."\n";
        }            
        }?></textarea>
      </div>
      <?php } ?>
    <?php $iter++;} ?>  
    <div class="form-group">
      <button type="submit" class="btn btn-primary">Guardar entrenamiento</button>
    </div>
  </div>
</form>
</div>