<?php session_start(); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <script src="js/javascript.js"></script>
    
    <!-- CSS -->
    <style>
     /*header {padding: 154px 0 100px;}*/
     section {padding: 100px 0;}
     .slider{
        background: url("images/hj1.jpg");
        height: 50vh;
        background-size: cover;
        background-position: center;
      }
    </style>

    <title>Plataforma de Entrenamiento</title>
  </head>
  <body>

    <?php require("./view/vistaNav.php"); ?>

    <section id="planificacion_manual">
      <div class="container">
        <div class="row">
          <div class="col mx-auto bg-light">
            </br>
            <h3>Planificación personalizada</h3>
            </br>
            <form method="post" action="controller/controllerVolIntPlanPerso.php">
              <div class="form-group">
                <label for="nombre">Nombre planificación:</label>
                <input type="text" class="form-control" name="nombre" pattern="[A-Za-z0-9]{5,20}" required=""/>
              </div>
              <div class="form-group">
                <label for="temporada">Temporada:</label>
                <select name="temporada" class="form-control">
                  <option value="2017/2018">2017/2018</option>
                  <option value="2018/2019">2018/2019</option>
                  <option value="2019/2020">2019/2020</option>
                  <option value="2020/2021">2020/2021</option>
                </select>
              </div>
              <div class="form-group">
                <label for="periodo">Periodo:</label>
                <select name="periodo" class="form-control">
                  <option value="Pista cubierta">Pista cubierta</option>
                  <option value="Aire libre">Aire libre</option>
                </select>
              </div>
              </br>
              <h4>Ciclos/Mesociclos</h4>
              </br>
              <div class="row">
                <div class="col">
                  <div class="form-group">
                    <label class="form-check-label" for="Check1">
                      <h5><u>Preparación General</u></h5>
                    </label>
                  </div>
                  <div class="form-group">
                    <label for="puesta_marcha">Puesta en marcha:</label>
                    <select name="puesta_marcha" class="form-control form-control-sm" onchange="cargar_puesta_marcha(this.value);">
                      <option value="0">0 semanas</option>
                      <option value="1">1 semana</option>
                      <option value="2">2 semanas</option>
                      <option value="3">3 semanas</option>
                      <option value="4">4 semanas</option>
                    </select>
                  </div>
                   <div class="form-group">
                    <label for="adaptacion_funcional">Adaptación funcional:</label>
                    <select name="adaptacion_funcional" class="form-control form-control-sm" onchange="cargar_adaptacion_funcional(this.value);">
                      <option value="0">0 semanas</option>
                      <option value="1">1 semana</option>
                      <option value="2">2 semanas</option>
                      <option value="3">3 semanas</option>
                      <option value="4">4 semanas</option>
                    </select>
                  </div>
                </div>
                <div class="col">
                  <div class="form-group">
                      <label class="form-check-label" for="Check2">
                        <h5><u>Preparación Especial</u></h5>
                      </label>
                  </div>
                  <div class="form-group">
                    <label for="fuerza">Fuerza:</label>
                    <select name="fuerza" class="form-control form-control-sm" onchange="cargar_fuerza(this.value);">
                      <option value="0">0 semanas</option>
                      <option value="1">1 semana</option>
                      <option value="2">2 semanas</option>
                      <option value="3">3 semanas</option>
                      <option value="4">4 semanas</option>
                    </select>
                  </div>
                   <div class="form-group">
                    <label for="fuerza_velocidad">Fuerza velocidad:</label>
                    <select name="fuerza_velocidad" class="form-control form-control-sm" onchange="cargar_fuerza_velocidad(this.value);">
                      <option value="0">0 semanas</option>
                      <option value="1">1 semana</option>
                      <option value="2">2 semanas</option>
                      <option value="3">3 semanas</option>
                      <option value="4">4 semanas</option>
                    </select>
                  </div>
                </div>
                <div class="col">
                  <div class="form-group">
                      <label class="form-check-label" for="Check3">
                        <h5><u>Preparación Técnica</u></h5>
                      </label>
                  </div>
                  <div class="form-group">
                    <label for="velocidad_tecnica">Velocidad técnica:</label>
                    <select name="velocidad_tecnica" class="form-control form-control-sm" onchange="cargar_velocidad_tecnica(this.value);">
                      <option value="0">0 semanas</option>
                      <option value="1">1 semana</option>
                      <option value="2">2 semanas</option>
                      <option value="3">3 semanas</option>
                      <option value="4">4 semanas</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="mod_competitiva">Modelación competitiva:</label>
                    <select name="mod_competitiva" class="form-control form-control-sm" onchange="cargar_mod_competitiva(this.value);">
                      <option value="0">0 semanas</option>
                      <option value="1">1 semana</option>
                      <option value="2">2 semanas</option>
                      <option value="3">3 semanas</option>
                      <option value="4">4 semanas</option>
                    </select>
                  </div>
                </div>
                <div class="col">
                  <div class="form-group">
                      <label class="form-check-label" for="Check4">
                        <h5><u>Periodo competitivo</u></h5>
                      </label>
                  </div>
                  <div class="form-group">
                    <label for="competitivo">Periodo competitivo:</label>
                    <select name="competitivo" class="form-control form-control-sm" onchange="cargar_competitivo(this.value);">
                      <option value="1">1 semana</option>
                      <option value="2">2 semanas</option>
                      <option value="3">3 semanas</option>
                      <option value="4">4 semanas</option>
                      <option value="5">5 semanas</option>
                      <option value="6">6 semanas</option>
                      <option value="7">7 semanas</option>
                      <option value="8">8 semanas</option>
                      <option value="9">9 semanas</option>
                      <option value="10">10 semanas</option>
                    </select>
                  </div>
                </div>
              </div>
              <hr />
              </br>
                <h4>Volumenes e Intensidades</h4>
              </br>
              <div class="row">
                <div class="col">
                  <div id="puesta_marcha">
                  </div>
                </div>
                <div class="col">
                  <div id="adaptacion_funcional">
                  </div>
                </div>
                <div class="col">
                  <div id="fuerza">
                  </div>
                </div>
                <div class="col">
                  <div id="fuerza_velocidad">
                  </div>
                </div>
                <div class="col">
                  <div id="velocidad_tecnica">
                  </div>
                </div>
                <div class="col">
                  <div id="mod_competitiva">
                  </div>
                </div>
                <div class="col">
                  <div id="competitivo">
                    <h6><u>Competitivo</u></h6>
                    <div class="form-group">             
                      <label for="intensidad_competitivo">Intensidad:</label>
                      <select name="intensidad_competitivo" class="form-control form-control-sm">
                        <option value="1">Baja</option>
                        <option value="2">Media</option>
                        <option value="3">Alta</option>
                        <option value="4">Máxima</option>
                        <option value="5">Submáxima</option>
                      </select>
                    </div>
                    <div class="form-group">
                        <label for="volumen">Sem. 1:</label>
                        <select name="volumen_competitivo1" class="form-control form-control-sm">
                          <option value="10">10%</option>
                          <option value="20">20%</option>
                          <option value="30">30%</option>
                          <option value="40">40%</option>
                          <option value="50">50%</option>
                          <option value="60">60%</option>
                          <option value="70">70%</option>
                          <option value="80">80%</option>
                          <option value="90">90%</option>
                          <option value="100">100%</option>
                      </select>
                    </div>                            
                  </div>
                </div>
              </div>
              </br>
              <div class="form-group">
                <button type="submit" class="btn btn-primary">Generar planificación</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Plataforma de Entrenamiento 2018</p>
      </div>
    </footer>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>