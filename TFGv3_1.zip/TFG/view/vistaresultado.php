<!DOCTYPE html>
<html>
<head charset="UTF-8">
</head>
<body>
    <br/>
    <table>
        <tr>
            <td>Nombre:</td>
            <td><?php echo $nombreentrenador ?></td>
        </tr>
        <tr>
            <td>Usuario:</td>
            <td><?php echo $id_entrenador ?></td>
        </tr>
    </table>
    <br/>
</body>
</html>