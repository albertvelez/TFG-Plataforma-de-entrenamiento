<?php session_start(); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <script src="js/javascript.js"></script>
    
    <!-- CSS -->
    <style>
     /*header {padding: 154px 0 100px;}*/
     section {padding: 100px 0;}
     .slider{
        background: url("images/taf.jpg");
        height: 40vh;
        background-size: cover;
        background-position: center;
     }
    </style>

    <title>Plataforma de Entrenamiento</title>
  </head>
  <body>

    <?php require("./view/vistaNav.php"); ?>

    <section class="container-fluid slider d-flex justify-content-center align-items-center">
    </section>

    <section id="registro">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 mx-auto bg-light">
            <h2>Registro</h2>
            <form method="post" action="controller/controllerRegistro.php">
              <div class="form-group">
                <label>Selecciona tipo de cuenta:</label>
                <select name="tiporegistro" class="form-control" onchange="cargar_formulario(this.value);">
                  <option value="1">Entrenador</option>
                  <option value="2">Atleta</option>
                </select>
              </div>
              <div id="tipoform">
                <div class="form-group">
                  <label for="nombre">Nombre:</label>
                  <input type="text" class="form-control" name="nombre" pattern="[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð '-]{2,30}" required=""/>
                </div>
                <div class="form-group">
                  <label for="apellidos">Apellidos:</label>
                  <input type="text" class="form-control" name="apellidos" pattern="[a-zA-ZàáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð '-]{2,30}" required=""/>
                </div>
                <div class="form-group">
                  <label for="email">E-mail:</label>
                  <input type="email" class="form-control" name="email" pattern="^[-\w.]+@{1}[-a-z0-9]+[.]{1}[a-z]{2,5}$" required=""/>
                </div>
                <div class="form-group">
                  <label for="club_organizacion">Club/Organización:</label>
                  <input type="text" class="form-control" name="club_organizacion" pattern="[a-zA-Z0-9àáâäãåąčćęèéêëėįìíîïłńòóôöõøùúûüųūÿýżźñçčšžÀÁÂÄÃÅĄĆČĖĘÈÉÊËÌÍÎÏĮŁŃÒÓÔÖÕØÙÚÛÜŲŪŸÝŻŹÑßÇŒÆČŠŽ∂ð ,.'-ºª]{2,30}" required=""/>
                </div>
                <div class="form-group">
                  <label for="sector">Sector:</label>
                  <select name="sector"class="form-control">
                    <option value="Saltos">Saltos</option>
                  </select>
                </div>
                <div class="form-group">
                  <label for="especialidad">Especialidad:</label>
                  <select name="especialidad" class="form-control">
                    <option value="Salto de altura">Salto de altura</option>
                  </select>
                </div>
                <div class="form-group">
                  <label for="titulacion">Titulación:</label>
                  <select name="titulacion" class="form-control">
                    <option value="Nacional especializado">E. Nacional especializado</option>
                    <option value="Nacional">E. Nacional</option>
                    <option value="Club">E. Club</option>
                    <option value="Monitor">Monitor</option>
                  </select>
                </div>
                <br/>
                <div class="form-group">
                  <label for="user">Nombre de usuario:</label>
                  <input type="text" class="form-control" name="user" pattern="[A-Za-z0-9]{5,10}" required=""/>
                </div>
                <div class="form-group">
                  <label for="pass">Contraseña:</label>
                  <input type="password" class="form-control" name="pass" pattern="[A-Za-z0-9]{4,8}" required=""/>
                </div>
                <div class="form-group">
                  <button type="submit" class="btn btn-primary">Registrarse</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Plataforma de Entrenamiento 2018</p>
      </div>
    </footer>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>