<?php
	require("./model/model.php");

	$id = $_GET['id'];
	$semana = $_GET['semana'];
	$user = $_GET['user'];
	$dia = $_GET['dia'];

	$id_entr = result_identrenador($user);
	$result_atletas_entrenador = result_atletas_entrenador($id_entr);

    $atletas = array();

	while($row = $result_atletas_entrenador->fetch_assoc()) {
		$atletas[]= $row;
    }    
?>