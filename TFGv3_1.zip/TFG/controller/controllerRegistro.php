<?php
    session_start();
    require("../model/model.php");

    $tiporegistro = $_POST['tiporegistro'];
    $nombre = test_input($_POST['nombre']);
    $apellidos = test_input($_POST['apellidos']);
    $email = test_input($_POST['email']);
    $club_organizacion = test_input($_POST['club_organizacion']);
    $sector = $_POST['sector'];
    $especialidad = $_POST['especialidad'];
    $user = test_input($_POST['user']);
    $pass = test_input($_POST['pass']);
    $pass = password_hash($pass, PASSWORD_DEFAULT);

    if($tiporegistro == 1){
        $titulacion = $_POST['titulacion'];
        anadir_usuario_entrenador($nombre, $apellidos, $email, $club_organizacion, $sector, $especialidad, $user, $pass, $titulacion);
    }

    if($tiporegistro == 2){
        $fecha = test_input($_POST['fecha']);
        $nombreentrenador = test_input($_POST['nombreentrenador']);
        $id_entrenador = result_identrenador($nombreentrenador);
        anadir_usuario_atleta($nombre, $apellidos, $email, $club_organizacion, $sector, $especialidad, $user, $pass, $fecha, $id_entrenador);
    }

    function test_input($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    echo '<script>window.location.assign("../index.php");</script>';
?>