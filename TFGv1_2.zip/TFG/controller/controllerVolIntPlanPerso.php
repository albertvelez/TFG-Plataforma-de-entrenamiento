<?php
    session_start();
    require("../model/model.php");

    if(isset($_SESSION['entrenador'])){

        $id_entrenador = $_SESSION['entrenador'];
        $nombre = test_input($_POST['nombre']);
        $temporada = $_POST['temporada'];
        $periodo = $_POST['periodo'];

        $puesta_marcha = $_POST['puesta_marcha'];
        $adaptacion_funcional = $_POST['adaptacion_funcional'];
       
        if(isset($_POST['intensidad_puesta_marcha']))
        {
            $intensidad_puesta_marcha = $_POST['intensidad_puesta_marcha'];
        }else{  
            $intensidad_puesta_marcha = 0;
        }

        if(isset($_POST['intensidad_adaptacion_funcional']))
        {
            $intensidad_adaptacion_funcional = $_POST['intensidad_adaptacion_funcional'];
        }else{  
            $intensidad_adaptacion_funcional = 0;
        }

       if($puesta_marcha == 0 && $adaptacion_funcional == 0)
        {
            $prep_general = 0;
        }else{  
            $prep_general = 1;
        }


        $fuerza = $_POST['fuerza'];
        $fuerza_velocidad = $_POST['fuerza_velocidad'];

        if(isset($_POST['intensidad_fuerza']))
        {
            $intensidad_fuerza = $_POST['intensidad_fuerza'];
        }else{  
            $intensidad_fuerza = 0;
        }

        if(isset($_POST['intensidad_fuerza_velocidad']))
        {
            $intensidad_fuerza_velocidad = $_POST['intensidad_fuerza_velocidad'];
        }else{  
            $intensidad_fuerza_velocidad = 0;
        }

        if($fuerza == 0 && $fuerza_velocidad == 0)
        {
            $prep_especial = 0;
        }else{   
            $prep_especial = 1;
        }


        $velocidad_tecnica = $_POST['velocidad_tecnica'];
        $mod_competitiva = $_POST['mod_competitiva'];

        if(isset($_POST['intensidad_velocidad_tecnica']))
        {
            $intensidad_velocidad_tecnica = $_POST['intensidad_velocidad_tecnica'];
        }else{  
            $intensidad_velocidad_tecnica = 0;
        }

        if(isset($_POST['intensidad_mod_competitiva']))
        {
            $intensidad_mod_competitiva = $_POST['intensidad_mod_competitiva'];
        }else{  
            $intensidad_mod_competitiva = 0;
        }
        
        if($velocidad_tecnica == 0 && $mod_competitiva == 0)
        {
            $prep_tecnica = 0;
        }else{   
            $prep_tecnica = 1;
        }

        
        $competitivo = $_POST['competitivo'];

        if(isset($_POST['intensidad_competitivo']))
        {
            $intensidad_competitivo = $_POST['intensidad_competitivo'];
        }else{  
            $intensidad_competitivo = 0;
        }
        
        if($competitivo == 0)
        {
            $per_competitivo = 0;
        }else{   
            $per_competitivo = 1;
        }

        /*guardar planificacion
        echo "$nombre, $temporada, $periodo <br>";
        echo "$puesta_marcha, $adaptacion_funcional, $intensidad_puesta_marcha, $intensidad_adaptacion_funcional, $prep_general <br>";
        echo "$fuerza, $fuerza_velocidad, $intensidad_fuerza, $intensidad_fuerza_velocidad, $prep_especial <br>";
        echo "$velocidad_tecnica, $mod_competitiva, $intensidad_velocidad_tecnica, $intensidad_mod_competitiva, $prep_tecnica <br>";
        echo "$competitivo, $intensidad_competitivo, $per_competitivo <br>";*/

        guardar_planificacion($nombre, $id_entrenador, $temporada, $periodo, $puesta_marcha, $adaptacion_funcional, $intensidad_puesta_marcha, $intensidad_adaptacion_funcional, $prep_general, $fuerza, $fuerza_velocidad, $intensidad_fuerza, $intensidad_fuerza_velocidad, $prep_especial, $velocidad_tecnica, $mod_competitiva, $intensidad_velocidad_tecnica, $intensidad_mod_competitiva, $prep_tecnica, $competitivo, $intensidad_competitivo, $per_competitivo);

        $id_planificacion = id_planificacion();

        $i = 1;

        if($puesta_marcha != 0){

            $array1 = array();
            if(isset($_POST['volumen_puesta_marcha1'])){
                $volumen_puesta_marcha1 = $_POST['volumen_puesta_marcha1'];
                array_push($array1, $volumen_puesta_marcha1); }

            if(isset($_POST['volumen_puesta_marcha2'])){
                $volumen_puesta_marcha2 = $_POST['volumen_puesta_marcha2'];
                array_push($array1, $volumen_puesta_marcha2); }

            if(isset($_POST['volumen_puesta_marcha3'])){
                $volumen_puesta_marcha3 = $_POST['volumen_puesta_marcha3'];
                array_push($array1, $volumen_puesta_marcha3); }

            if(isset($_POST['volumen_puesta_marcha4'])){
                $volumen_puesta_marcha4 = $_POST['volumen_puesta_marcha4'];
                array_push($array1, $volumen_puesta_marcha4); }

            $ciclo = "Preparación General";
            $mesociclo = "Puesta en marcha";
            
            for($j=0; $j<count($array1); $j++){
                $volumen = $array1[$j];
                guardar_volumen($id_planificacion, $ciclo, $mesociclo, $i, $volumen);
                /*echo "$ciclo, $mesociclo, $i, $volumen <br>";*/
                $i++;
            }
        }

        if($adaptacion_funcional != 0){

            $array2 = array();
            if(isset($_POST['volumen_adaptacion_funcional1'])){
                $volumen_adaptacion_funcional1 = $_POST['volumen_adaptacion_funcional1'];
                array_push($array2, $volumen_adaptacion_funcional1); }

            if(isset($_POST['volumen_adaptacion_funcional2'])){
                $volumen_adaptacion_funcional2 = $_POST['volumen_adaptacion_funcional2'];
                array_push($array2, $volumen_adaptacion_funcional2); }

            if(isset($_POST['volumen_adaptacion_funcional3'])){
                $volumen_adaptacion_funcional3 = $_POST['volumen_adaptacion_funcional3'];
                array_push($array2, $volumen_adaptacion_funcional3); }

            if(isset($_POST['volumen_adaptacion_funcional4'])){
                $volumen_adaptacion_funcional4 = $_POST['volumen_adaptacion_funcional4'];
                array_push($array2, $volumen_adaptacion_funcional4); }

            $ciclo = "Preparación General";
            $mesociclo = "Adaptación funcional";
            
            for($j=0; $j<count($array2); $j++){
                $volumen = $array2[$j];
                guardar_volumen($id_planificacion, $ciclo, $mesociclo, $i, $volumen);
                /*echo "$ciclo, $mesociclo, $i, $volumen <br>";*/
                $i++;
            }
        }

        if($fuerza != 0){

            $array3 = array();
            if(isset($_POST['volumen_fuerza1'])){
                $volumen_fuerza1 = $_POST['volumen_fuerza1'];
                array_push($array3, $volumen_fuerza1); }

            if(isset($_POST['volumen_fuerza2'])){
                $volumen_fuerza2 = $_POST['volumen_fuerza2'];
                array_push($array3, $volumen_fuerza2); }

            if(isset($_POST['volumen_fuerza3'])){
                $volumen_fuerza3 = $_POST['volumen_fuerza3'];
                array_push($array3, $volumen_fuerza3); }

            if(isset($_POST['volumen_fuerza4'])){
                $volumen_fuerza4 = $_POST['volumen_fuerza4'];
                array_push($array3, $volumen_fuerza4); }

            $ciclo = "Preparación Especial";
            $mesociclo = "Fuerza";
            
            for($j=0; $j<count($array3); $j++){
                $volumen = $array3[$j];
                guardar_volumen($id_planificacion, $ciclo, $mesociclo, $i, $volumen);
                /*echo "$ciclo, $mesociclo, $i, $volumen <br>";*/
                $i++;
            }
        }

        if($fuerza_velocidad != 0){

            $array4 = array();
            if(isset($_POST['volumen_fuerza_velocidad1'])){
                $volumen_fuerza_velocidad1 = $_POST['volumen_fuerza_velocidad1'];
                array_push($array4, $volumen_fuerza_velocidad1); }

            if(isset($_POST['volumen_fuerza_velocidad2'])){
                $volumen_fuerza_velocidad2 = $_POST['volumen_fuerza_velocidad2'];
                array_push($array4, $volumen_fuerza_velocidad2); }

            if(isset($_POST['volumen_fuerza_velocidad3'])){
                $volumen_fuerza_velocidad3 = $_POST['volumen_fuerza_velocidad3'];
                array_push($array4, $volumen_fuerza_velocidad3); }

            if(isset($_POST['volumen_fuerza_velocidad4'])){
                $volumen_fuerza_velocidad4 = $_POST['volumen_fuerza_velocidad4'];
                array_push($array4, $volumen_fuerza_velocidad4); }

            $ciclo = "Preparación Especial";
            $mesociclo = "Fuerza velocidad";
            
            for($j=0; $j<count($array4); $j++){
                $volumen = $array4[$j];
                guardar_volumen($id_planificacion, $ciclo, $mesociclo, $i, $volumen);
                /*echo "$ciclo, $mesociclo, $i, $volumen <br>";*/
                $i++;
            }
        } 

        if($velocidad_tecnica != 0){

            $array5 = array();
            if(isset($_POST['volumen_velocidad_tecnica1'])){
                $volumen_velocidad_tecnica1 = $_POST['volumen_velocidad_tecnica1'];
                array_push($array5, $volumen_velocidad_tecnica1); }

            if(isset($_POST['volumen_velocidad_tecnica2'])){
                $volumen_velocidad_tecnica2 = $_POST['volumen_velocidad_tecnica2'];
                array_push($array5, $volumen_velocidad_tecnica2); }

            if(isset($_POST['volumen_velocidad_tecnica3'])){
                $volumen_velocidad_tecnica3 = $_POST['volumen_velocidad_tecnica3'];
                array_push($array5, $volumen_velocidad_tecnica3); }

            if(isset($_POST['volumen_velocidad_tecnica4'])){
                $volumen_velocidad_tecnica4 = $_POST['volumen_velocidad_tecnica4'];
                array_push($array5, $volumen_velocidad_tecnica4); }

            $ciclo = "Preparación Técnica";
            $mesociclo = "Velocidad técnica";
            
            for($j=0; $j<count($array5); $j++){
                $volumen = $array5[$j];
                guardar_volumen($id_planificacion, $ciclo, $mesociclo, $i, $volumen);
                /*echo "$ciclo, $mesociclo, $i, $volumen <br>";*/
                $i++;
            }
        }

        if($mod_competitiva != 0){

            $array6 = array();
            if(isset($_POST['volumen_mod_competitiva1'])){
                $volumen_mod_competitiva1 = $_POST['volumen_mod_competitiva1'];
                array_push($array6, $volumen_mod_competitiva1); }

            if(isset($_POST['volumen_mod_competitiva2'])){
                $volumen_mod_competitiva2 = $_POST['volumen_mod_competitiva2'];
                array_push($array6, $volumen_mod_competitiva2); }

            if(isset($_POST['volumen_mod_competitiva3'])){
                $volumen_mod_competitiva3 = $_POST['volumen_mod_competitiva3'];
                array_push($array6, $volumen_mod_competitiva3); }

            if(isset($_POST['volumen_mod_competitiva4'])){
                $volumen_mod_competitiva4 = $_POST['volumen_mod_competitiva4'];
                array_push($array6, $volumen_mod_competitiva4); }

            $ciclo = "Preparación Técnica";
            $mesociclo = "Modelación competitiva";
            
            for($j=0; $j<count($array6); $j++){
                $volumen = $array6[$j];
                guardar_volumen($id_planificacion, $ciclo, $mesociclo, $i, $volumen);
                /*echo "$ciclo, $mesociclo, $i, $volumen <br>";*/
                $i++;
            }
        }

        if($competitivo != 0){

            $array7 = array();
            if(isset($_POST['volumen_competitivo1'])){
                $volumen_competitivo1 = $_POST['volumen_competitivo1'];
                array_push($array7, $volumen_competitivo1); }

            if(isset($_POST['volumen_competitivo2'])){
                $volumen_competitivo2 = $_POST['volumen_competitivo2'];
                array_push($array7, $volumen_competitivo2); }

            if(isset($_POST['volumen_competitivo3'])){
                $volumen_competitivo3 = $_POST['volumen_competitivo3'];
                array_push($array7, $volumen_competitivo3); }

            if(isset($_POST['volumen_competitivo4'])){
                $volumen_competitivo4 = $_POST['volumen_competitivo4'];
                array_push($array7, $volumen_competitivo4); }

            if(isset($_POST['volumen_competitivo5'])){
                $volumen_competitivo5 = $_POST['volumen_competitivo5'];
                array_push($array7, $volumen_competitivo5); }

            if(isset($_POST['volumen_competitivo6'])){
                $volumen_competitivo6 = $_POST['volumen_competitivo6'];
                array_push($array7, $volumen_competitivo6); }

            if(isset($_POST['volumen_competitivo7'])){
                $volumen_competitivo7 = $_POST['volumen_competitivo7'];
                array_push($array7, $volumen_competitivo7); }

            if(isset($_POST['volumen_competitivo8'])){
                $volumen_competitivo8 = $_POST['volumen_competitivo8'];
                array_push($array7, $volumen_competitivo8); }

            if(isset($_POST['volumen_competitivo9'])){
                $volumen_competitivo9 = $_POST['volumen_competitivo9'];
                array_push($array7, $volumen_competitivo9); }

            if(isset($_POST['volumen_competitivo10'])){
                $volumen_competitivo10 = $_POST['volumen_competitivo10'];
                array_push($array7, $volumen_competitivo10); }

            $ciclo = "Periodo Competitivo";
            $mesociclo = "Competitivo";
            
            for($j=0; $j<count($array7); $j++){
                $volumen = $array7[$j];
                guardar_volumen($id_planificacion, $ciclo, $mesociclo, $i, $volumen);
                /*echo "$ciclo, $mesociclo, $i, $volumen <br>";*/
                $i++;
            }
        }

    }else{
        echo "<script>alert('Para hacer una planificacion necesitas ser entrenador');</script>";
        echo '<script>window.location.assign("../login.php");</script>';
    }     

 
    function test_input($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

?>