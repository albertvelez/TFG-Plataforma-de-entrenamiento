<?php
    session_start();

    $nombre = test_input($_POST['nombre']);
    $temporada = $_POST['temporada'];
    $periodo = $_POST['periodo'];

    if(isset($_POST['prep_general']) && $_POST['prep_general'] == '1')
    {
        $prep_general = $_POST['prep_general'];
        $puesta_marcha = $_POST['puesta_marcha'];
        $adaptacion_funcional = $_POST['adaptacion_funcional'];

    }else{
        
        $prep_general = 0;
        $puesta_marcha = 0;
        $adaptacion_funcional = 0;
    }

    if(isset($_POST['prep_especial']) && $_POST['prep_especial'] == '1')
    {
        $prep_especial = $_POST['prep_especial'];
        $fuerza = $_POST['fuerza'];
        $fuerza_velocidad = $_POST['fuerza_velocidad'];

    }else{
        
        $prep_especial = 0;
        $fuerza = 0;
        $fuerza_velocidad = 0;
    }

    if(isset($_POST['prep_tecnica']) && $_POST['prep_tecnica'] == '1')
    {
        $prep_tecnica = $_POST['prep_tecnica'];
        $velocidad_tecnica = $_POST['velocidad_tecnica'];
        $mod_competitiva = $_POST['mod_competitiva'];

    }else{
        
        $prep_tecnica = 0;
        $velocidad_tecnica = 0;
        $mod_competitiva = 0;
    }

    if(isset($_POST['per_competitivo']) && $_POST['per_competitivo'] == '1')
    {
        $per_competitivo = $_POST['per_competitivo'];
        $competitivo = $_POST['competitivo'];
       
    }else{
        
        $per_competitivo = 0;
        $competitivo = 0;
    }

 
    function test_input($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

?>