//Funcion que construye un objeto xmlhttp, devuelve un objeto xmlhttp
function getXMLHTTP()
{
  var xmlhttp;
  
  if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  }
  else
  {// code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  return xmlhttp;
}

//Funcion que modifica el contenido de la seccion tipoform(Tipo de registro)
function cargar_formulario(id){

    var xmlhttp = getXMLHTTP();
    
    //Realizaremos esto cuando tengamos la respuesta del servidor
    xmlhttp.onreadystatechange = function() {
      if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        document.getElementById("tipoform").innerHTML = xmlhttp.responseText;
      }
    };
    //Enviamos la peticion asincrona al servidor y esperamos la respuesta
    xmlhttp.open("GET","./view/vistaFormulario.php?id="+id,true);
    xmlhttp.send();
}

//Funcion que modifica el contenido de la seccion tipoform(Tipo de registro)
function cargar_puesta_marcha(valor){

    var xmlhttp = getXMLHTTP();
    
    //Realizaremos esto cuando tengamos la respuesta del servidor
    xmlhttp.onreadystatechange = function() {
      if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        document.getElementById("puesta_marcha").innerHTML = xmlhttp.responseText;
      }
    };
    //Enviamos la peticion asincrona al servidor y esperamos la respuesta
    xmlhttp.open("GET","./view/vistaVolIntPuestaMarcha.php?valor="+valor,true);
    xmlhttp.send();
}

//Funcion que modifica el contenido de la seccion tipoform(Tipo de registro)
function cargar_adaptacion_funcional(valor){

    var xmlhttp = getXMLHTTP();
    
    //Realizaremos esto cuando tengamos la respuesta del servidor
    xmlhttp.onreadystatechange = function() {
      if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        document.getElementById("adaptacion_funcional").innerHTML = xmlhttp.responseText;
      }
    };
    //Enviamos la peticion asincrona al servidor y esperamos la respuesta
    xmlhttp.open("GET","./view/vistaVolIntAdaptFunc.php?valor="+valor,true);
    xmlhttp.send();
}

function cargar_fuerza(valor){

    var xmlhttp = getXMLHTTP();
    
    //Realizaremos esto cuando tengamos la respuesta del servidor
    xmlhttp.onreadystatechange = function() {
      if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        document.getElementById("fuerza").innerHTML = xmlhttp.responseText;
      }
    };
    //Enviamos la peticion asincrona al servidor y esperamos la respuesta
    xmlhttp.open("GET","./view/vistaVolIntFuerza.php?valor="+valor,true);
    xmlhttp.send();
}

function cargar_fuerza_velocidad(valor){

    var xmlhttp = getXMLHTTP();
    
    //Realizaremos esto cuando tengamos la respuesta del servidor
    xmlhttp.onreadystatechange = function() {
      if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        document.getElementById("fuerza_velocidad").innerHTML = xmlhttp.responseText;
      }
    };
    //Enviamos la peticion asincrona al servidor y esperamos la respuesta
    xmlhttp.open("GET","./view/vistaVolIntFuerzaVel.php?valor="+valor,true);
    xmlhttp.send();
}

function cargar_velocidad_tecnica(valor){

    var xmlhttp = getXMLHTTP();
    
    //Realizaremos esto cuando tengamos la respuesta del servidor
    xmlhttp.onreadystatechange = function() {
      if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        document.getElementById("velocidad_tecnica").innerHTML = xmlhttp.responseText;
      }
    };
    //Enviamos la peticion asincrona al servidor y esperamos la respuesta
    xmlhttp.open("GET","./view/vistaVolIntVelTec.php?valor="+valor,true);
    xmlhttp.send();
}

function cargar_mod_competitiva(valor){

    var xmlhttp = getXMLHTTP();
    
    //Realizaremos esto cuando tengamos la respuesta del servidor
    xmlhttp.onreadystatechange = function() {
      if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        document.getElementById("mod_competitiva").innerHTML = xmlhttp.responseText;
      }
    };
    //Enviamos la peticion asincrona al servidor y esperamos la respuesta
    xmlhttp.open("GET","./view/vistaVolIntModComp.php?valor="+valor,true);
    xmlhttp.send();
}

function cargar_competitivo(valor){

    var xmlhttp = getXMLHTTP();
    
    //Realizaremos esto cuando tengamos la respuesta del servidor
    xmlhttp.onreadystatechange = function() {
      if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        document.getElementById("competitivo").innerHTML = xmlhttp.responseText;
      }
    };
    //Enviamos la peticion asincrona al servidor y esperamos la respuesta
    xmlhttp.open("GET","./view/vistaVolIntComp.php?valor="+valor,true);
    xmlhttp.send();
}