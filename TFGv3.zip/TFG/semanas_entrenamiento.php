<?php session_start(); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <script src="js/javascript.js"></script>
    
    <!-- CSS -->
    <style>
     /*header {padding: 154px 0 100px;}*/
     section {padding: 100px 0;}
     .slider{
        background: url("images/hj1.jpg");
        height: 50vh;
        background-size: cover;
        background-position: center;
      }
    </style>

    <title>Plataforma de Entrenamiento</title>
  </head>
  <body>

    <?php require("./view/vistaNav.php"); ?>
    <?php require("./controller/controllerSemanasEntrenamiento.php"); ?>

    <section id="semanas_planificacion">
      <div class="container">
        <div class="row">
          <div class="col mx-auto bg-light">
            </br>
              <h3>Semanas Planificación</h3>
            </br>
            <div class="form-group">
              <label for="planificacion">Nombre planificación:</label>
              <select name="planificacion" id="planificacion" class="form-control" onchange="cargar_semanas(this.value);">
                <option value="0">-----</option>
                <?php foreach($planificacion as $planificacion){?>
                    <option value="<?php echo $planificacion['Id'];?>"><?php echo $planificacion['Nombre'];?></option>
                <?php } ?>
              </select>
              </br>
              <label for="semana">Semana:</label>
              <select name="semana" id="semanas" class="form-control">
                <option value="0">-----</option>
              </select>
              </br>
              <div class="row">
                <div class="col">
                  <div id="boton">
                    <button class="btn btn-primary" type="button" onclick="cargar_semana_concreta();">Cargar semana</button>
                  </div>
                </div>
              </div>
              </br>
              <div class="row">
                <div id="tabla_semana">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Plataforma de Entrenamiento 2018</p>
      </div>
    </footer>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>