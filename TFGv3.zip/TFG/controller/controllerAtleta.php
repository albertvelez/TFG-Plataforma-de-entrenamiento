<?php
	require("./model/model.php");

		$user = $_SESSION['atleta'];
		$atleta = result_atleta($user);
        $id = result_idatleta($user);
        $resultados = resultados_atleta($id);

        $res_atleta = array();

        while($row = $resultados->fetch_assoc()) {
            $res_atleta[]= $row;
        } 

		while($obj = $atleta->fetch_object()){
            $datos_atleta = $obj;
        }

        $nombre=$datos_atleta->Nombre;
        $apellidos=$datos_atleta->Apellidos;
        $fecha=$datos_atleta->Fecha; 
        $club_organizacion=$datos_atleta->Club_organizacion;
        $especialidad=$datos_atleta->Especialidad;          
?>
