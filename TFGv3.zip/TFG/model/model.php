<?php

    function connectDB(){
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "tfg";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

          // Check connection
          if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
          }
        $conn->set_charset("utf8");  

        return $conn;    
    }

    function result_identrenador($nombreentrenador){
        $conn = connectDB(); 
        $sql_identrenador = "SELECT Id FROM entrenadores where Usuario='$nombreentrenador'";
        $result_identrenador = $conn->query($sql_identrenador);

        while($obj = $result_identrenador->fetch_object()){
            $identrenador = $obj;
        }

        $id=$identrenador->Id;

        return $id;
    }

    function result_idatleta($nombreatleta){
        $conn = connectDB(); 
        $sql_idatleta = "SELECT Id FROM atletas where Usuario='$nombreatleta'";
        $result_idatleta = $conn->query($sql_idatleta);

        while($obj = $result_idatleta->fetch_object()){
            $idatleta = $obj;
        }

        $id=$idatleta->Id;

        return $id;
    }

    function anadir_usuario_entrenador($nombre, $apellidos, $email, $club_organizacion, $sector, $especialidad, $user, $pass, $titulacion){
        $conn = connectDB();

        $stmt = $conn->prepare("INSERT INTO entrenadores (Nombre, Apellidos, Email, Club_organizacion, Sector, Especialidad, Titulacion, Usuario, Password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssssss", $nombre, $apellidos, $email, $club_organizacion, $sector, $especialidad, $titulacion, $user, $pass);
        
        if(!$stmt->execute()){
            echo "Error: " . $stmt->errno . "<br>" . $stmt->error;
        }else{
            echo "<script>alert('Registro realizado correctamente');</script>";
        }
    }

    function anadir_usuario_atleta($nombre, $apellidos, $email, $club_organizacion, $sector, $especialidad, $user, $pass, $fecha, $id_entrenador){
        $conn = connectDB();

        $stmt = $conn->prepare("INSERT INTO atletas (Nombre, Apellidos, Email, Club_organizacion, Sector, Especialidad, Fecha, Id_entrenador, Usuario, Password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssssss", $nombre, $apellidos, $email, $club_organizacion, $sector, $especialidad, $fecha, $id_entrenador, $user, $pass);
        
        if(!$stmt->execute()){
            echo "Error: " . $stmt->errno . "<br>" . $stmt->error;
        }else{
            echo "<script>alert('Registro realizado correctamente');</script>";
        }
    }

    function loginUser($user, $pass){
        $conn = connectDB();

        $stmt = $conn->prepare("SELECT Usuario, Password FROM entrenadores where Usuario=?");
        $stmt->bind_param("s", $user);
        if(!$stmt->execute()){
            echo "Error: " . $stmt->errno . "<br>" . $stmt->error;
        }

        $result_entrenador = $stmt->get_result();
        
        $count = 0;
        while($obj = $result_entrenador->fetch_object()){
            $entrenador= $obj;
            $count++;
        }

        if($count == 1){ //Ha habido un resultado del select
            if(password_verify($pass, $entrenador->Password)){
                    echo "<script>alert('Usuario correcto, bienvenid@ ".$entrenador->Usuario."');</script>";
                    return 1;
                }else{
                    echo "<script>alert('Password incorrecto');</script>";
                    return 2;
                }                    
            
        }else{ //Si no lo ha habido, buscamos atletas

            $stmt = $conn->prepare("SELECT Usuario, Password FROM atletas where Usuario=?");
            $stmt->bind_param("s", $user);
            if(!$stmt->execute()){
                echo "Error: " . $stmt->errno . "<br>" . $stmt->error;
            }

            $result_atleta = $stmt->get_result();

            $count = 0;
            while($obj = $result_atleta->fetch_object()){
                $atleta = $obj;
                $count++;
            }

            if($count == 0){
                echo "<script>alert('Usuario incorrecto');</script>";
                return 5;
            }

            if($count == 1){ //Ha habido un resultado del select
                if(password_verify($pass, $atleta->Password)){
                    echo "<script>alert('Usuario correcto, bienvenid@ ".$atleta->Usuario."');</script>";
                    return 3;
                }else{
                    echo "<script>alert('Password incorrecto');</script>";
                    return 4;
                }                    
            }          
        }
    }

    function result_entrenador($user){
        $conn = connectDB(); 
        $sql_entrenador = "SELECT Nombre, Apellidos, Club_organizacion, Sector, Especialidad, Titulacion FROM entrenadores where Usuario='$user'";
        $result_entrenador = $conn->query($sql_entrenador);

        return $result_entrenador;
    }

    function result_atletas_entrenador($id){
        $conn = connectDB(); 
        $sql_atletas_entrenador = "SELECT Nombre, Apellidos, Fecha, Club_organizacion, Especialidad FROM atletas where Id_entrenador='$id'";
        $result_atletas_entrenador = $conn->query($sql_atletas_entrenador);

        return $result_atletas_entrenador;
    }

    function result_atleta($user){
        $conn = connectDB(); 
        $sql_atleta = "SELECT Nombre, Apellidos, Fecha, Club_organizacion, Especialidad FROM atletas where Usuario='$user'";
        $result_atleta = $conn->query($sql_atleta);

        return $result_atleta;
    }

    function resultados_atleta($id){
        $conn = connectDB(); 
        $sql_resultados_atleta = "SELECT Fecha, Competicion, Lugar, Posicion, Prueba, Marca FROM resultados_atleta where Id_atleta='$id'";
        $resultados_atleta = $conn->query($sql_resultados_atleta);

        return $resultados_atleta;
    }

    function id_planificacion(){
        $conn = connectDB();
        $sql_planificacion = "SELECT Id FROM planificacion ORDER BY Id DESC LIMIT 1";
        $result_planificacion = $conn->query($sql_planificacion);
        
        $count = 0;
        while($obj = $result_planificacion->fetch_object()){
                $planificacion = $obj;
                $count++;
        }

        if($count == 0){
            $id = 0;
        }else{
            $id = $planificacion->Id;
        }

        return $id; 
    }

    function guardar_planificacion($nombre, $id_entrenador, $temporada, $periodo, $puesta_marcha, $adaptacion_funcional, $intensidad_puesta_marcha, $intensidad_adaptacion_funcional, $prep_general, $fuerza, $fuerza_velocidad, $intensidad_fuerza, $intensidad_fuerza_velocidad, $prep_especial, $velocidad_tecnica, $mod_competitiva, $intensidad_velocidad_tecnica, $intensidad_mod_competitiva, $prep_tecnica, $competitivo, $intensidad_competitivo, $per_competitivo){

        $conn = connectDB();

        $stmt = $conn->prepare("INSERT INTO planificacion (Nombre, Id_entrenador, Temporada, Periodo, P_marcha, A_funcional, Int_p_marcha, Int_a_funcional, Prep_general, Fuerza, F_velocidad, Int_fuerza, Int_f_velocidad, Prep_especial, V_tecnica, M_competitiva, Int_v_tecnica, Int_m_competitiva, Prep_tecnica, Competitivo, Int_competitivo, Per_competitivo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssssssssssssssssss", $nombre, $id_entrenador, $temporada, $periodo, $puesta_marcha, $adaptacion_funcional, $intensidad_puesta_marcha, $intensidad_adaptacion_funcional, $prep_general, $fuerza, $fuerza_velocidad, $intensidad_fuerza, $intensidad_fuerza_velocidad, $prep_especial, $velocidad_tecnica, $mod_competitiva, $intensidad_velocidad_tecnica, $intensidad_mod_competitiva, $prep_tecnica, $competitivo, $intensidad_competitivo, $per_competitivo);
        
        if(!$stmt->execute()){
            echo "Error: " . $stmt->errno . "<br>" . $stmt->error;
        }
    }

    function guardar_volumen($id_planificacion, $ciclo, $mesociclo, $i, $volumen){
        $conn = connectDB();

        $stmt = $conn->prepare("INSERT INTO volumenes_planificacion (Id_planificacion, Ciclo, Mesociclo, Semana, Volumen) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $id_planificacion, $ciclo, $mesociclo, $i, $volumen);
        
        if(!$stmt->execute()){
            echo "Error: " . $stmt->errno . "<br>" . $stmt->error;
        }
    }

    function seleccionar_planificacion($user){
        $conn = connectDB(); 
        $sql_planificacion = "SELECT Id, Nombre FROM planificacion where Id_entrenador='$user'";
        $planificacion = $conn->query($sql_planificacion);

        return $planificacion;
    }

    function datos_planificacion($id){
        $conn = connectDB(); 
        $sql_planificacion = "SELECT Nombre, Temporada, Periodo, P_marcha, A_funcional, Int_p_marcha, Int_a_funcional, Prep_general, Fuerza, F_velocidad, Int_fuerza, Int_f_velocidad, Prep_especial, V_tecnica, M_competitiva, Int_v_tecnica, Int_m_competitiva, Prep_tecnica, Competitivo, Int_competitivo, Per_competitivo FROM planificacion where Id ='$id'";
        $planificacion = $conn->query($sql_planificacion);

        return $planificacion;
    }

    function datos_volumen($id){
        $conn = connectDB(); 
        $sql_volumenes = "SELECT Ciclo, Mesociclo, Semana, Volumen FROM volumenes_planificacion where Id_planificacion ='$id'";
        $volumenes = $conn->query($sql_volumenes);

        return $volumenes;
    }

    function guardar_semana_mesociclo($id_planificacion, $mesociclo, $semana, $dia, $u1, $u2, $u3, $u4, $u5, $u6){
        $conn = connectDB();

        $sql_id = "SELECT Id FROM semana_mesociclo where Id_planificacion ='$id_planificacion' AND Semana ='$semana' AND Dia ='$dia'";
        $result_id = $conn->query($sql_id);

        $count = 0;
        while($obj = $result_id->fetch_object()){
                $id = $obj;
                $count++;
        }

        if($count == 0){
            $stmt = $conn->prepare("INSERT INTO semana_mesociclo (Id_planificacion, Mesociclo, Semana, Dia, U_entrenamiento1, U_entrenamiento2, U_entrenamiento3, U_entrenamiento4, U_entrenamiento5, U_entrenamiento6) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssssss", $id_planificacion, $mesociclo, $semana, $dia, $u1, $u2, $u3, $u4, $u5, $u6);
            
            if(!$stmt->execute()){
                echo "Error: " . $stmt->errno . "<br>" . $stmt->error;
            }

        }else{
            $sql = "UPDATE semana_mesociclo SET U_entrenamiento1='$u1', U_entrenamiento2='$u2', U_entrenamiento3='$u3', U_entrenamiento4='$u4', U_entrenamiento5='$u5', U_entrenamiento6='$u6' WHERE Id_planificacion ='$id_planificacion' AND Semana ='$semana' AND Dia ='$dia'";

            if (!$conn->query($sql) === TRUE) {
                echo "Error updating record: " . $conn->error;
            }
        }  
    }

    function datos_semanas_planificacion($id){
        $conn = connectDB(); 
        $sql_semanas = "SELECT DISTINCT Semana FROM semana_mesociclo where Id_planificacion ='$id' ORDER BY Semana DESC";
        $semanas = $conn->query($sql_semanas);

        return $semanas;
    }

    function datos_semana_concreta($id, $valor){
        $conn = connectDB(); 
        $sql_semana = "SELECT Id, Mesociclo, Dia, U_entrenamiento1, U_entrenamiento2, U_entrenamiento3, U_entrenamiento4, U_entrenamiento5, U_entrenamiento6 FROM semana_mesociclo where Id_planificacion ='$valor' AND Semana = '$id' ORDER BY Id";
        $semana = $conn->query($sql_semana);

        return $semana;
    }

    function existe_semana($id, $semana){
        $conn = connectDB();

        $sql_id = "SELECT Id FROM semana_mesociclo where Id_planificacion ='$id' AND Semana ='$semana'";
        $result_id = $conn->query($sql_id);

        $count = 0;
        while($obj = $result_id->fetch_object()){
                $id = $obj;
                $count++;
        }
        if($count == 0){
            return 0;
        }else{
            return 1;
        }  
    }