<?php
  session_start();

  $valor = $_GET['valor'];
?> 

<?php if($valor==0){?>

<?php }else{ ?>
<h6><u>Vel. técnica</u></h6>      

    <div class="form-group">             
      <label for="intensidad_velocidad_tecnica">Intensidad:</label>
      <select name="intensidad_velocidad_tecnica" class="form-control form-control-sm">
        <option value="1">Baja</option>
        <option value="2">Media</option>
        <option value="3">Alta</option>
        <option value="4">Máxima</option>
        <option value="5">Submáxima</option>
      </select>
    </div>
    <div class="form-group">
      <?php for ($i = 1; $i <= $valor; $i++) { ?>
        <label for="volumen">Sem. <?php echo $i;?>:</label>
        <select name="volumen_velocidad_tecnica<?php echo $i;?>" class="form-control form-control-sm">
          <option value="10">10%</option>
          <option value="20">20%</option>
          <option value="30">30%</option>
          <option value="40">40%</option>
          <option value="50">50%</option>
          <option value="60">60%</option>
          <option value="70">70%</option>
          <option value="80">80%</option>
          <option value="90">90%</option>
          <option value="100">100%</option>
      </select>
      <?php } ?>
    </div>                            
  </div>
<?php } ?>     